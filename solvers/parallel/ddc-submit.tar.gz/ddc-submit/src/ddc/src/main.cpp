
#include <algorithm>
#include <memory>
#include <array>
#include <vector>
#include <map>
#include <unordered_map>
#include <queue>
#include <string>
#include <iostream>
#include <fstream>
#include <sstream>
#include <iomanip>
#include <random>
#include <stdexcept>
#include <mutex>
#include <cstring>
#include <csignal>
#include <cassert>
#include <experimental/optional>

#include <unistd.h>
#include <fcntl.h>

#include <mpi.h>

#include <satuzk/util/Mpi.inline.hpp>
#include <satuzk/All.hpp>
#include "mpix.hpp"
#include "messages.hpp"
//#include <mpicxx/fiber.hpp>
//#include <satuzk/distributed/balancer.hpp>
#include <satuzk/CubeAndConquer.hpp>
#include <satuzk/CubeAndConquer.inline.hpp>

#include CONFIG_HEADER

MpiGuardStruct mpiGuard;

void onInterrupt(int signal_num) {
}

int main(int argc, char **argv) {
	int world_rank;
	MPI_Comm_rank(MPI_COMM_WORLD, &world_rank);

	if(world_rank == 0) {
		std::cout << "c This is satUZK-ddc, commit " << CONFIG_REVISION
	#ifdef CONFIG_DIRTY
			<< "*"
	#endif
			<< std::endl;
		
		std::cout << "c Args:";
		for(int i = 0; i < argc; i++)
			std::cout << ' ' << argv[i];
		std::cout << std::endl;
	}

	//theSolver.opts.general.verbose = 1;

	struct sigaction action;
	action.sa_handler = &onInterrupt;
	action.sa_flags = 0;
	sigemptyset(&action.sa_mask);
	if(sigaction(SIGINT, &action, NULL) != 0
			|| sigaction(SIGTERM, &action, NULL) != 0)
		throw std::runtime_error("sigaction() failed");
	
	// parse the parameters given to the solver
	std::vector<std::string> args;
	for(int i = 1; i < argc; ++i)
		args.push_back(std::string(argv[i]));

	std::string instance;
	std::string model_file;
	std::string file_prefix;
	int num_workers = 0;
	size_t memory_budget = 0;
	std::vector<int> assumptions;
	for(auto i = args.begin(); i != args.end(); ) { // no increment here
		if(*i == "--file-prefix") {
			++i;
			if(i == args.end()) {
				std::cout << "Expected argument for --log-prefix" << std::endl;
				return 0;
			}
			file_prefix = *i;
			++i;
		}else if(*i == "--num-workers") {
			++i;
			if(i == args.end()) {
				std::cout << "Expected argument for --num-workers" << std::endl;
				return 0;
			}
			num_workers = std::stoi(*i);
			++i;
		}else if(*i == "--memory-budget") {
			++i;
			if(i == args.end()) {
				std::cout << "Expected argument for --memory-budget" << std::endl;
				return 0;
			}
			memory_budget = std::stoi(*i);
			++i;
		}else if((*i).at(0) == '-') {
			std::cout << "Illegal command line parameter '" << (*i) << "'" << std::endl;
			return 0;
		}else{
			// the last parameter is always the instance name
			instance = *i;
			++i;
			if(i != args.end()) {
				std::cout << "Unexpected parameter '" << *i
						<< "' after instance name" << std::endl;
				return 0;
			}
		}
	}

	assert(instance.length() > 0);
	assert(num_workers > 0);

	struct timespec start_wt, end_wt;
	if(clock_gettime(CLOCK_MONOTONIC, &start_wt))
		throw std::runtime_error("clock_gettime() failed");

	satuzk::ddc::SuiteStruct<> suite{num_workers};
	suite.memoryBudget = memory_budget * size_t(1'000'000);
	satuzk::SolveState result = suite.run(instance);
	
	if(clock_gettime(CLOCK_MONOTONIC, &end_wt))
		throw std::runtime_error("clock_gettime() failed");
	time_t elapsed_secs = end_wt.tv_sec - start_wt.tv_sec;
	
	if(world_rank == 0) {
		std::cout << "c walltime: " << elapsed_secs << " secs" << std::endl;

		if(result == satuzk::kStateSatisfied) {
			std::cout << "s SATISFIABLE" << std::endl;

			for(auto it = suite.sharedData.model.begin(); it != suite.sharedData.model.end(); /* no increment */) {
				fputc('v', stdout);
				for(int i = 0; i < 10 && it != suite.sharedData.model.end(); ++i, ++it)
					fprintf(stdout, " %d", it->toNumber());
				if(it == suite.sharedData.model.end()) {
					fputs(" 0\n", stdout);
				}else{
					fputc('\n', stdout);
				}
			}
		}else if(result == satuzk::kStateUnsatisfiable) {
			std::cout << "s UNSATISFIABLE" << std::endl;
		}else if(result == satuzk::kStateAssumptionFail) {
			std::cout << "s ASSUMPTIONFAIL" << std::endl;
		}else{
			std::cout << "s UNKNOWN" << std::endl;
		}
	}

	/*if(result == satuzk::kStateSatisfied) {
		return 10;
	}else if(result == satuzk::kStateUnsatisfiable) {
		return 20;
	}*/
	return 0;
}

