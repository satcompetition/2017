
template<typename T>
extern MPI_Datatype MPIx_primitive;

template<>
MPI_Datatype MPIx_primitive<int> = MPI_INT;

template<>
MPI_Datatype MPIx_primitive<unsigned int> = MPI_UNSIGNED;

template<>
MPI_Datatype MPIx_primitive<long> = MPI_LONG;

template<>
MPI_Datatype MPIx_primitive<unsigned long> = MPI_UNSIGNED_LONG;

template<>
MPI_Datatype MPIx_primitive<long long> = MPI_LONG_LONG;

// --------------------------------------------------------
// Send/receive single element functions
// --------------------------------------------------------

template<typename T>
void MPIx_Send_single(const T &value, MPI_Datatype datatype,
		int dest, int tag, MPI_Comm comm = MPI_COMM_WORLD) {
	MPI_Send(const_cast<T *>(&value), 1, datatype, dest, tag, comm);
}

template<typename T>
T MPIx_Recv_single(MPI_Datatype datatype, int source, int tag, MPI_Comm comm = MPI_COMM_WORLD) {
	T buffer;
	MPI_Recv(&buffer, 1, datatype, source, tag, comm, MPI_STATUS_IGNORE);
	return buffer;
}

// --------------------------------------------------------
// Send/receive vector functions
// --------------------------------------------------------

template<typename T>
void MPIx_Send_vector(const std::vector<T> &vector, MPI_Datatype datatype,
		int dest, int tag, MPI_Comm comm = MPI_COMM_WORLD) {
	MPI_Send(const_cast<T *>(vector.data()), vector.size(), datatype, dest, tag, comm);
}

template<typename T>
std::vector<T> MPIx_Recv_vector(MPI_Datatype datatype, int source, int tag, MPI_Comm comm = MPI_COMM_WORLD) {
	MPI_Status status;
	MPI_Probe(source, tag, comm, &status);

	int count;
	MPI_Get_count(&status, datatype, &count);

	std::vector<T> vector;
	vector.resize(count);
	MPI_Recv(vector.data(), count, datatype, source, tag, comm, MPI_STATUS_IGNORE);
	return vector;
}

// --------------------------------------------------------
// Send/receive serialized functions
// --------------------------------------------------------

template<typename S, typename Functor, typename Iterator>
void MPIx_Serialize_multiple(Functor functor, Iterator begin, Iterator end, MPI_Datatype datatype,
		int dest, int tag, MPI_Comm comm = MPI_COMM_WORLD) {
	std::vector<S> vector;
	for(auto it = begin; it != end; it++)
		vector.push_back(functor(*it));
	
	MPIx_Send_vector(vector, datatype, dest, tag, comm);
}

template<typename S, typename Functor>
void MPIx_Deserialize_multiple(Functor functor, MPI_Datatype datatype,
		int source, int tag, MPI_Comm comm = MPI_COMM_WORLD) {
	auto vector = MPIx_Recv_vector<S>(datatype, source, tag, comm);

	for(auto it = vector.begin(); it != vector.end(); ++it)
		functor(*it);
}

// --------------------------------------------------------
// Polling send/receive vector functions
// --------------------------------------------------------

template<typename T, typename IdleFunctor>
void MPIx_Poll_send_vector(const std::vector<T> &vector, int dest, int tag,
		IdleFunctor idle_functor, MPI_Datatype datatype = MPIx_primitive<T>, MPI_Comm comm = MPI_COMM_WORLD) {
	MPI_Request request;
	MPI_Isend(const_cast<T *>(vector.data()), vector.size(), datatype, dest, tag, comm, &request);

	int completed;
	do {
		idle_functor();
		MPI_Test(&request, &completed, MPI_STATUS_IGNORE);
	} while(!completed);
}

template<typename T, typename IdleFunctor>
std::vector<T> MPIx_Poll_recv_vector(int source, int tag,
		IdleFunctor idle_functor, MPI_Datatype datatype = MPIx_primitive<T>, MPI_Comm comm = MPI_COMM_WORLD) {
	int completed;
	MPI_Status status;

	do {
		idle_functor();
		MPI_Iprobe(source, tag, comm, &completed, &status);
	} while(!completed);

	int count;
	MPI_Get_count(&status, datatype, &count);

	std::vector<T> vector;
	vector.resize(count);
	MPI_Recv(vector.data(), count, datatype, source, tag, comm, MPI_STATUS_IGNORE);
	return vector;
}

template<typename S, typename Functor, typename Iterator, typename IdleFunctor>
void MPIx_Poll_serialize_multiple(Functor functor, Iterator begin, Iterator end, int dest, int tag,
		IdleFunctor idle_functor, MPI_Datatype datatype = MPIx_primitive<S>, MPI_Comm comm = MPI_COMM_WORLD) {
	std::vector<S> vector;
	for(auto it = begin; it != end; it++)
		vector.push_back(functor(*it));
	
	MPIx_Poll_send_vector(vector, dest, tag, idle_functor, datatype, comm);
}

template<typename S, typename Functor, typename IdleFunctor>
void MPIx_Poll_deserialize_multiple(Functor functor, int source, int tag,
		IdleFunctor idle_functor, MPI_Datatype datatype = MPIx_primitive<S>, MPI_Comm comm = MPI_COMM_WORLD) {
	auto vector = MPIx_Poll_recv_vector<S>(source, tag, idle_functor, datatype, comm);

	for(auto it = vector.begin(); it != vector.end(); ++it)
		functor(*it);
}

// --------------------------------------------------------
// Async send/receive functions
// --------------------------------------------------------

class MPIx_Hub {
public:
	typedef std::pair<void *, void (*) (void *, MPI_Status)> Callback;

	inline void watch(MPI_Request request, Callback callback) {
		p_requests.push_back(request);
		p_callbacks.push_back(callback);
	}

	inline void process() {
		assert(p_requests.size() == p_callbacks.size());
		if(p_requests.size() == 0)
			return;
		p_indices.resize(p_requests.size());
		p_status.resize(p_requests.size());

		int num_completed;
		MPI_Testsome(p_requests.size(), p_requests.data(),
				&num_completed, p_indices.data(), p_status.data());
		assert(num_completed != MPI_UNDEFINED);
		if(num_completed == 0)
			return;
		
		// invoke callbacks
		for(int i = 0; i < num_completed; i++) {
			int k = p_indices[i];
			p_callbacks[k].second(p_callbacks[k].first, p_status[i]);
		}
		
		// collect garbage
		auto request_ptr = p_requests.begin();
		auto callback_ptr = p_callbacks.begin();
		for(int i = 0; i < p_requests.size(); i++) {
			if(p_requests[i] == MPI_REQUEST_NULL)
				continue;
			*request_ptr = p_requests[i];
			*callback_ptr = p_callbacks[i];
			request_ptr++;
			callback_ptr++;
		}
		p_requests.erase(request_ptr, p_requests.end());
		p_callbacks.erase(callback_ptr, p_callbacks.end());
	}

private:
	std::vector<MPI_Request> p_requests;
	std::vector<Callback> p_callbacks;
	std::vector<int> p_indices;
	std::vector<MPI_Status> p_status;
};

template<typename T>
void MPIx_Isend_single(const T *buffer, MPIx_Hub &hub, MPIx_Hub::Callback callback,
		int dest, int tag, MPI_Datatype datatype = MPIx_primitive<T>,
		MPI_Comm comm = MPI_COMM_WORLD) {
	MPI_Request request;
	MPI_Isend(const_cast<T *>(buffer), 1, datatype, dest, tag, comm, &request);
	hub.watch(request, callback);
}

template<typename T>
void MPIx_Isend_vector(const std::vector<T> *buffer, MPIx_Hub &hub, MPIx_Hub::Callback callback,
		int dest, int tag, MPI_Datatype datatype = MPIx_primitive<T>,
		MPI_Comm comm = MPI_COMM_WORLD) {
	MPI_Request request;
	MPI_Isend(const_cast<T *>(buffer->data()), buffer->size(), datatype, dest, tag, comm, &request);
	hub.watch(request, callback);
}

template<typename T>
std::experimental::optional<std::pair<T, int>> MPIx_Irecv_single(int source, int tag,
		MPI_Datatype datatype = MPIx_primitive<T>, MPI_Comm comm = MPI_COMM_WORLD) {
	int success;
	MPI_Status status;
	MPI_Iprobe(source, tag, comm, &success, &status);
	if(!success)
		return std::experimental::nullopt;

	T result;
	MPI_Recv(&result, 1, datatype, status.MPI_SOURCE, tag, comm, MPI_STATUS_IGNORE);
	return std::make_pair(result, status.MPI_SOURCE);
}

