
enum MsgTags {
	kTagNone,

	// sent by the offloader, received by the server
	kTagCommand,
	kTagCmdArgument,
	// sent by the server, received by the offloader
	kTagCmdResult,
	
	kTagSplitLocalTrail,
	kTagSplitGlobalTrail,
	kTagSplitResult,
	kTagSplitValues,
	kTagSplitFailed
};

enum Commands {
	kCmdNone,

	kCmdCancelServer,
	
	kCmdEnterNode,
	kCmdLeaveChild,

	kCmdSplit,
	kCmdSolve,
	kCmdRequestInterrupt,
	kCmdShutdownWorker,
	
	kCmdCompleteSplit,
	kCmdTerminateSplit,

	kCmdProgress,
	kCmdInterruptSolve,
	kCmdCompleteSolve,
	kCmdTerminateSolve,

	kCmdSatisfied,
	kCmdUnsatisfiable,
	kCmdTerminateSuite,

	kReqQueryBranch,
};

namespace msg {
	struct Command {
		static MPI_Datatype commit() {
			constexpr int n = 2;
			std::array<int, n> blocks = { 1, 1 };
			std::array<MPI_Aint, n> offsets = {
				offsetof(Command, opcode),
				offsetof(Command, peer)
			};
			std::array<MPI_Datatype, n> types = {
				MPIx_primitive<uint32_t>,
				MPIx_primitive<uint32_t>
			};

			MPI_Datatype datatype;
			MPI_Type_create_struct(n, blocks.data(), offsets.data(), types.data(), &datatype);
			MPI_Type_commit(&datatype);
			return datatype;
		}

		int opcode;
		int peer;
	};
}

struct LinkMsgStruct {
	static MPI_Datatype commit() {
		MPI_Datatype datatype;
		MPI_Type_contiguous(2, MPI_INT, &datatype);
		MPI_Type_commit(&datatype);
		return datatype;
	}

	LinkMsgStruct() = default;

	LinkMsgStruct(std::pair<int, int> link)
	: link(link) { }
	
	std::pair<int, int> link;
};

struct BranchMsgStruct {
	static MPI_Datatype commit() {
		constexpr int n = 1;
		std::array<int, n> blocks = { 1 };
		std::array<MPI_Aint, n> offsets = {
			offsetof(BranchMsgStruct, numClauses)
		};
		std::array<MPI_Datatype, n> types = {
			MPIx_primitive<uint32_t>,
		};

		MPI_Datatype datatype;
		MPI_Type_create_struct(n, blocks.data(), offsets.data(), types.data(), &datatype);
		MPI_Type_commit(&datatype);
		return datatype;
	}

	BranchMsgStruct() = default;

	BranchMsgStruct(uint32_t num_clauses)
	: numClauses(num_clauses) { }

	uint32_t numClauses;
};

struct SplitValueMsgStruct {
	static MPI_Datatype commit() {
		constexpr int n = 2;
		std::array<int, n> blocks = { 1, 1 };
		std::array<MPI_Aint, n> offsets = {
				offsetof(SplitValueMsgStruct, literal),
				offsetof(SplitValueMsgStruct, value)
			};
		std::array<MPI_Datatype, n> types = {
				MPIx_primitive<uint32_t>,
				MPIx_primitive<int64_t>
			};

		MPI_Datatype datatype, resized;
		MPI_Type_create_struct(n, blocks.data(), offsets.data(), types.data(), &datatype);
		MPI_Type_create_resized(datatype, 0, sizeof(SplitValueMsgStruct), &resized);
		MPI_Type_commit(&resized);
		return resized;
	}

	uint32_t literal;
	int64_t value;
};

