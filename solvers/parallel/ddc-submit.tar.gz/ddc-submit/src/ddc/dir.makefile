
$c_SRCDIR := $(TREE_PATH)/$c/src
$c_GENDIR := $(BUILD_PATH)/$c/gen
$c_BINDIR := $(BUILD_PATH)/$c/bin

$c_SOURCES := $($c_SRCDIR)/main.cpp

.PHONY: all-$c clean-$c

$c_TARGETS := all-$c all-$c.asan all-$c.tsan clean-$c $($c_BINDIR)/satUZK-ddc $($c_BINDIR)

all-$c: $($c_BINDIR)/satUZK-ddc
all-$c.asan: $($c_BINDIR)/satUZK-ddc.asan
all-$c.tsan: $($c_BINDIR)/satUZK-ddc.tsan

clean-$c:
	rm -f $($d_BINDIR)/satUZK-ddc $($d_BINDIR)/satUZK-ddc.d

$($c_BINDIR) $($c_GENDIR) $(BUILD_PATH)/common/gen:
	mkdir -p $@

$c_INCLUDES := -I$(TREE_PATH)/lib/include -I$(TREE_PATH)/common/include
$c_INCLUDES += -I$(BUILD_PATH)/common/gen

$c_CXXFLAGS := $($c_INCLUDES)
$c_CXXFLAGS += -std=c++14 -O3 -pthread
$c_CXXFLAGS += -DCONFIG_HEADER=\"$(BUILD_PATH)/Config.hpp\"
$c_CXXFLAGS += -static-libgcc -static-libstdc++

$c_LDFLAGS := $(LDFLAGS)
$c_LIBS := -lmpi -lboost_fiber -lboost_context

$($c_BINDIR)/satUZK-ddc: $($c_SOURCES) | $($c_BINDIR)
	$(TREE_PATH)/mkconfig.sh $(TREE_PATH) release
	$(CXX) -o $@ $($d_CXXFLAGS) $($d_LDFLAGS) $($d_SOURCES) $($d_LIBS)
	$(CXX) $($d_CXXFLAGS) -MM -MP -MF $@.d -MT "$@" -MT "$@d" $<

$($c_BINDIR)/satUZK-ddc.asan: $($c_SOURCES) | $($c_BINDIR)
	$(TREE_PATH)/mkconfig.sh $(TREE_PATH) release
	$(CXX) -o $@ $($d_CXXFLAGS) -g -fsanitize=address,undefined $($d_LDFLAGS) $($d_SOURCES) $($d_LIBS)
	$(CXX) $($d_CXXFLAGS) -MM -MP -MF $@.d -MT "$@" -MT "$@d" $<

$($c_BINDIR)/satUZK-ddc.tsan: $($c_SOURCES) | $($c_BINDIR)
	$(TREE_PATH)/mkconfig.sh $(TREE_PATH) release
	$(CXX) -o $@ $($d_CXXFLAGS) -g -fsanitize=thread,undefined $($d_LDFLAGS) $($d_SOURCES) $($d_LIBS)
	$(CXX) $($d_CXXFLAGS) -MM -MP -MF $@.d -MT "$@" -MT "$@d" $<

-include $($c_BINDIR)/satUZK-ddc.d
-include $($c_BINDIR)/satUZK-ddc.asan.d
-include $($c_BINDIR)/satUZK-ddc.tsan.d

