
#include <unistd.h>
#include <type_traits>
#include <algorithm>
#include <array>
#include <memory>
#include <vector>
#include <map>
#include <unordered_map>
#include <queue>
#include <string>
#include <iostream>
#include <fstream>
#include <sstream>
#include <iomanip>
#include <random>
#include <stdexcept>
#include <cstring>
#include <csignal>
#include <cassert>

#include <satuzk/All.hpp>
#include <ipasir.h>

#ifdef TRACE_IPASIR
#define DO_TRACE_ENTER() do { std::cout << "Entering " << __func__ << std::endl; } while(0)
#define DO_TRACE_LEAVE() do { std::cout << "Leaving " << __func__ << std::endl; } while(0)
#else
#define DO_TRACE_ENTER() do { } while(0)
#define DO_TRACE_LEAVE() do { } while(0)
#endif

class IpasirStruct {
public:
	typedef satuzk::DefaultDefs Defs;
	typedef satuzk::Solver<Defs> Solver;
	typedef satuzk::LiteralType<Defs> Literal;

	IpasirStruct() : p_solver(satuzk::HookStruct<Defs>(), 0),
			p_context(nullptr), p_callback(nullptr) { }

	void addLiteral(Literal literal) {
		while(literal.variable().getIndex() >= p_solver.numVariables())
			p_solver.varAlloc();

		p_clause.push_back(literal);
	}

	void finishClause() {
		p_solver.inputClause(p_clause.size(), p_clause.begin(), p_clause.end());
		p_clause.clear();
	}

	void assume(Literal literal) {
		while(literal.variable().getIndex() >= p_solver.numVariables())
			p_solver.varAlloc();
		
		p_assumptions.push_back(literal);
	}

	int solve() {
		p_solver.inputFinish();

		for(auto it = p_assumptions.begin(); it != p_assumptions.end(); ++it) {
			p_solver.lockVariable(it->variable());
			p_solver.assumptionEnable(*it);
		}
		
		p_solver.start();

		int return_state = 0;
		while(true) {
			satuzk::SolveState state = search(p_solver);
			
			if(state == satuzk::kStateBreak) {
				// invoke the callback and check if we should break
				if(p_callback != nullptr && p_callback(p_context) != 0)
					break;
			}else if(state == satuzk::kStateSatisfied) {
				// eagerly build a model of the formula
				p_model.clear();
				p_solver.p_extModelConfig.buildModel(p_solver, p_model);
				return_state = 10;
				break;
			}else if(state == satuzk::kStateUnsatisfiable) {
				return_state = 20;
				break;
			}else if(state == satuzk::kStateAssumptionFail) {
				// eagerly find all failed assumptions
				p_failed = satuzk::findFailedAssumptions(p_solver);
				return_state = 20;
				break;
			}else throw std::logic_error("Illegal solve state");
		}
		
		p_solver.reset();

		for(auto it = p_assumptions.begin(); it != p_assumptions.end(); ++it) {
			p_solver.unlockVariable(it->variable());
			p_solver.assumptionDisable(*it);
		}
		p_assumptions.clear();

		return return_state;
	}

	int modelValue(int literal_num) {
		auto literal = Literal::fromNumber(literal_num);
		Bool3 value = p_model[literal.variable().toNumber()];
		if(value.isTrue())
			return literal_num;
		if(value.isFalse())
			return -literal_num;
		return 0;
	}

	bool isFailed(int literal_num) {
		auto literal = Literal::fromNumber(literal_num);
		return std::find(p_failed.begin(), p_failed.end(),
				literal) != p_failed.end();
	}

	void setCallback(void *context, int (*callback)(void *)) {
		p_context = context;
		p_callback = callback;
	}

private:
	Solver p_solver;

	std::vector<Literal> p_clause;
	std::vector<Literal> p_assumptions;
	std::vector<Literal> p_failed;
	std::unordered_map<int, Bool3> p_model;
	
	void *p_context;
	int (*p_callback)(void *);
};

const char *ipasir_signature() {
	DO_TRACE_ENTER();
	return "satUZK";
}

void *ipasir_init() {
	DO_TRACE_ENTER();
	return new IpasirStruct();
}

void ipasir_release(void *solver) {
	DO_TRACE_ENTER();
	auto ipasir_struct = reinterpret_cast<IpasirStruct *>(solver);
	delete ipasir_struct;
}

void ipasir_add(void *solver, int lit_or_zero) {
	DO_TRACE_ENTER();
	auto ipasir_struct = reinterpret_cast<IpasirStruct *>(solver);
	if(lit_or_zero == 0) {
		ipasir_struct->finishClause();
	}else{
		ipasir_struct->addLiteral(IpasirStruct::Literal::fromNumber(lit_or_zero));
	}
	DO_TRACE_LEAVE();
}

void ipasir_assume(void *solver, int lit) {
	DO_TRACE_ENTER();
	auto ipasir_struct = reinterpret_cast<IpasirStruct *>(solver);
	ipasir_struct->assume(IpasirStruct::Literal::fromNumber(lit));
}

int ipasir_solve(void *solver) {
	DO_TRACE_ENTER();
	auto ipasir_struct = reinterpret_cast<IpasirStruct *>(solver);
	return ipasir_struct->solve();
}

int ipasir_val(void *solver, int literal_num) {
	DO_TRACE_ENTER();
	auto ipasir_struct = reinterpret_cast<IpasirStruct *>(solver);
	return ipasir_struct->modelValue(literal_num);
}

int ipasir_failed(void *solver, int literal_num) {
	DO_TRACE_ENTER();
	auto ipasir_struct = reinterpret_cast<IpasirStruct *>(solver);
	return ipasir_struct->isFailed(literal_num);
}

void ipasir_set_terminate(void *solver, void *context, int (*callback)(void *context)) {
	DO_TRACE_ENTER();
	auto ipasir_struct = reinterpret_cast<IpasirStruct *>(solver);
	ipasir_struct->setCallback(context, callback);
}

