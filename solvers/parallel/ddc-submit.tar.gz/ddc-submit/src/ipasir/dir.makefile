
$c_SRCDIR := $(TREE_PATH)/$c/src
$c_OBJDIR := $(BUILD_PATH)/$c/obj
$c_BINDIR := $(BUILD_PATH)/$c/bin

$c_OBJECTS := ipasir.o
$c_OBJECT_PATHS := $(addprefix $($c_OBJDIR)/,$($c_OBJECTS))

$c_TARGETS := all-$c clean-$c $($c_BINDIR)/ipasir.a $($c_OBJDIR)/%.o \
		$($c_OBJDIR) $($c_BINDIR)

.PHONY: all-$c clean-$c

all-$c: $($c_BINDIR)/ipasir.a

clean-$c:
	rm -f $($d_BINDIR)/ipasir.a $($d_OBJECT_PATHS) $($d_OBJECT_PATHS:%.o=%.d)

$($c_OBJDIR) $($c_BINDIR):
	mkdir -p $@

$c_INCLUDES := -I$(TREE_PATH)/common/include -I$(TREE_PATH)/$c/include

$c_CXXFLAGS := $(CXXFLAGS) $($c_INCLUDES)
$c_CXXFLAGS += -std=c++11

$($c_BINDIR)/ipasir.a: $($c_OBJECT_PATHS) | $($c_BINDIR)
	ar rc $@ $($d_OBJECT_PATHS)
	ranlib $@

$($c_OBJDIR)/%.o: $($c_SRCDIR)/%.cpp | $($c_OBJDIR)
	$(CXX) -c -o $@ $($d_CXXFLAGS) $<
	$(CXX) $($d_CXXFLAGS) -MM -MP -MF $(@:%.o=%.d) -MT "$@" -MT "$(@:%.o=%.d)" $<

-include $($c_OBJECT_PATHS:%.o=%.d)

