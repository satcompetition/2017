
#include <assert.h>

#include <vector>

namespace satuzk {
namespace vars {

template<typename... PT>
struct WatchlistEntryStruct {
	typedef LiteralId<PT...> LiteralIdType;
	typedef ClauseId<PT...> ClauseIdType;

private:
	struct BinaryTag { };
	struct ClauseTag { };

	static const uint32_t kTypeMask = 0x80000000;
	static const uint32_t kTypeClause = 0;
	static const uint32_t kTypeBinary = 0x80000000;

public:
	static WatchlistEntryStruct makeClause(ClauseIdType clause, LiteralIdType blocking) {
		return WatchlistEntryStruct(ClauseTag(), clause, blocking);
	}
	static WatchlistEntryStruct makeBinary(ClauseIdType clause, LiteralIdType implied) {
		return WatchlistEntryStruct(BinaryTag(), clause, implied);
	}

	WatchlistEntryStruct() : _field1(0), _field2(0) { }

private:
	// This function is in the CDCL hot path.
	WatchlistEntryStruct(ClauseTag, ClauseIdType clause, LiteralIdType blocking)
	: _field1(blocking.getIndex() | kTypeClause), _field2(clause.getIndex()) {
		if(kDbgSlowAssertions)
			assert(!(blocking.getIndex() & kTypeMask));
	}
	
	// This function is in the CDCL hot path.
	WatchlistEntryStruct(BinaryTag, ClauseIdType clause, LiteralIdType implied)
	: _field1(implied.getIndex() | kTypeBinary), _field2(clause.getIndex()) {
		if(kDbgSlowAssertions)
			assert(!(implied.getIndex() & kTypeMask));
	}

public:
	bool isClause() {
		return (_field1 & kTypeMask) == kTypeClause;
	}
	// This function is in the CDCL hot path.
	bool isBinary() {
		return (_field1 & kTypeMask) == kTypeBinary;
	}

	ClauseIdType getClause() {
		return ClauseIdType::fromIndex(_field2);
	}
	// This function is in the CDCL hot path.
	LiteralIdType getBlocking() {
		return LiteralIdType::fromIndex(_field1 & ~kTypeMask);
	}

	LiteralIdType getImplied() {
		if(kDbgSlowAssertions)
			assert(isBinary());
		return LiteralIdType::fromIndex(_field1 & ~kTypeMask);
	}

	void setClause(ClauseIdType clause) {
		_field2 = clause.getIndex();
	}

private:
	// Stores the implied literal for binary entries.
	// Stores the blocking literal for clause entries.
	// The high bits store this entry's type.
	uint32_t _field1;
	// Stores the clause for all entries.
	uint32_t _field2;
};

template<typename... PT>
class WatchlistStruct {
public:
	typedef WatchlistEntryStruct<PT...> Entry;

	typedef util::vectors::simple<Entry> EntryVector;
	typedef typename EntryVector::iterator iterator;

	WatchlistStruct() : p_vector() { }
	WatchlistStruct(WatchlistStruct &&other)
		: p_vector(std::move(other.p_vector)) { }
	WatchlistStruct(const WatchlistStruct &) = delete;
	void operator= (const WatchlistStruct &) = delete;

	typename EntryVector::size_type size() {
		return p_vector.size();
	}
	void insert(Entry entry) {
		p_vector.push_back(entry);
	}
	void erase(iterator it) {
		iterator end = p_vector.end();
		--end;
		*it = *end;
		p_vector.pop_back();
	}
	iterator begin() {
		return p_vector.begin();
	}
	iterator end() {
		return p_vector.end();
	}
	void cutoff(iterator after) {
		p_vector.resize(p_vector.index_of(after));
	}
	void clear() {
		p_vector.clear();
	}

private:
	EntryVector p_vector;
};

template<typename... PT>
class VariableSpaceStruct {
public:
	typedef Index<PT...> IndexType;
	typedef VariableId<PT...> VariableIdType;
	typedef LiteralId<PT...> LiteralIdType;

	typedef ClauseId<PT...> ClauseIdType;
	typedef DecisionLevel<PT...> DecisionLevelType;
	typedef Antecedent<PT...> AntecedentType;
	
	typedef Hooks<PT...> HooksType;
	
	typedef uint8_t Flags;
	static const Flags kVarflagDeleted = 0x1;
	static const Flags kVarflagSavedOne = 0x2;
	// true iff the variable must not be eliminted
	static const Flags kVarflagLocked = 0x4;
	// true iff the variable is currently being restored
	// and should not be re-eliminated
	static const Flags kVarflagRestore = 0x8;
	// true iff the variable does not retain its original meaning
	// e.g. the variable was partially eliminated through blocked clause elimination
	static const Flags kVarflagRecoded = 0x10;
	static const Flags kVarflagStamp = 0x20;

	static const Flags kLitflagMarked = 2;
	// true if the literal is an assumption
	// (i.e. must be set to true before all other decisions)
	static const Flags kLitflagAssumption = 4;

	struct VariableRef;
	struct LiteralRef;

	struct Iterator {
		Iterator(VariableSpaceStruct *space, IndexType index)
		: _space(space), _index(index) { }

		void operator++ () {
			_index++;
		}
		bool operator== (const Iterator &other) {
			return _index == other._index;
		}
		bool operator!= (const Iterator &other) {
			return !(*this == other);
		}
		bool operator < (const Iterator &other) {
			return _index < other._index;
		}

		Iterator operator+ (int offset) {
			return Iterator(_index + offset);
		}
		void operator+= (int offset) {
			_index += offset;
		}

		VariableRef operator* () const {
			return VariableRef(*_space, VariableIdType::fromIndex(_index));
		}
		ArrowProxy<VariableRef> operator-> () const {
			return ArrowProxy<VariableRef>(**this);
		}

	private:
		VariableSpaceStruct *_space;
		IndexType _index;
	};

	class VariableRef {
	public:
		VariableRef()
		: _space(nullptr) { }

		VariableRef(VariableSpaceStruct &space, VariableIdType id)
		: _space(&space), _id(id) { }

		explicit operator bool () {
			return _space;
		}

		VariableSpaceStruct &space() const {
			return *_space;
		}

		VariableIdType id() const {
			return _id;
		}

		bool operator== (const VariableRef &other) const {
			return _id == other._id;
		}
		bool operator!= (const VariableRef &other) const {
			return !(*this == other);
		}

		IndexType getIndex() const {
			return _id.getIndex();
		}
		int64_t toNumber() const {
			return _id.toNumber();
		}

		LiteralRef positive() const {
			return LiteralRef(*_space, _id.oneLiteral());
		}
		LiteralRef negative() const {
			return LiteralRef(*_space, _id.zeroLiteral());
		}

		bool isProtected() const {
			return _space->getVarFlagLocked(_id);
		}

		bool isPresent() const {
			return _space->isPresent(_id);
		}
		void erase() const {
			assert(!_space->getVarFlagLocked(_id));
			assert(_space->isPresent(_id));
			_space->deleteVar(_id);
		}

		void stamp(unsigned int value) {
			assert(value <= 1);
			_space->p_varflags[getIndex()] &= ~kVarflagStamp;
			_space->p_varflags[getIndex()] |= (value ? kVarflagStamp : 0);
		}
		unsigned int getStamp() {
			return !!(_space->p_varflags[getIndex()] & kVarflagStamp);
		}

	private:
		VariableSpaceStruct *_space;
		VariableIdType _id;
	};

	class LiteralRef {
	public:
		LiteralRef()
		: _space(nullptr) { }

		LiteralRef(VariableSpaceStruct &space, LiteralIdType id)
		: _space(&space), _id(id) { }

		explicit operator bool () {
			return _space;
		}

		VariableSpaceStruct &space() const {
			return *_space;
		}

		LiteralIdType id() const {
			return _id;
		}

		bool operator== (const LiteralRef &other) {
			return _id == other._id;
		}
		bool operator!= (const LiteralRef &other) {
			return !(*this == other);
		}

		IndexType getIndex() const {
			return _id.getIndex();
		}
		int64_t toNumber() const {
			return _id.toNumber();
		}

		int polarity() const {
			return _id.polarity();
		}

		VariableRef variable() const {
			return VariableRef(*_space, _id.variable());
		}
		LiteralRef inverse() const {
			return LiteralRef(*_space, _id.inverse());
		}

	private:
		VariableSpaceStruct *_space;
		LiteralIdType _id;
	};

	typedef WatchlistEntryStruct<PT...> WatchlistEntry;
	typedef WatchlistStruct<PT...> Watchlist;
	typedef typename Watchlist::iterator WatchIterator;

	//TODO: replace with better assertions!
	//static_assert(std::is_trivial<AssignInfo>::value, "assignment info not trivial");
	//static_assert(std::is_trivial<AntecedentType>::value, "antecedent not trivial");
	//static_assert(std::is_trivial<WatchlistEntry>::value, "watchlist entry not trivial");

	VariableSpaceStruct(HooksType hooks)
	: _hooks(std::move(hooks)), p_presentCount(0), p_watchSize(0), _watchesDirty(false) { }

	void reserveVars(IndexType count) {
		p_varflags.reserve(count);
		p_litflags.reserve(2 * count);
		p_watchlists.reserve(2 * count);
	}

	VariableIdType allocVar() {
		IndexType index = p_varflags.size();
		assert(p_watchlists.size() == 2 * index);
		
		Flags initial_flags = 0;

		Flags initial_litflags1 = 0;
		Flags initial_litflags2 = 0;
		Watchlist initial_watchlist1;
		Watchlist initial_watchlist2;

		p_varflags.push_back(initial_flags);

		p_litflags.push_back(initial_litflags1);
		p_litflags.push_back(initial_litflags2);
		p_watchlists.emplace_back(std::move(initial_watchlist1));
		p_watchlists.emplace_back(std::move(initial_watchlist2));

		_hooks.onResize(p_varflags.size());
		_hooks.onAllocate(VariableRef(*this, VariableIdType::fromIndex(index)));

		p_presentCount++;
		return VariableIdType::fromIndex(index);
	}
	
	void deleteVar(VariableIdType var) {
		p_varflags[var.getIndex()] |= kVarflagDeleted;
		p_presentCount--;

		_hooks.onErase(VariableRef(*this, var));
	}
	void undeleteVar(VariableIdType var) {
		p_varflags[var.getIndex()] &= ~kVarflagDeleted;
		p_presentCount++;
	}

	IndexType count() {
		return p_varflags.size();
	}
	IndexType presentCount() {
		return p_presentCount;
	}
	bool isPresent(VariableIdType var) {
		return !(p_varflags[var.getIndex()] & kVarflagDeleted);
	}

	Iterator begin() {
		return Iterator(this, 0);
	}

	Iterator end() {
		return Iterator(this, p_varflags.size());
	}

	// -----------------------------------------------------------------
	// flag related functions
	// -----------------------------------------------------------------
	
	bool getVarFlagSaved(VariableIdType var) { return p_varflags[var.getIndex()] & kVarflagSavedOne; }
	void setVarFlagSaved(VariableIdType var) { p_varflags[var.getIndex()] |= kVarflagSavedOne; }
	void clearVarFlagSaved(VariableIdType var) { p_varflags[var.getIndex()] &= ~kVarflagSavedOne; }
	
	Flags getVarFlagLocked(VariableIdType var) { return p_varflags[var.getIndex()] & kVarflagLocked; }
	void setVarFlagLocked(VariableIdType var) { p_varflags[var.getIndex()] |= kVarflagLocked; }
	void clearVarFlagLocked(VariableIdType var) { p_varflags[var.getIndex()] &= ~kVarflagLocked; }
	
	Flags getVarFlagRestore(VariableIdType var) { return p_varflags[var.getIndex()] & kVarflagRestore; }
	void setVarFlagRestore(VariableIdType var) { p_varflags[var.getIndex()] |= kVarflagRestore; }
	void clearVarFlagRestore(VariableIdType var) { p_varflags[var.getIndex()] &= ~kVarflagRestore; }
	
	Flags getVarFlagRecoded(VariableIdType var) { return p_varflags[var.getIndex()] & kVarflagRecoded; }
	void setVarFlagRecoded(VariableIdType var) { p_varflags[var.getIndex()] |= kVarflagRecoded; }
	void clearVarFlagRecoded(VariableIdType var) { p_varflags[var.getIndex()] &= ~kVarflagRecoded; }

	bool getLitFlagMarked(LiteralIdType lit) { return p_litflags[lit.getIndex()] & kLitflagMarked; }
	void setLitFlagMarked(LiteralIdType lit) { p_litflags[lit.getIndex()] |= kLitflagMarked; }
	void clearLitFlagMarked(LiteralIdType lit) { p_litflags[lit.getIndex()] &= ~kLitflagMarked; }
	
	bool getLitFlagAssumption(LiteralIdType lit) { return p_litflags[lit.getIndex()] & kLitflagAssumption; }
	void setLitFlagAssumption(LiteralIdType lit) { p_litflags[lit.getIndex()] |= kLitflagAssumption; }
	void clearLitFlagAssumption(LiteralIdType lit) { p_litflags[lit.getIndex()] &= ~kLitflagAssumption; }

	// -----------------------------------------------------------------
	// watchlist related functions
	// -----------------------------------------------------------------

	unsigned int watchOverallSize() {
		return p_watchSize;
	}
	void watchInsert(LiteralIdType literal, WatchlistEntry entry) {
		Watchlist &watchlist = p_watchlists[literal.getIndex()];
		watchlist.insert(entry);
		p_watchSize++;
	}
	unsigned int watchSize(LiteralIdType literal) {
		Watchlist &watch_list = p_watchlists[literal.getIndex()];
		return watch_list.size();
	}
	WatchIterator watchBegin(LiteralIdType literal) {
		Watchlist &watch_list = p_watchlists[literal.getIndex()];
		return watch_list.begin();
	}
	WatchIterator watchEnd(LiteralIdType literal) {
		Watchlist &watch_list = p_watchlists[literal.getIndex()];
		return watch_list.end();
	}
	void watchCut(LiteralIdType literal, WatchIterator it) {
		Watchlist &watch_list = p_watchlists[literal.getIndex()];
		p_watchSize -= watch_list.end() - it;
		watch_list.cutoff(it);
	}
	void watchErase(LiteralIdType literal, WatchIterator it) {
		Watchlist &watch_list = p_watchlists[literal.getIndex()];
		watch_list.erase(it);
		p_watchSize--;
	}
	void watchClear(LiteralIdType literal) {
		Watchlist &watch_list = p_watchlists[literal.getIndex()];
		p_watchSize -= watch_list.size();
		watch_list.clear();
	}

	void markWatchesDirty() {
		_watchesDirty = true;
	}

	bool areWatchesDirty() {
		return _watchesDirty;
	}

	template<typename ClauseSpace>
	void cleanWatches(ClauseSpace *space) {
		if(!_watchesDirty)
			return;

		for(auto wit = p_watchlists.begin(); wit != p_watchlists.end(); ++wit) {
			auto cit = wit->begin();
			for(auto it = wit->begin(); it != wit->end(); ++it) {
				typename ClauseSpace::ClauseRef clause{*space, it->getClause()};
				if(!clause.isPresent() || clause.isFrozen())
					continue;
				assert(clause.isPresent());
				*cit++ = *it;
			}
			wit->cutoff(cit);
		}
		_watchesDirty = false;
	}

private:
	// per variable configuration
	std::vector<Flags> p_varflags;
	std::vector<Flags> p_litflags;
	std::vector<Watchlist> p_watchlists;

	HooksType _hooks;

	IndexType p_presentCount;
	unsigned int p_watchSize;
	bool _watchesDirty;
};

} } // namespace satuzk::vars

