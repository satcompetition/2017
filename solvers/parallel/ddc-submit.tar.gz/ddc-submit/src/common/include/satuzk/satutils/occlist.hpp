
#include <algorithm>

namespace satuzk {
namespace satutils {

template<typename... PT>
struct OcclistsStruct {
public:
	typedef Atom<PT...> AtomType;
	typedef ConstraintId<PT...> ConstraintIdType;
	typedef ConstraintSpace<PT...> ConstraintSpaceType;
	typedef ConstraintRef<PT...> ConstraintRefType;

private:
	typedef std::vector<ConstraintIdType> ConstraintVectorType;

public:
	// We store an atom + index to ensure that the iterator is not invalidated
	// when clauses are added to the occlists.
	struct Iterator {
		Iterator(OcclistsStruct *occlists, AtomType atom, size_t index)
		: _occlists{occlists}, _atom{atom}, _index{index} { }

		bool operator== (const Iterator &other) {
			return _index == other._index;
		}
		bool operator!= (const Iterator &other) {
			return !(*this == other);
		}

		ConstraintRefType operator* () {
			return ConstraintRefType{*_occlists->_constraintSpace,
					_occlists->_perAtomList[_atom.getIndex()][_index]};
		}
		Iterator &operator++ () {
			++_index;
			return *this;
		}

		ArrowProxy<ConstraintRefType> operator-> () {
			return ArrowProxy<ConstraintRefType>(**this);
		}

	private:
		OcclistsStruct *_occlists;
		AtomType _atom;
		size_t _index;
	};

	OcclistsStruct(ConstraintSpaceType &constraint_space)
	: _constraintSpace(&constraint_space), _maintain(false), _dirty(false), _numStored(0), _numErased(0) { }

	void resizeAtoms(size_t num_atoms) {
		_perAtomList.resize(num_atoms);
	}

	void construct() {
		assert(!_maintain);

		assert(!_numStored && !_numErased);
		_constraintSpace->forEach([&] (ConstraintRefType clause) {
			for(auto atom_it = clause.beginLits(); atom_it != clause.endLits(); ++atom_it) {
				_perAtomList[atom_it->getIndex()].push_back(clause.id());
				_numStored++;
			}
		});

		_maintain = true;
	}

	void destruct() {
		assert(_maintain);

		// TODO: call shrink_to_fit() here?
		for(auto it = _perAtomList.begin(); it != _perAtomList.end(); ++it)
			it->clear();
		_numStored = 0;
		_numErased = 0;

		_maintain = false;
	}

	// rebuilds the occurrence lists, e.g. after constraints have been renumbered
	void rebuild() {
		if(!_maintain)
			return;

		for(auto it = _perAtomList.begin(); it != _perAtomList.end(); ++it)
			it->clear();
		_numStored = 0;
		_numErased = 0;

		_constraintSpace->forEach([&] (ConstraintRefType clause) {
			if(!clause.isPresent())
				return;
			for(auto atom_it = clause.beginLits(); atom_it != clause.endLits(); ++atom_it) {
				_perAtomList[atom_it->getIndex()].push_back(clause.id());
				_numStored++;
			}
		});
	}

	void addConstraint(ConstraintRefType ref) {
		if(!_maintain)
			return;
		
		for(auto atom_it = ref.beginLits(); atom_it != ref.endLits(); ++atom_it) {
			auto &vector = _perAtomList[atom_it->getIndex()];
//			auto it = std::find(vector.begin(), vector.end(), ref.id());
//			assert(it == vector.end()); // TODO: this is a costly assertion
			vector.push_back(ref.id());
			_numStored++;
		}
	}

	void removeConstraint(ConstraintRefType ref, bool urgent) {
		if(!_maintain)
			return;

		if(urgent) {
			for(auto atom_it = ref.beginLits(); atom_it != ref.endLits(); ++atom_it) {
				auto &vector = _perAtomList[atom_it->getIndex()];
				auto it = std::find(vector.begin(), vector.end(), ref.id());
				assert(it != vector.end());
				vector.erase(it);
				assert(_numStored);
				_numStored--;
			}
		}else{
			_numErased += ref.length();
			_dirty = true;
		}
	}

	Iterator begin(AtomType atom) {
		assert(_maintain);
		assert(atom.getIndex() < _perAtomList.size());
		return Iterator{this, atom, 0};
	}
	Iterator end(AtomType atom) {
		assert(_maintain);
		assert(atom.getIndex() < _perAtomList.size());
		return Iterator{this, atom, _perAtomList[atom.getIndex()].size()};
	}

	size_t size(AtomType atom) {
		assert(_maintain);
		assert(atom.getIndex() < _perAtomList.size());
		return _perAtomList[atom.getIndex()].size();
	}

	void clean() {
		if(!_dirty)
			return;

		_numStored = 0;
		_numErased = 0;

		for(auto ait = _perAtomList.begin(); ait != _perAtomList.end(); ++ait) {
			auto wit = ait->begin();
			for(auto rit = ait->begin(); rit != ait->end(); ++rit) {
				ConstraintRefType constraint{*_constraintSpace, *rit};
				if(!constraint.isPresent())
					continue;
				*wit++ = *rit;
				_numStored++;
			}
			ait->erase(wit, ait->end());
		}
		_dirty = false;
	}

	void maybeClean(int shift = 2) {
		if((_numErased << shift) > _numStored)
			clean();
	}

private:
	std::vector<ConstraintVectorType> _perAtomList;
	ConstraintSpaceType *_constraintSpace;
	bool _maintain;
	bool _dirty;

	// Number of elements that are stored in the occlists.
	uint64_t _numStored;
	// Number of elements that represent erased clauses.
	uint64_t _numErased;
};

} } // namespace satuzk::satutils

