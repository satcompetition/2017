
namespace satuzk {
namespace cdcl {

template<typename... PT>
struct PropagationStruct {
	typedef LiteralId<PT...> LiteralIdType;
	typedef ClauseRef<PT...> ClauseRefType;

	typedef Antecedent<PT...> AntecedentType;
	typedef Conflict<PT...> ConflictType;
	typedef Solver<PT...> SolverType;

	template<typename PropagationFilter>
	__attribute__((always_inline))
	static ConflictType propagateWatch(SolverType &solver, LiteralIdType literal, PropagationFilter f) {
		auto begin = solver.watchBegin(literal);
		auto end = solver.watchEnd(literal);
		auto wp = begin;
		
		//FIXME
		using Entry = typename std::remove_reference<decltype(*wp)>::type;

		for(auto rp = begin; rp != end; ++rp) {
			// TODO: Do we really need this?
//			solver.perf.searchWatchVisitOps++;

			// Try to avoid inspecting the clause.
			auto blocking = (*rp).getBlocking();
			if(LIKELY(solver.assignment.isTrue(blocking))) {
				*wp++ = *rp;
				continue;
			}

			auto clause = (*rp).getClause();
			ClauseRefType ref(solver.clauseSpace, clause);
			if(LIKELY((*rp).isBinary())) {
				if(UNLIKELY(!f.doesParticipate(ref))) {
					*wp++ = *rp;
					continue;
				}

				// Note that the implied literal equals the blocking literal.
				LiteralIdType implied = (*rp).getImplied();
				if(UNLIKELY(solver.varAssigned(implied.variable()))) {
					// We know that the implied literal is false here.
					wp = std::copy(rp, end, wp);
					solver.watchCut(literal, wp);
					return ConflictType::makeBinary(literal.inverse(), implied);
				}else{
					solver.trail.enqueue(implied, AntecedentType::makeImplication(rp->getClause(), literal));
					*wp++ = *rp;
				}
			}else{
//				ref.prefetchLits();

				// TODO: Do we really need this?
//				solver.perf.searchClauseVisitOps++;

				// Reorder the watches so that the propagated literal is the trigger literal.
				// This is the literal that we might replace during this iteration.
				// There is a subtle edge case here: We need to make sure that
				// we do not modify clauses that are already unit. Doing so would break antecedents.
				// But if the clause is unit, the propagated literal is already the trigger literal
				// (in that case the asserted literal is true and the propagated one is always false).
				auto trigger = literal.inverse();
				if(ref.triggerWatch() != trigger)
					ref.swapWatches();
				if(kDbgSlowAssertions)
					assert(ref.triggerWatch() == trigger);
				
				auto asserted = ref.assertedWatch();
				if(solver.assignment.isTrue(asserted)) {
					// The clause is SAT. we don't need to update anything.
					*wp++ = Entry::makeClause(clause, asserted);
					continue;
				}

				// This is optimized for clause structures at store watches in the first two literals.
				auto it = std::next(ref.beginLits(), 2);
				auto limit = ref.endLits();
				for( ; it != limit; ++it) {
					if(LIKELY(!solver.assignment.isFalse(*it)))
						break;
				}

				// For clause data structures that do not reorder watches we need the folowing:
//				auto it = ref.beginLits();
//				for( ; it != ref.endLits(); ++it) {
//					if(LIKELY(!solver.assignment.isFalse(*it) && it->id() != asserted))
//						break;
//				}

				if(UNLIKELY(it == limit)) {
					// We know that all literals except for the asserted literal
					// are false. The clause is either unit or conflicting.
					*wp++ = Entry::makeClause(clause, asserted);

					if(UNLIKELY(!f.doesParticipate(ref)))
						continue;

					if(UNLIKELY(solver.varAssigned(asserted.variable()))) {
						// We know that the asserted watch is false
						// Because of the isTrue() check above.
						wp = std::copy(std::next(rp), end, wp);
						solver.watchCut(literal, wp);
						return ConflictType::makeClause(clause);
					}else{
						solver.trail.enqueue(asserted, AntecedentType::makeClause(clause));
					}
				}else{
					// We found a new watched literal. The clause might still be unit
					// but that will be handled when we propagate the asserted watched literal.
					auto new_watch = it->id();
					ref.updateTriggerWatch(it);
					solver.watchInsertClause(new_watch.inverse(), asserted, clause);
				}
			}
		}
		solver.watchCut(literal, wp);

		return ConflictType();
	}
};

} } // namespace satuzk::cdcl

