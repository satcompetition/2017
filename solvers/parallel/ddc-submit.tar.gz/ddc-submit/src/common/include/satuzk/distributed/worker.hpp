
#include <queue>
#include <atomic>
#include <mutex>
#include <condition_variable>
#include <thread>

#include <mpi.h>

#include <satuzk/distributed/common.hpp>

namespace satuzk {
namespace distributed {

template<typename... PT>
struct WorkerStruct {
	static int packTag(int sender_index, int receiver_index, int actual_tag) {
		assert(sender_index < (1 << 5));
		assert(receiver_index < (1 << 5));
		assert(actual_tag < (1 << 5));
		int real_tag = (sender_index << 10) | (receiver_index << 5) | actual_tag;
		assert(real_tag < (1 << 15));
		return real_tag;
	}

	static int unpackSender(int real_tag) {
		return (real_tag >> 10) & ((1 << 5) - 1);
	}
	static int unpackReceiver(int real_tag) {
		return (real_tag >> 5) & ((1 << 5) - 1);
	}
	static int unpackActualTag(int real_tag) {
		return real_tag & ((1 << 5) - 1);
	}

	using SuiteType = SuiteStruct<PT...>;
//	using PerSuiteDataType = PerSuiteData<PT...>;

	WorkerStruct(SuiteType &suite, WorkerId id, MPI_Comm communicator)
	: suite(suite), _id(id), _communicator(communicator),
			_thread([this] () { _threadMain(); }), _shutdown(false) { }
	
	// prevent copy-construction and assignment of this class
	WorkerStruct(const WorkerStruct &) = delete;
	WorkerStruct(WorkerStruct &&) = delete;
	WorkerStruct &operator= (WorkerStruct) = delete;

	WorkerId id() {
		return _id;
	}
	
	MPI_Comm communicator() {
		return _communicator;
	}

//	PerSuiteDataType &suiteData() {
//		return suite.data();
//	}

	void shutdown(std::unique_lock<std::mutex> &lock) {
		assert(lock && lock.mutex() == &mutex);
		assert(!_shutdown.load(std::memory_order_relaxed));
		_shutdown.store(true, std::memory_order_relaxed);
		_available.notify_one();
	}

	bool inShutdown() {
		return _shutdown.load(std::memory_order_relaxed);
	}

	void join() {
		assert(_shutdown.load(std::memory_order_relaxed));
		_thread.join();
	}

	void enqueue(std::unique_lock<std::mutex> &lock, std::function<void(WorkerStruct &)> task) {
		assert(lock && lock.mutex() == &mutex);
		assert(!_shutdown.load(std::memory_order_relaxed));
		_queue.push(std::move(task));
		_available.notify_one();
	}

	int packRecvTag(int sender_index, int actual_tag) {
		return packTag(sender_index, _id.index, actual_tag);
	}
	int packRecvTag(WorkerId sender_id, int actual_tag) {
		return packRecvTag(sender_id.index, actual_tag);
	}

	int packSendTag(int receiver_index, int actual_tag) {
		return packTag(_id.index, receiver_index, actual_tag);
	}
	int packSendTag(WorkerId receiver_id, int actual_tag) {
		return packSendTag(receiver_id.index, actual_tag);
	}

	SuiteType &suite;

	std::mutex mutex;

private:
	void _threadMain() {
		std::unique_lock<std::mutex> lock(mutex);
		while(true) {
			if(!_queue.empty()) {
				auto task = std::move(_queue.front());
				_queue.pop();

				lock.unlock();
				task(*this);
				lock.lock();
			}else{
				if(_shutdown.load(std::memory_order_relaxed))
					break;
				_available.wait(lock);
			}
		}
	}

	WorkerId _id;
	MPI_Comm _communicator;
	std::thread _thread;

	std::queue<std::function<void(WorkerStruct &)>> _queue;
	std::atomic<bool> _shutdown;
	std::condition_variable _available;
};

} } // namespace satuzk::distributed

