
namespace satuzk {
namespace satutils {

template<typename... PT>
class Dump {
public:
	typedef AtomSpace<PT...> AtomSpaceType;
	typedef ConstraintSpace<PT...> ConstraintSpaceType;

	static void writeCnf(std::ostream &out, AtomSpaceType &atom_space,
			ConstraintSpaceType &constraint_space) {
		out << "p cnf " << atom_space.count()
				<< " " << constraint_space.numPresent() << "\n";

		constraint_space.forEach([&] (auto clause) {
			if(!clause.isPresent())
				return;

			for(auto a_it = clause.beginLits(); a_it != clause.endLits(); ++a_it)
				out << a_it->toNumber() << " ";
			out << "0\n";
		});
	}
};

} } // namespace satuzk::satutils

