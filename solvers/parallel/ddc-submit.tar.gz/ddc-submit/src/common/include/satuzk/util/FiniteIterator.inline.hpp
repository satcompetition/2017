
namespace satuzk {

template<typename T, size_t n>
class SeqIterator {
public:
	SeqIterator(std::array<T, n> array, size_t index)
			: _array(array), _index(index) { }

	bool operator== (const SeqIterator &other) const {
		return _index == other._index;
	}

	SeqIterator &operator++ () {
		_index++;
		return *this;
	}

	T operator* () {
		return _array[_index];
	}

private:
	std::array<T, n> _array;
	size_t _index;
};

} // namespace satuzk

