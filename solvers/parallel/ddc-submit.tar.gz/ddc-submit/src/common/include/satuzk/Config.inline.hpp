
namespace satuzk {
namespace cdcl {

template<typename... PT>
SolverStruct<PT...>::SolverStruct(HooksType hooks, int config_id)
: _hooks(hooks), p_configId(config_id),
		varSpace(VariableHooksStruct<PT...>(*this)), clauseSpace(varSpace, ClauseHooksStruct<PT...>(*this)),
		_localClauseName(1),
		trail(varSpace, TrailHooksStruct<PT...>(*this)), occlists(clauseSpace),
		currentAssignedVars(0), currentActiveClauses(0), emulation(Emulation::native) {
	p_rndEngine.seed(0x12345678);
	
	state.general.startTime = sys::hptCurrent();
	state.general.stopSolve = false; //FIXME: remove this flag
	
	state.restart.lubyCounter = 100;
	state.restart.lubyPeriod = opts.restart.lubyScale
		* lubySequence(stat.search.restarts);
	
	if(kReportEnable)
		p_reporter.open(p_configId);
}

/* --------------------- VARIABLE MANAGEMENT FUNCTIONS --------------------- */

template<typename... PT>
void SolverStruct<PT...>::varReserve(LiteralIndex<PT...> count) {
	varSpace.reserveVars(count);
}

template<typename... PT>
void SolverStruct<PT...>::undeleteVar(VariableIdType var) {
	assert(!varIsPresent(var));
	
	varSpace.undeleteVar(var);

	if(!p_vsidsConfig.isInserted(var))
		p_vsidsConfig.insertVariable(var);
};

template<typename... PT>
void SolverStruct<PT...>::randomizeVsids() {
	std::uniform_real_distribution<ActivityType> activity_dist(0, 5);
	std::bernoulli_distribution phase_dist(0.5);
	for(auto it = varSpace.begin(); it != varSpace.end(); ++it) {
		p_vsidsConfig.raiseActivity((*it).id(), activity_dist(p_rndEngine));

		if(phase_dist(p_rndEngine))
			varSpace.setVarFlagSaved((*it).id());
	}
}

template<typename... PT>
bool SolverStruct<PT...>::varIsPresent(VariableIdType var) {
	return varSpace.isPresent(var);
}

template<typename... PT>
void SolverStruct<PT...>::lockVariable(VariableIdType var) {
	assert(!varSpace.getVarFlagLocked(var));
	varSpace.setVarFlagLocked(var);
}

template<typename... PT>
void SolverStruct<PT...>::unlockVariable(VariableIdType var) {
	assert(varSpace.getVarFlagLocked(var));
	varSpace.clearVarFlagLocked(var);
}

template<typename... PT>
bool SolverStruct<PT...>::varIsLocked(VariableIdType var) {
	return varSpace.getVarFlagLocked(var);
}

template<typename... PT>
bool SolverStruct<PT...>::varIsFixed(VariableIdType var) {
	return varDeclevel(var) == 1;
}

/* ------------------- CLAUSE MANAGEMENT FUNCTIONS ------------------------- */

template<typename... PT>
bool SolverStruct<PT...>::clauseAssigned(ClauseIdType clause) {
	if(clauseLength(clause) == 1)
		return true;

	ClauseRefType ref(clauseSpace, clause);
	LiteralIdType lit1 = ref.assertedWatch();
	LiteralIdType lit2 = ref.triggerWatch();
	return varAssigned(lit1.variable()) && varAssigned(lit2.variable());
}

template<typename... PT>
bool SolverStruct<PT...>::clauseIsAntecedent(ClauseIdType clause) {
	ClauseRefType ref(clauseSpace, clause);
	assert(ref.length());

	auto isAntecedentOf = [&] (LiteralIdType literal) {
		if(!assignment.isAssigned(literal.variable()))
			return false;
		auto antecedent = assignment.antecedent(literal.variable());
		return !antecedent.isInitial() && antecedent.getClause() == clause;
	};

	if(ref.length() == 2) {
		// Binary clauses are not reordered during propagation.
		return isAntecedentOf(ref.assertedWatch())
				|| isAntecedentOf(ref.triggerWatch());
	}else{
		return isAntecedentOf(ref.assertedWatch());
	}
}

template<typename... PT>
auto SolverStruct<PT...>::clauseLength(ClauseIdType clause) -> ClauseSizeType {
	ClauseRefType ref(clauseSpace, clause);
	return ref.length();
}

template<typename... PT>
void SolverStruct<PT...>::markClause(ClauseIdType clause) {
	assert(!clauseSpace.getFlagMarked(clause));
	clauseSpace.setFlagMarked(clause);
}
template<typename... PT>
void SolverStruct<PT...>::unmarkClause(ClauseIdType clause) {
	assert(clauseSpace.getFlagMarked(clause));
	clauseSpace.unsetFlagMarked(clause);
}
template<typename... PT>
bool SolverStruct<PT...>::clauseIsMarked(ClauseIdType clause) {
	return clauseSpace.getFlagMarked(clause);
}

/*
template<typename... PT>
void SolverStruct<PT...>::onClauseMove(ClauseIdType from_index, ClauseIdType to_index) {
	//std::cout << "Moving " << from_index << " to " << to_index << std::endl;
	// Replace the clause in both watch lists.
	if(!clauseSpace.getFlagInstalled(from_index))
		return;
	
	ClauseRefType clause(clauseSpace, from_index);
	if(clause.length() == 2) {
		auto lit1 = clause.assertedWatch();
		auto lit2 = clause.triggerWatch();
		watchReplaceBinary(lit1.inverse(), from_index, to_index);
		watchReplaceBinary(lit2.inverse(), from_index, to_index);
	}else if(clause.length() > 2) {
		auto lit1 = clause.assertedWatch();
		auto lit2 = clause.triggerWatch();
		watchReplaceClause(lit1.inverse(), from_index, to_index);
		watchReplaceClause(lit2.inverse(), from_index, to_index);
	}
	
	// Update the antecedent if the clause was unit.
	if(clause.length()) {
		auto variable = clause.assertedWatch().variable();
		if(assignment.isAssigned(variable)) {
			auto antecedent = assignment.antecedent(variable);
			if(!antecedent.isInitial() && antecedent.getClause() == clause.id())
				assignment.updateAntecedent(variable, AntecedentType::makeClause(to_index));
		}
	}
}
*/

template<typename... PT>
void SolverStruct<PT...>::expellLearned() {
	assert(currentAssignedVars == 0);
	
	clauseSpace.forEach([&] (ClauseRefType clause) {
		if(!clause.isPresent())
			return;
		if(clause.isEssential())
			return;
		clause.erase();
	});
}

template<typename... PT>
void SolverStruct<PT...>::expellContaining(LiteralRefType lit) {
	assert(currentAssignedVars == 0);
	
	clauseSpace.forEach([&] (ClauseRefType clause) {
		if(!clause.isPresent())
			return;
		if(std::find(clause.beginLits(), clause.endLits(), lit) == clause.endLits())
			return;
		clause.forceErase();
	});
}


/* -------------- WATCH LIST / OCCLIST FUNCTIONS ----------------------- */

template<typename... PT>
void SolverStruct<PT...>::watchInsertClause(LiteralIdType literal,
		LiteralIdType blocking, ClauseIdType clause) {
	varSpace.watchInsert(literal, WatchlistEntry::makeClause(clause, blocking));
}
template<typename... PT>
void SolverStruct<PT...>::watchInsertBinary(LiteralIdType literal,
		LiteralIdType implied, ClauseIdType clause) {
	varSpace.watchInsert(literal, WatchlistEntry::makeBinary(clause, implied));
}

template<typename... PT>
void SolverStruct<PT...>::watchRemoveClause(LiteralIdType literal, ClauseIdType clause) {
	for(auto i = varSpace.watchBegin(literal);
			i != varSpace.watchEnd(literal); ++i) {
		if(!i->isClause())
			continue;
		if(i->getClause() != clause)
			continue;
		varSpace.watchErase(literal, i);
		return;
	}
	throw std::runtime_error("Clause not found\n");
}
template<typename... PT>
void SolverStruct<PT...>::watchRemoveBinary(LiteralIdType literal, ClauseIdType clause) {
	for(auto i = varSpace.watchBegin(literal);
			i != varSpace.watchEnd(literal); ++i) {
		if(!i->isBinary())
			continue;
		if(i->getClause() != clause)
			continue;
		varSpace.watchErase(literal, i);
		return;
	}
	throw std::runtime_error("Clause not found\n");
}

template<typename... PT>
void SolverStruct<PT...>::watchReplaceClause(LiteralIdType literal,
		ClauseIdType clause, ClauseIdType replacement) {
	for(auto i = watchBegin(literal); i != watchEnd(literal); ++i) {
		if(!i->isClause())
			continue;
		if(i->getClause() != clause)
			continue;
		*i = WatchlistEntry::makeClause(replacement, i->getBlocking());
		return;
	}
	throw std::runtime_error("Clause not found\n");
}

template<typename... PT>
void SolverStruct<PT...>::watchReplaceBinary(LiteralIdType literal,
		ClauseIdType clause, ClauseIdType replacement) {
	for(auto i = watchBegin(literal); i != watchEnd(literal); ++i) {
		if(!i->isBinary())
			continue;
		if(i->getClause() != clause)
			continue;
		*i = WatchlistEntry::makeBinary(replacement, i->getImplied());
		return;
	}
	throw std::runtime_error("Clause not found\n");
}

template<typename... PT>
bool SolverStruct<PT...>::watchContainsBinary(LiteralIdType literal, LiteralIdType implied) {
	for(auto i = varSpace.watchBegin(literal);
			i != varSpace.watchEnd(literal); ++i) {
		if(!i->isBinary())
			continue;
		if(i->getImplied() != implied)
			continue;
		return true;
	}
	return false;
}

/* ------------------- ASSIGN / UNASSIGN FUNCTIONS --------------------- */

template<typename... PT>
void SolverStruct<PT...>::restart() {
	assert(!trail.conflict());
	trail.backjump(trail.initialPoint());
	stat.search.restarts++;
}

template<typename... PT>
void SolverStruct<PT...>::checkRestart() {
	if(opts.restart.strategy == kRestartLuby) {
		state.restart.lubyCounter++;
		if(!trail.conflict() && !trail.isReset() && trail.currentLevel() > trail.initialPoint()
				&& state.restart.lubyCounter >= state.restart.lubyPeriod) {
			restart();
			state.restart.lubyPeriod = opts.restart.lubyScale
					* lubySequence(stat.search.restarts);
			state.restart.lubyCounter = 0;
		}
	}else if(opts.restart.strategy == kRestartGlucose) {
		if(trail.conflict() || trail.isReset() || trail.currentLevel() <= trail.initialPoint())
			return;

		if(!state.restart.recentLbds.valid())
			return;

		auto historic_avg = static_cast<double>(state.restart.historicLbdSum) / state.restart.historicCounter;
		if(0.8 * state.restart.recentLbds.avg() > historic_avg) {
			restart();
			state.restart.recentLbds.clear();
		}
	}else throw std::logic_error("Illegal restart strategy\n");
}

/* ----------------------------- HEURISTIC FUNCTIONS --------------------------- */

template<typename... PT>
void SolverStruct<PT...>::resetBaseHeuristics() {
	if(emulation == Emulation::miniSat) {
		opts.clauseRed.model = kClauseRedGeometric;
		opts.clauseRed.geomIncFactor = 1.5;
		opts.clauseRed.geomSizeFactor = 1.1;
	}else if(emulation == Emulation::glucose) {
		opts.learn.updateLbd = true;

		opts.clauseRed.model = kClauseRedAgile;
		opts.clauseRed.agileBaseInterval = 2000;
		opts.clauseRed.agileSlowdown = 300;
		opts.clauseRed.agileRaiseOnGoodClauses = true;
		opts.clauseRed.agileRaiseCount = 1000;
		opts.clauseRed.permanentLbd = 2;
		opts.clauseRed.freezeUnimportant = false;

		opts.restart.strategy = kRestartGlucose;
	}else{
		assert(emulation == Emulation::native);
		assert(opts.clauseRed.model == kClauseRedAgile);
	}
}

template<typename... PT>
void SolverStruct<PT...>::resetInputHeuristics() {
	// Initialize clause deletion heuristics.
	if(emulation == Emulation::miniSat) {
		state.clauseRed.geomIncCounter = 0;
		state.clauseRed.geomIncLimit = 100;
		state.clauseRed.geomSizeLimit = clauseSpace.numClauses() / 3;
	}else if(emulation == Emulation::glucose) {
		state.restart.recentLbds.set_window(50);
	}else{
		assert(emulation == Emulation::native);

		state.clauseRed.geomIncCounter = 0;
		state.clauseRed.geomIncLimit = 100;
		state.clauseRed.geomSizeLimit = clauseSpace.numClauses() / 3 + 10;
	}

	state.clauseRed.nextReductionConflict = 0;
	state.clauseRed.agileInterval = opts.clauseRed.agileBaseInterval;
}

/* ------------------------ CLAUSE REDUCTION FUNCTIONS --------------------- */

template<typename... PT>
int SolverStruct<PT...>::calculatePsm(ClauseRefType clause) {
	int psm = 0;
	for(auto it = clause.beginLits(); it != clause.endLits(); ++it) {
		VariableIdType var = (it->id()).variable();
		bool saved_one = varSpace.getVarFlagSaved(var);
		if(((it->id()).isOneLiteral() && saved_one)
				|| (!(it->id()).isOneLiteral() && !saved_one))
			psm++;
	}
	return psm;
}

// We freeze/unfreeze clauses when their PSM passes this threshold.
const int goodPsm = 3;

template<typename... PT>
void SolverStruct<PT...>::reduceClauses() {
	assert(!trail.conflict());

	// Keep clauses with high activity values.
	// MiniSAT and Glucose do not use this.
	const bool keepActiveClauses = false;

	// Delete only half of the clauses.
	// This is adopted from Glucose.
	const bool deleteOnlyHalf = true;

	// We freeze/delete clauses when their LBD passes this threshold.
	const int freezeLbd = 8;

	// Build a list of all clauses that are considered for deletion.
	std::vector<ClauseRefType> unfreeze_queue;
	std::vector<ClauseRefType> delete_queue;
	for(auto it = clauseSpace.reducible().begin(); it != clauseSpace.reducible().end(); ++it) {	
		// Never delete essential clauses.
		if(it->isEssential() || !it->isPresent())
			continue;

		stat.clauseRed.clausesConsidered++;

		if(it->isFrozen()) {
			// Unfreeze clauses if their PSM is good.
			if(calculatePsm(*it) <= goodPsm) {
				unfreeze_queue.push_back(*it);
				stat.clauseRed.clauseUnfreezes++;
			}
			continue;
		}
		
		// Do not delete classes that are currently unit.
		// This is adopted from MiniSAT and Glucose.
		if(clauseIsAntecedent(it->id()))
			continue;
		// Don't delete units and binary clauses.
		// This is adopted from MiniSAT and Glucose.
		if(clauseLength(it->id()) <= 2)
			continue;

		// Keep clauses with low LBD.
		if(it->localLbd() <= opts.clauseRed.permanentLbd)
			continue;

		// Keep clauses with high activity.
		if(keepActiveClauses) {
			if(it->getActivity() > state.search.clauseActInc) {
				stat.clauseRed.clausesActive++;
				continue;
			}else{
				stat.clauseRed.clausesNotActive++;
			}
		}

		if(it->willBeSpared()) {
			it->doNotSpare();
			continue;
		}

		delete_queue.push_back(*it);
		stat.clauseRed.clauseDeletions++;
	}

	// TODO: Just backjump to a lower level instead of resetting.
	trail.reset(); // Reset the solver so that unfreeze works correctly.

	// Perform the actual deletion.
	for(auto clause : unfreeze_queue)
		clause.unfreeze();

	size_t wanted_deletions;
	if(deleteOnlyHalf) {
 		wanted_deletions = delete_queue.size() / 2;

		std::sort(delete_queue.begin(), delete_queue.end(), [&] (auto c1, auto c2) {
			// Prefer clauses with high LBD.
			auto lbd1 = c1.localLbd();
			auto lbd2 = c2.localLbd();
			if(lbd1 != lbd2)
				return lbd1 > lbd2;
			// Prefer clauses with low activity.
			return c1.getActivity() < c2.getActivity();
		});
	}else{
 		wanted_deletions = delete_queue.size();
	}
	
	if(opts.clauseRed.agileRaiseOnGoodClauses && !delete_queue.empty()) {
		if(delete_queue[delete_queue.size() / 2].localLbd() <= 3)
			state.clauseRed.agileInterval += opts.clauseRed.agileRaiseCount;
		if(delete_queue[delete_queue.size() - 1].localLbd() <= 5)
			state.clauseRed.agileInterval += opts.clauseRed.agileRaiseCount;
	}


	for(size_t i = 0; i < wanted_deletions; i++) {
		auto clause = delete_queue[i];
		if(clause.isImportant() || (opts.clauseRed.freezeUnimportant && clause.localLbd() <= freezeLbd)) {
			// Freeze clauses that are good in general but bad under the current assignment.
			if(calculatePsm(clause) > goodPsm) {
				clause.freeze();
				stat.clauseRed.clauseFreezes++;
			}
		}else{
			_hooks.reduceProof(clause);
			clause.erase();
			stat.clauseRed.clauseDeletions++;
		}
	}

	stat.clauseRed.reductionRuns++;

	varSpace.cleanWatches(&clauseSpace);
}

template<typename... PT>
void reduceClausesGeometric(SolverStruct<PT...> &solver) {
	assert(!solver.trail.conflict());

	bool useExtraLimit = false;

	std::vector<ClauseRef<PT...>> unfreeze_queue;
	std::vector<ClauseRef<PT...>> delete_queue;
	for(auto it = solver.clauseSpace.reducible().begin(); it != solver.clauseSpace.reducible().end(); ++it) {
		// Never delete essential clauses.
		if(it->isEssential() || !it->isPresent())
			continue;

		solver.stat.clauseRed.clausesConsidered++;

		if(it->isFrozen()) {
			// Unfreeze clauses if their PSM is good.
			if(solver.calculatePsm(*it) <= goodPsm) {
				unfreeze_queue.push_back(*it);
				solver.stat.clauseRed.clauseUnfreezes++;
			}
			continue;
		}

		// Do not delete classes that are currently unit.
		// This is adopted from MiniSAT and Glucose.
		if(solver.clauseIsAntecedent(it->id()))
			continue;
		// Don't delete units and binary clauses.
		// This is adopted from MiniSAT and Glucose.
		if(it->length() <= 2)
			continue;
		
		delete_queue.push_back(*it);
	}

	// TODO: See agile reduction.
	solver.trail.reset(); // Reset the solver so that unfreeze works correctly.

	// Perform the actual deletion.
	for(auto clause : unfreeze_queue)
		clause.unfreeze();

	std::sort(delete_queue.begin(), delete_queue.end(), [] (auto c1, auto c2) {
		return c1.getActivity() < c2.getActivity();
	});
	
	auto learnts = solver.currentActiveClauses - solver.clauseSpace.currentEssentialClauses;
	auto extra_limit = solver.state.search.clauseActInc / learnts;

	size_t wanted_deletions = delete_queue.size() / 2;
	for(size_t i = 0; i < delete_queue.size(); i++) {
		auto clause = delete_queue[i];

		if(i < wanted_deletions || (useExtraLimit && clause.getActivity() < extra_limit)) {
			if(clause.isImportant()) {
				// Freeze clauses that are good in general but bad under the current assignment.
				if(solver.calculatePsm(clause) > goodPsm) {
					clause.freeze();
					solver.stat.clauseRed.clauseFreezes++;
				}
			}else{
				solver._hooks.reduceProof(clause);
				clause.erase();
				solver.stat.clauseRed.clauseDeletions++;
			}
		}
	}

	solver.stat.clauseRed.reductionRuns++;

	solver.varSpace.cleanWatches(&solver.clauseSpace);
}

template<typename... PT>
void SolverStruct<PT...>::checkClauseReduction() {
	if(opts.clauseRed.model == kClauseRedAgile) {
		if(!trail.conflict() && trail.conflictCounter >= state.clauseRed.nextReductionConflict) {
			reduceClauses();
			state.clauseRed.numClauseReds++;

			state.clauseRed.nextReductionConflict = trail.conflictCounter + state.clauseRed.agileInterval;
			state.clauseRed.agileInterval += opts.clauseRed.agileSlowdown;

			_hooks.onReductionIncrement();
		}
	}else if(opts.clauseRed.model == kClauseRedGeometric) {
		auto learnts = currentActiveClauses - clauseSpace.currentEssentialClauses;
		if(!trail.conflict() && learnts >= state.clauseRed.geomSizeLimit) {
			reduceClausesGeometric(*this);
			state.clauseRed.numClauseReds++;
		}

		state.clauseRed.geomIncCounter++;
		if(state.clauseRed.geomIncCounter >= state.clauseRed.geomIncLimit) {
			state.clauseRed.geomSizeLimit *= opts.clauseRed.geomSizeFactor;
			state.clauseRed.geomIncLimit *= opts.clauseRed.geomIncFactor;
			state.clauseRed.geomIncCounter = 0;

			_hooks.onReductionIncrement();
		}
	}else std::logic_error("Illegal clause reduction model\n");
}

/* ---------------------- DECISION FUNCTIONS ------------------------------- */

template<typename... PT>
bool SolverStruct<PT...>::decide() {
	assert(!trail.conflict());
	
	// determine the variable with minimal VSIDS score
	VariableIdType var;
	do {
		if(!p_vsidsConfig.hasMaximum())
			return false;
		var = p_vsidsConfig.removeMaximum();
	} while(varAssigned(var) || !varIsPresent(var));
		
	bool saved_one = varSpace.getVarFlagSaved(var);
	LiteralIdType decliteral = saved_one ? var.oneLiteral() : var.zeroLiteral();
	
	// create a new decision level; assign the variable
	trail.beginLevel();
	trail.enqueue(decliteral, AntecedentType::makeInitial());
	return true;
}

template<typename... PT>
void SolverStruct<PT...>::scaleVarActivity(ActivityType divisor) {
	p_vsidsConfig.scaleActivity(divisor);
	state.search.varActInc /= divisor;
}
template<typename... PT>
void SolverStruct<PT...>::scaleClauseActivity(ActivityType divisor) {
	for(auto it = clauseSpace.reducible().begin(); it != clauseSpace.reducible().end(); ++it)
		it->setActivity(it->getActivity() / divisor);
	state.search.clauseActInc /= divisor;
}

template<typename... PT>
void SolverStruct<PT...>::onVarActivity(VariableIdType var) {
	ActivityType activity = p_vsidsConfig.raiseActivity(var, state.search.varActInc);
	
	// re-scale the activity of all variables if necessary
	if(activity > 1.0E50)
		scaleVarActivity(activity);
}
template<typename... PT>
void SolverStruct<PT...>::onAntecedentActivity(AntecedentType antecedent) {
	if(!antecedent.isClause())
		return;

	ClauseRefType clause{clauseSpace, antecedent.getClause()};
	if(!clause.isReducible())
		return;

	auto activity = clause.getActivity();
	clause.setActivity(activity + state.search.clauseActInc);
	
	// re-scale the activity of all clauses if necessary
	if(activity > 1.0E50)
		scaleClauseActivity(activity);
}


template<typename... PT>
void SolverStruct<PT...>::recomputeLbd(ClauseIdType id) {
	if(!opts.learn.updateLbd)
		return;

	ClauseRefType clause{clauseSpace, id};
	if(!clause.isReducible())
		return;

	auto lbd = computeLocalLbd(*this, clause.beginLits(), clause.endLits());
	if(lbd < UINT16_MAX && lbd + 1 < clause.localLbd()) {
		clause.spare();
		clause.decreaseLocalLbd(lbd);
	}
}

template<typename... PT>
void SolverStruct<PT...>::increaseActivity() {
	state.search.varActInc *= state.search.varActFactor;
	state.search.clauseActInc *= state.search.clauseActFactor;
}

/* ------------------------- CONFLICT MANAGEMENT --------------------------- */

template<typename... PT>
void SolverStruct<PT...>::resolveConflict() {
	assert(isResolveable());

	state.conflict.lastConflictDeclevel = trail.currentLevel();

	// Determine the 1UIP clause.
	learnState.cut(*this, trail.conflict());
	stat.search.learnedLits += learnState.cutSize();
	stat.search.minimizedLits += learnState.minSize();

	// Generate a conflict clause.
	assert(learnState.minSize() > 0);
	ClauseRefType learned = clauseSpace.allocate(uniqueClauseName(), learnState.minSize(),
			learnState.beginMin(), learnState.endMin());

	// Calculate the LBD.
	// NOTE: This has to be done before doing the backjump!
	auto global_lbd = computeGlobalLbd(*this, learnState.beginMin(), learnState.endMin());
	auto local_lbd = computeLocalLbd(*this, learnState.beginMin(), learnState.endMin());
	learned.updateLbd(global_lbd);
	learned.decreaseLocalLbd(local_lbd);
	learned.setActivity(state.search.clauseActInc);

	// Keep track of LBD restart heuristics.
	if(opts.restart.strategy == kRestartGlucose) {
		state.restart.recentLbds.push_back(learned.localLbd());
		state.restart.historicLbdSum += learned.localLbd();
		state.restart.historicCounter++;
	}

	// TODO: Move this code before the clause allocation.
	resolveToLearn(learnState.minSize(), learnState.beginMin(), learnState.endMin());
	
	_hooks.onLearnClause(learned);
	enqueueAfterLearning(learned);

	// Bump variables asserted by glue clauses as in glucose.
/*
	if(opts.learn.bumpGlueTwice)
		for(auto i = learnState.beginCurlevel();
				i != learnState.endCurlevel(); ++i) {
			AntecedentType antecedent = varAntecedent(*i);
			if(antecedent.isBinary() && lbd > 2) {
				// cannot check if the clause is learned. do not bump for now!
				//onVarActivity(*i);
			}else if(antecedent.isClause()) {
				ClauseIdType reason = antecedent.identifier.clause_ident;
				if(!clauseSpace.getFlagEssential(reason)
						&& clauseGetLbd(reason) < lbd)
					onVarActivity(*i);
			}
		}
*/

	if(learnState.minSize() == 1) {
		stat.search.learnedUnits++;
	}else if(learnState.minSize() == 2) {
		stat.search.learnedBinary++;
	}
	
	// Output the DRAT proof line for this clause.
	_hooks.emitProof(learned);
	
	if(kReportSample) {
		report<ReportTag>(ReportTag::kSample);
		report<uint64_t>(currentActiveClauses);
	}

	learnState.reset();
}

template<typename... PT>
template<typename Iterator>
void SolverStruct<PT...>::resolveToLearn(ClauseSizeType size, Iterator begin, Iterator end) {
	(void)end;
	assert(size);

	DecisionLevelType level = 0;
	if(size > 1)
		level = assignment.level(std::next(begin)->variable());
	
	trail.backjump(level);
	trail.clearConflict();
}

template<typename... PT>
void SolverStruct<PT...>::enqueueAfterLearning(ClauseRefType learned) {
	assert(learned.length());
	
	auto forced_literal = *learned.beginLits();
	if(learned.length() == 1) {
		trail.enqueue(forced_literal, AntecedentType::makeUnit(learned.id()));
	}else if(learned.length() == 2) {
		auto reason_inverse = *std::next(learned.beginLits());
		auto reason_literal = reason_inverse.inverse();
		trail.enqueue(forced_literal, AntecedentType::makeImplication(learned.id(), reason_literal.id()));
	}else{
		trail.enqueue(forced_literal, AntecedentType::makeClause(learned.id()));
	}
}

/* --------------------- ASSUMPTION FUNCTIONS -------------------------- */

template<typename... PT>
void SolverStruct<PT...>::assumptionEnable(LiteralIdType literal) {
	assert(!varSpace.getLitFlagAssumption(literal));
	assert(!varAssigned(literal.variable()));
	assert(varIsLocked(literal.variable()));
	varSpace.setLitFlagAssumption(literal);

	_assumptionList.push_back(literal);
}

template<typename... PT>
void SolverStruct<PT...>::assumptionDisable(LiteralIdType literal) {
	assert(varSpace.getLitFlagAssumption(literal));
	assert(!varAssigned(literal.variable()));
	varSpace.clearLitFlagAssumption(literal);

	auto it = std::find(_assumptionList.begin(), _assumptionList.end(), literal);
	assert(it != _assumptionList.end());
	_assumptionList.erase(it);
}

template<typename... PT>
bool SolverStruct<PT...>::isAssumed(LiteralIdType literal) {
	return varSpace.getLitFlagAssumption(literal);
}

/* ---------------- SEARCH FUNCTIONS --------------------------- */

struct TotalSearchStats {
	sys::HptCounter elapsed;

	TotalSearchStats() : elapsed(0) { }
};

template<typename... PT>
void progressHeader(SolverStruct<PT...> &solver) {
	std::stringstream text;
	text << std::right;
	text << "c (" << std::to_string(solver.p_configId) <<") [SEARCH]" ;
	text << std::setw(6) << "secs";
	text << std::setw(14) << "conflicts";
	text << std::setw(15) << "conflicts/secs";
	text << std::setw(9) << "restarts";
	text << std::setw(12) << "limit";
	text << std::setw(10) << "space(kb)";
	std::cout << text.str() << std::endl;
	std::cout << "c -----------------------------------------------------------------------" << std::endl;
}

template<typename... PT>
void progressMessage(SolverStruct<PT...> &solver, sys::HptCounter current_time, const char *reason = "") {
	auto secs = sysGetCpuTime() / 1000.0;

	std::stringstream msg;
	msg << "c (" << std::to_string(solver.p_configId) << ") [SEARCH]";
	msg << std::right << std::setprecision(2) << std::fixed;
	msg << std::setw(6) << ((current_time - solver.state.general.startTime) / (1000 * 1000 * 1000));
	msg << std::setw(14) << solver.trail.conflictCounter;
	msg << std::setw(15) << (solver.trail.conflictCounter / secs);
	msg << std::setw(9) << solver.stat.search.restarts;
	msg << std::setw(12) << (solver.opts.clauseRed.model == SolverStruct<PT...>::kClauseRedAgile
			? solver.state.clauseRed.agileInterval
			: solver.state.clauseRed.geomSizeLimit);
	msg << std::setw(10) << (solver.usedClauseSpace() / 1024);
	msg << " " << reason;
//			msg << std::setw(12) << ((float)solver.state.restart.glucose_long_sum / solver.trail.conflictCounter);
//			msg << std::setw(12) << ((float)solver.state.restart.glucose_short_sum
//					/ solver.opts.restart.glucose_short_interval);
	std::cout << msg.str() << std::endl;
}

template<typename... PT>
struct SatisfiedReduction {
	using LiteralIdType = LiteralId<PT...>;
	using ClauseSpaceType = ClauseSpace<PT...>;
	using ClauseRefType = ClauseRef<PT...>;
	using TrailType = Trail<PT...>;
	using AssignmentType = Assignment<PT...>;
	using AntecedentType = Antecedent<PT...>;

	SatisfiedReduction(SolverStruct<PT...> *solver, ClauseSpaceType *clause_space, TrailType *trail,
			AssignmentType *assignment)
	: _solver{solver}, _clauseSpace{clause_space}, _trail{trail}, _assignment{assignment},
			_lastUnitCount{0}, _nextRunProps{0} { }

	bool simplify() {
		if(_trail->isReset() || !_trail->isPropagated())
			return false;
		if(_trail->conflict())
			return false;

		auto num_units = _trail->indexOfNextLevel(0);
		assert(num_units >= _lastUnitCount);

		// Only perform simplification if there are new units.
		if(num_units == _lastUnitCount)
			return false;

		// Ensure that we do not simplify too often.
		if(_nextRunProps > _solver->trail.propagationCounter)
			return false;

		// Resolve all propagated units to unit clauses.
		for(size_t i = 0; i < num_units; i++) {
			auto literal = _trail->atomAt(i);
			auto antecedent = _assignment->antecedent(literal.variable());
			if(antecedent.isUnit())
				continue;
			assert(antecedent.isClause() || antecedent.isImplication());

			std::array<LiteralIdType, 1> lits{literal.id()};
			auto unit = _clauseSpace->allocate(_solver->uniqueClauseName(), 1, lits.begin(), lits.end());
			unit.markAsEssential();
			_solver->_hooks.emitProof(unit);

			_assignment->updateAntecedent(literal.variable().id(),
					AntecedentType::makeUnit(unit.id()));
		}

		// Find all clauses that are satisfied by units only.
		_clauseSpace->forEach([&] (ClauseRefType clause) {
			auto p = [&] (auto literal) {
				if(!_assignment->isTrue(literal))
					return false;
				return _assignment->level(literal.variable()) == 0;
			};

			if(!clause.isPresent())
				return;
			if(clause.length() <= 1)
				return;

			if(std::any_of(clause.beginLits(), clause.endLits(), p))
				_queue.push_back(clause);
		});

		// Perform the actual erause.
		for(auto clause : _queue) {
			_solver->_hooks.reduceProof(clause);
			clause.forceErase();
		}
		_queue.clear();

		_solver->varSpace.cleanWatches(_clauseSpace);

		_lastUnitCount = num_units;
		_nextRunProps = _solver->trail.propagationCounter
				+ _clauseSpace->presentLiterals();
		return true;
	}

private:
	SolverStruct<PT...> *_solver;
	ClauseSpaceType *_clauseSpace;
	TrailType *_trail;
	AssignmentType *_assignment;

	unsigned int _lastUnitCount;
	uint64_t _nextRunProps;
	std::vector<ClauseRefType> _queue;
};

struct SearchLimits {
	SearchLimits()
	: propagations{0}, conflicts{0} { }

	uint64_t propagations;
	uint64_t conflicts;
};

template<typename... PT>
SolveState search(SolverStruct<PT...> &solver, SearchLimits limits = SearchLimits{},
		TotalSearchStats *stats = nullptr) {
	SolveState result = SolveState::kStateBreak;
	uint64_t max_propagation = UINT64_MAX;
	uint64_t max_conflict = UINT64_MAX;

	if(limits.propagations)
		max_propagation = solver.trail.propagationCounter + limits.propagations;
	if(limits.conflicts)
		max_conflict = solver.trail.conflictCounter + limits.conflicts;

	auto start = sys::hptCurrent();
	while(true) {
		assert(!solver.varSpace.areWatchesDirty());
		solver.trail.propagate();

		if(solver.trail.conflict()) {
			if(!solver.isResolveable()) {
				if(solver.isUnsatisfiable()) {
					result = SolveState::kStateUnsatisfiable;
					break;
				}else if(solver.isFailedAssumption()) {
					result = SolveState::kStateAssumptionFail;
					break;
				}else std::logic_error("Illegal conflict state");
			}
			solver.resolveConflict();
			solver.increaseActivity();
	
			solver.checkClauseReduction();
			solver.checkRestart();
		}else{
			if(solver.trail.propagationCounter > max_propagation
					|| solver.trail.conflictCounter > max_conflict)
				break;
			
			solver.clauseSpace.compactClauses();

			if(solver.trail.isReset()
					|| solver.trail.currentLevel() < solver.trail.initialPoint()) {
				solver.trail.pushInitialLevel();
			}else if(!solver.decide()) {
				assert(solver.currentAssignedVars == solver.varSpace.presentCount());
				result = SolveState::kStateSatisfied;
				break;
			}
		}
	}

	auto elapsed = sys::hptElapsed(start);
	if(stats)
		stats->elapsed += elapsed;
	solver.perf.searchTime += elapsed;

	return result;
}

} } // namespace satuzk::cdcl

