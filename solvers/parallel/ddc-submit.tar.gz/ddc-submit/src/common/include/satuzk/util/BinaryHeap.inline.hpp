
#include <vector>

namespace util {

// implements a binary minimum-heap
// Policy need to provide ItemType and IndexType types
// as well as the functions isLess(item1, item2),
// insert(it), remove(previous) and update(it, previous)
template<typename Policy>
struct BinaryHeap {
	typedef typename Policy::ItemType ItemType;

	typedef typename std::vector<ItemType>::iterator Iterator;
	
	BinaryHeap(Policy policy)
	: _policy(std::move(policy)) { }

	void insert(ItemType item) {
		// insert as last node; then fix heap
		auto it = _array.insert(_array.end(), std::move(item));
		_policy.insert(it);
		
		moveUp(it);
	}

	bool empty() {
		return _array.empty();
	}

	ItemType front() {
		return _array.front();
	}

	Iterator begin() {
		return _array.begin();
	}
	Iterator end() {
		return _array.end();
	}

	void remove(Iterator it) {
		using std::swap;

		// we always remove the last element
		Iterator last = end() - 1;
		if(it == last) {
			_policy.remove(last);
			_array.pop_back();
		}else{
			swap(*it, *last);
			_policy.update(it, last);
			_policy.update(last, it);

			_policy.remove(last);
			_array.pop_back();
			
			moveDown(it);
		}
	}

	// moves the item towards the root of the heap
	void moveUp(Iterator it) {
		using std::swap;

		if(it == begin())
			return;

		Iterator parent = getParent(it);
		if(_policy.isLess(*parent, *it))
			return;
		
		// swap node with parent; then fix parent
		swap(*it, *parent);
		_policy.update(it, parent);
		_policy.update(parent, it);

		moveUp(parent);
	}

	// moves the item away from the root of the heap
	void moveDown(Iterator it) {
		using std::swap;
		
		Iterator left = getLeft(it);
		Iterator right = getRight(it);

		if(left == end())
			return; // the item has no children
		
		if(right == end()) {
			if(_policy.isLess(*it, *left))
				return;

			// swap the item with its single child
			swap(*it, *left);
			_policy.update(it, left);
			_policy.update(left, it);

			return;
		}

		// find the smaller of the two children
		Iterator pivot = _policy.isLess(*left, *right) ? left : right;
		if(_policy.isLess(*it, *pivot))
			return;
		
		// swap node with minimal child; then fix child
		swap(*it, *pivot);
		_policy.update(it, pivot);
		_policy.update(pivot, it);

		moveDown(pivot);
	}

private:
	Iterator getParent(Iterator it) {
		assert(it != _array.begin());
		size_t index = ((it - _array.begin()) - 1) / 2;
		return _array.begin() + index;
	}
	Iterator getLeft(Iterator it) {
		size_t index = (it - _array.begin()) * 2 + 1;
		if(index >= _array.size())
			return _array.end();
		return _array.begin() + index;
	}
	Iterator getRight(Iterator it) {
		size_t index = (it - _array.begin()) * 2 + 2;
		if(index >= _array.size())
			return _array.end();
		return _array.begin() + index;
	}

	Policy _policy;
	std::vector<ItemType> _array;
};

} // namespace util

