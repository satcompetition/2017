
namespace satuzk {

// checks whether the given literal blocks the given clause.
// the given literal must be in the clause.
template<typename Defs, typename Stats>
bool bceBlocks(Solver<Defs> &solver, ClauseType<Defs> clause,
		LiteralType<Defs> literal, Stats &stats) {
	if(solver.litFalse(literal))
		return false;/*FIXME: what does this check do? */

	LiteralType<Defs> inverse = literal.inverse();
	for(auto i = solver.occurBegin(inverse); i != solver.occurEnd(inverse); ++i) {
		stats.ops++;

		if(!solver.clauseIsPresent(clause))
			continue;
		if(!resolventTrivial(solver, clause, *i, literal.variable()))
			return false;
	}
	return true;
}

// checks whether the given clause is a blocked clause
template<typename Defs, typename Stats>
bool bceBlocked(Solver<Defs> &solver, ClauseType<Defs> clause,
		LiteralType<Defs> &blocking, Stats &stats) {
	for(auto i = solver.clauseBegin(clause); i != solver.clauseEnd(clause); ++i) {
		if(solver.varIsProtected((*i).variable()))
			continue;
		if(bceBlocks(solver, clause, *i, stats)) {
			blocking = *i;
			return true;
		}
	}
	return false;
}

template<typename Defs, typename Stats>
bool bceEliminateSingle(Solver<Defs> &solver,
		ClauseType<Defs> clause, Stats &stats) {
	LiteralType<Defs> blocking = LiteralType<Defs>::illegalLit();
	if(!bceBlocked(solver, clause, blocking, stats))
		return false;
	
	if(solver.clauseIsEssential(clause)) {
		solver.p_extModelConfig.pushBlockedClause(solver, clause, blocking);
		solver.p_varConfig.setVarFlagRecoded(blocking.variable());
	}

	if(solver.clauseIsEssential(clause))
		solver.clauseUnsetEssential(clause);
	if(solver.clauseIsInstalled(clause))
		solver.uninstallClause(clause);
	solver.deleteClause(clause);

	stats.elimClauses++;
	return true;
}

// performs blocked clause elimination on all clauses
template<typename Defs>
void bceEliminateAll(Solver<Defs> &solver) {
	std::vector<ClauseType<Defs>> queue;
	for(auto i = solver.clausesBegin(); i != solver.clausesEnd(); ++i) {
		if(!solver.clauseIsPresent(*i))
			continue;
		if(solver.clauseLength(*i) <= 2)
			continue;
		queue.push_back(*i);
	}

	sys::HptCounter start = sys::hptCurrent();

	for(auto i = queue.begin(); i != queue.end(); ++i)
		bceEliminateSingle(solver, *i, solver.stat.simp.bce);
	solver.stat.simp.bce.time += sys::hptElapsed(start);

	solver.checkClauseGarbage();
}

} // namespace satuzk

