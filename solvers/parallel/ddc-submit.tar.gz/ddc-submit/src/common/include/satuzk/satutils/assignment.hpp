
namespace satuzk {
namespace satutils {

namespace values {
	using Type = uint8_t;

	// Use the second bit to remember if the variable is assigned
	// and the first bit to store the actual value.
	static constexpr Type unassigned = 2;
	static constexpr Type mask = 1;
	static constexpr Type positive = 1;
	static constexpr Type negative = 0;

};

template<typename... PT>
class AssignmentStruct {
public:
	typedef VariableSpace<PT...> VariableSpaceType;
	typedef typename VariableSpaceType::VariableIdType VariableIdType;
	typedef typename VariableSpaceType::LiteralIdType LiteralIdType;
	typedef typename VariableSpaceType::VariableRef VariableRefType;
	typedef typename VariableSpaceType::LiteralRef LiteralRefType;
	
	typedef Antecedent<PT...> AntecedentType;
	typedef DecisionLevel<PT...> DecisionLevelType;

public:
	void resizeVariables(size_t num_variables) {
		_values.resize(num_variables, 2);
		_levels.resize(num_variables);
		_antecedents.resize(num_variables);
	}
	
	void assign(VariableIdType var, bool state, AntecedentType antecedent, DecisionLevelType level) {
		if(kDbgSlowAssertions)
			assert(!isAssigned(var));
		_values[var.getIndex()] = static_cast<values::Type>(state);
		_antecedents[var.getIndex()] = antecedent;
		_levels[var.getIndex()] = level;
	}
	void unassign(VariableIdType var) {
		if(kDbgSlowAssertions)
			assert(isAssigned(var));
		_values[var.getIndex()] = 2;
	}

	bool isAssigned(VariableIdType var) {
		return !(_values[var.getIndex()] & 2);
	}
	bool isAssigned(VariableRefType var) {
		return isAssigned(var.id());
	}
	bool isTrue(LiteralIdType literal) {
		auto value = _values[literal.variable().getIndex()];
		return value == (literal.getIndex() & 1);
	}
	bool isTrue(LiteralRefType literal) {
		return isTrue(literal.id());
	}
	bool isFalse(LiteralIdType literal) {
		auto value = _values[literal.variable().getIndex()];
		return value == ((~literal.getIndex()) & 1);
	}
	bool isFalse(LiteralRefType literal) {
		return isFalse(literal.id());
	}
	
	AntecedentType antecedent(VariableIdType var) {
		if(kDbgSlowAssertions)
			assert(isAssigned(var));
		return _antecedents[var.getIndex()];
	}
	AntecedentType antecedent(VariableRefType var) {
		if(kDbgSlowAssertions)
			assert(isAssigned(var));
		return _antecedents[var.getIndex()];
	}
	DecisionLevelType level(VariableIdType var) {
		if(kDbgSlowAssertions)
			assert(isAssigned(var));
		return _levels[var.getIndex()];
	}
	DecisionLevelType level(VariableRefType var) {
		if(kDbgSlowAssertions)
			assert(isAssigned(var));
		return _levels[var.getIndex()];
	}

	// this is called during clause garbage collection
	// TODO: allow clause garbage collection only when there are no assigned vars
	// and remove this function?
	void updateAntecedent(VariableIdType var, AntecedentType new_antecedent) {
		_antecedents[var.getIndex()] = new_antecedent;
	}

private:
	std::vector<values::Type> _values;
	std::vector<AntecedentType> _antecedents;
	std::vector<DecisionLevelType> _levels;
};

} } // namespace satuzk::satutils

