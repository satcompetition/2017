
namespace satuzk {
namespace iclauses {

template<typename... PT>
class ClauseIdStruct {
public:
	typedef Index<PT...> IndexType;

	static ClauseIdStruct illegalClause() {
		return ClauseIdStruct(-1);
	}
	static ClauseIdStruct fromIndex(IndexType index) {
		return ClauseIdStruct(index);
	}
	
	ClauseIdStruct() : p_index(-1) { }

	IndexType getIndex() const {
		return p_index;
	}

	explicit operator bool () {
		return p_index != -1;
	}

	bool operator== (const ClauseIdStruct &other) const {
		return p_index == other.p_index;
	}
	bool operator!= (const ClauseIdStruct &other) const {
		return p_index != other.p_index;
	}

private:
	explicit ClauseIdStruct(IndexType index) : p_index(index) { }
	
	IndexType p_index;
};

} } // namespace satuzk::iclauses

