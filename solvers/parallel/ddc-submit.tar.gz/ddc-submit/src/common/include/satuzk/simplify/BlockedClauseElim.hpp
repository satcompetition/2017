
namespace satuzk {

struct BceStats {
	uint64_t elimClauses;
	uint64_t ops;
	sys::HptCounter time;

	inline BceStats() : elimClauses(0), ops(0), time(0) { }

	BceStats &operator+= (const BceStats &other) {
		elimClauses += other.elimClauses;
		ops += other.ops;
		time += other.time;
		return *this;
	}
};

} // namespace satuzk

