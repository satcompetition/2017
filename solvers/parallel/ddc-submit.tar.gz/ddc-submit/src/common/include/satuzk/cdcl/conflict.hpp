
namespace satuzk {
namespace cdcl {

template<typename... PT>
struct ConflictStruct {
	typedef LiteralId<PT...> LiteralIdType;
	typedef ClauseId<PT...> ClauseIdType;
	typedef ClauseRef<PT...> ClauseRefType;

	struct UnitTag { };
	struct BinaryTag { };
	struct ClauseTag { };

private:
	typedef typename ClauseRefType::LiteralIterator ClauseLiteralIteratorType;

	enum Type {
		kTypeNone,
		kTypeUnit,
		kTypeBinary,
		kTypeClause
	};

public:
	struct Iterator {
		Iterator(UnitTag tag, SeqIterator<LiteralIdType, 1> unit)
		: _type(kTypeUnit), _unit(unit) { }

		Iterator(BinaryTag tag, SeqIterator<LiteralIdType, 2> binary)
		: _type(kTypeBinary), _binary(binary) { }
		
		Iterator(ClauseTag tag, ClauseLiteralIteratorType clause_lits)
		: _type(kTypeClause), _clauseLits(clause_lits) { }
	
		bool operator== (const Iterator &other) const {
			assert(_type == other._type);
			
			switch(_type) {
			case kTypeUnit:
				return _unit == other._unit;
			case kTypeBinary:
				return _binary == other._binary;
			case kTypeClause:
				return _clauseLits == other._clauseLits;
			default:
				assert(!"Illegal iterator type");
			}
		}
		bool operator!= (const Iterator &other) const {
			return !(*this == other);
		}

		Iterator &operator++ () {
			switch(_type) {
			case kTypeUnit:
				++_unit;
				break;
			case kTypeBinary:
				++_binary;
				break;
			case kTypeClause:
				++_clauseLits;
				break;
			default:
				assert(!"Illegal iterator type");
			}
			return *this;
		}

		LiteralIdType operator* () {
			switch(_type) {
			case kTypeUnit:
				return (*_unit).inverse();
			case kTypeBinary:
				return (*_binary).inverse();
			case kTypeClause:
				return (*_clauseLits).inverse().id();
			default:
				assert(!"Illegal iterator type");
			}
		}
		ArrowProxy<LiteralIdType> operator-> () {
			return ArrowProxy<LiteralIdType>(**this);
		}

		Type _type;

		union {
			SeqIterator<LiteralIdType, 1> _unit;
			SeqIterator<LiteralIdType, 2> _binary;
			ClauseLiteralIteratorType _clauseLits;
		};
	};

	ConflictStruct()
	: _type(kTypeNone) { }
	
	ConflictStruct(UnitTag tag, LiteralIdType literal)
	: _type(kTypeUnit), _unit(literal) { }
	
	ConflictStruct(BinaryTag tag, LiteralIdType lit1, LiteralIdType lit2)
	: _type(kTypeBinary), _binary({ lit1, lit2 }) { }

	ConflictStruct(ClauseTag tag, ClauseIdType clause)
	: _type(kTypeClause), _clause(clause) { }

	// syntactic sugar for the constructors
	static ConflictStruct makeUnit(LiteralIdType literal) {
		return ConflictStruct(UnitTag(), literal);
	}
	static ConflictStruct makeBinary(LiteralIdType lit1, LiteralIdType lit2) {
		return ConflictStruct(BinaryTag(), lit1, lit2);
	}
	static ConflictStruct makeClause(ClauseIdType clause) {
		return ConflictStruct(ClauseTag(), clause);
	}

	bool isUnit() const {
		return _type == kTypeUnit;
	}
	bool isBinary() const {
		return _type == kTypeBinary;
	}
	bool isClause() const {
		return _type == kTypeClause;
	}

	LiteralIdType getUnit() const {
		return _unit;
	}
	std::array<LiteralIdType, 2> getBinary() const {
		return _binary;
	}
	ClauseIdType getClause() const {
		return _clause;
	}

	operator bool () const {
		return _type != kTypeNone;
	}
	Iterator begin(Solver<PT...> &solver) const {
		if(_type == kTypeUnit) {
			SeqIterator<LiteralIdType, 1> begin({ _unit }, 0);
			return Iterator(UnitTag(), begin);
		}else if(_type == kTypeBinary) {
			SeqIterator<LiteralIdType, 2> begin(_binary, 0);
			return Iterator(BinaryTag(), begin);
		}else if(_type == kTypeClause) {
			ClauseRefType ref(solver.clauseSpace, _clause);
			return Iterator(ClauseTag(), ref.beginLits());
		}else throw std::logic_error("Illegal conflict");
	}
	
	Iterator end(Solver<PT...> &solver) const {
		if(_type == kTypeUnit) {
			SeqIterator<LiteralIdType, 1> end({ _unit }, 1);
			return Iterator(UnitTag(), end);
		}else if(_type == kTypeBinary) {
			SeqIterator<LiteralIdType, 2> end(_binary, 2);
			return Iterator(BinaryTag(), end);
		}else if(_type == kTypeClause) {
			ClauseRefType ref(solver.clauseSpace, _clause);
			return Iterator(ClauseTag(), ref.endLits());
		}else throw std::logic_error("Illegal conflict");
	}

	template<typename F>
	void for_each(Solver<PT...> *solver, F functor) {
		if(_type == kTypeUnit) {
			functor(_unit.inverse());
		}else if(_type == kTypeBinary) {
			functor(_binary[0].inverse());
			functor(_binary[1].inverse());
		}else{
			assert(_type == kTypeClause);
			ClauseRefType clause{solver->clauseSpace, _clause};
			for(auto it = clause.beginLits(); it != clause.endLits(); ++it)
				functor(it->inverse().id());
		}
	}

private:
	Type _type;

	union {
		LiteralIdType _unit;
		std::array<LiteralIdType, 2> _binary;
		ClauseIdType _clause;
	};
};

} } // namespace satuzk::cdcl

