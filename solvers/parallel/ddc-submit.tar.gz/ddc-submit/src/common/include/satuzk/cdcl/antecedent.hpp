
namespace satuzk {
namespace cdcl {

template<typename... PT>
struct AntecedentStruct {
	typedef LiteralId<PT...> LiteralIdType;
	typedef ClauseId<PT...> ClauseIdType;
	typedef ClauseRef<PT...> ClauseRefType;

	struct InitialTag { };
	struct UnitTag { };
	struct ImplicationTag { };
	struct ClauseTag { };

private:
	typedef typename ClauseRefType::LiteralIterator ClauseLiteralIteratorType;

	enum Type {
		kTypeNone,
		kTypeInitial,
		kTypeUnit,
		kTypeImplication,
		kTypeClause
	};

public:
	struct Iterator {
		Iterator(UnitTag tag)
		: _type(kTypeUnit) { }

		Iterator(ImplicationTag tag, SeqIterator<LiteralIdType, 1> implication)
		: _type(kTypeImplication), _implication(implication) { }
		
		Iterator(ClauseTag tag, ClauseRefType ref, ClauseLiteralIteratorType clause_lits)
		: _type(kTypeClause), _ref(ref), _clauseLits(clause_lits) {
			_fix();
		}
	
		bool operator== (const Iterator &other) const {
			assert(_type == other._type);
			
			switch(_type) {
			case kTypeUnit:
				return true;
			case kTypeImplication:
				return _implication == other._implication;
			case kTypeClause:
				return _clauseLits == other._clauseLits;
			default:
				assert(!"Illegal iterator type");
			}
		}
		bool operator!= (const Iterator &other) const {
			return !(*this == other);
		}

		Iterator &operator++ () {
			switch(_type) {
			case kTypeImplication:
				++_implication;
				break;
			case kTypeClause:
				++_clauseLits;
				_fix();
				break;
			default:
				assert(!"Illegal iterator type");
			}
			return *this;
		}

		LiteralIdType operator* () {
			switch(_type) {
			case kTypeImplication:
				return *_implication;
			case kTypeClause:
				return (*_clauseLits).inverse().id();
			default:
				assert(!"Illegal iterator type");
			}
		}
		ArrowProxy<LiteralIdType> operator-> () {
			return ArrowProxy<LiteralIdType>(**this);
		}
		
	private:
		void _fix() {
			assert(_type == kTypeClause);
			if(_clauseLits != _ref.endLits()
					&& _clauseLits->id() == _ref.assertedWatch())
				_clauseLits++;
		}

		Type _type;

		ClauseRefType _ref;

		union {
			SeqIterator<LiteralIdType, 1> _implication;
			ClauseLiteralIteratorType _clauseLits;
		};
	};

	AntecedentStruct()
	: _type(kTypeNone) { }

	AntecedentStruct(InitialTag tag)
	: _type(kTypeInitial) { }

	AntecedentStruct(UnitTag tag, ClauseIdType clause)
	: _type(kTypeUnit), _clause(clause) { }
	
	AntecedentStruct(ImplicationTag tag, ClauseIdType clause, LiteralIdType literal)
	: _type(kTypeImplication), _clause(clause), _implication(literal) { }

	AntecedentStruct(ClauseTag tag, ClauseIdType clause)
	: _type(kTypeClause), _clause(clause) { }

	// syntactic sugar for the constructors
	static AntecedentStruct makeInitial() {
		return AntecedentStruct(InitialTag());
	}
	static AntecedentStruct makeUnit(ClauseIdType clause) {
		return AntecedentStruct(UnitTag(), clause);
	}
	static AntecedentStruct makeImplication(ClauseIdType clause, LiteralIdType literal) {
		return AntecedentStruct(ImplicationTag(), clause, literal);
	}
	static AntecedentStruct makeClause(ClauseIdType clause) {
		return AntecedentStruct(ClauseTag(), clause);
	}

	bool isInitial() {
		return _type == kTypeInitial;
	}
	bool isUnit() {
		return _type == kTypeUnit;
	}
	bool isImplication() {
		return _type == kTypeImplication;
	}
	bool isClause() {
		return _type == kTypeClause;
	}

	ClauseIdType getClause() {
		assert(isUnit() || isImplication() || isClause());
		return _clause;
	}
	LiteralIdType getImplication() {
		assert(isImplication());
		return _implication;
	}

	Iterator begin(Solver<PT...> &solver) {
		if(_type == kTypeUnit) {
			return Iterator(UnitTag());
		}else if(_type == kTypeImplication) {
			SeqIterator<LiteralIdType, 1> begin({ _implication }, 0);
			return Iterator(ImplicationTag(), begin);
		}else if(_type == kTypeClause) {
			ClauseRefType ref(solver.clauseSpace, _clause);
			return Iterator(ClauseTag(), ref, ref.beginLits());
		}else throw std::logic_error("Illegal antecedent");
	}
	
	Iterator end(Solver<PT...> &solver) {
		if(_type == kTypeUnit) {
			return Iterator(UnitTag());
		}else if(_type == kTypeImplication) {
			SeqIterator<LiteralIdType, 1> end({ _implication }, 1);
			return Iterator(ImplicationTag(), end);
		}else if(_type == kTypeClause) {
			ClauseRefType ref(solver.clauseSpace, _clause);
			return Iterator(ClauseTag(), ref, ref.endLits());
		}else throw std::logic_error("Illegal antecedent");
	}

	template<typename F>
	void for_each(Solver<PT...> *solver, F functor) {
		if(_type == kTypeImplication) {
			functor(_implication);
		}else if(_type == kTypeClause) {
			auto clause = ClauseRefType{solver->clauseSpace, _clause};
			for(auto it = std::next(clause.beginLits(), 1); it != clause.endLits(); ++it)
				functor(it->inverse().id());
		}else{
			assert(_type == kTypeUnit);
		}
	}

private:
	Type _type;

	ClauseIdType _clause;
	LiteralIdType _implication;
};

} } // namespace satuzk::cdcl

