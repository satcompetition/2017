
#include <thread>
#include <atomic>
#include <mutex>
#include <experimental/optional>
#include <condition_variable>
#include <mpicxx/vector.hpp>

namespace satuzk {
namespace ddc {

struct OffloaderStruct {
	OffloaderStruct();

	void run();
	void shutdown();

	void enqueue(std::function<void()> tasklet);

private:
	boost::fibers::fiber _fiber;

	boost::fibers::mutex _mutex;
	boost::fibers::condition_variable _cv;
	bool _active;
	std::queue<std::function<void()>> _tasklets;
};

static constexpr int kNoRank = -1;
static constexpr int kIllegalId = -1;

struct WorkerId {
	WorkerId()
	: rank(-1), index(-1) { }

	explicit WorkerId(int rank, int index)
	: rank(rank), index(index) { }

	bool operator== (const WorkerId &other) {
		return rank == other.rank && index == other.index;
	}

	int rank;
	int index;
};

// links are pairs (constructor_rank, local_id) where constructor_rank is the rank
// of that process that constructed the node and local_id is a
// unique (for a given constructor_rank) id number.
typedef std::pair<int, int> CubeLink;

enum WorkState {
	kWorkNone,
	kWorkSplit,
	kWorkSolve,
	kActionInterrupt,
	kActionShutdown
};

template<typename... PT>
struct WorkerStruct;

template<typename... PT>
struct SharedDataStruct;

template<typename... PT>
struct SuiteStruct;

template<typename... PT>
struct WorkerHooks {
	using WorkerType = WorkerStruct<PT...>;
	using SharedDataType = SharedDataStruct<PT...>;

	using CubeClause = typename SharedDataType::CubeClause;

	using SolverType = cdcl::Solver<cdcl::UseHooks<WorkerHooks<PT...>>>;
	using LiteralIdType = typename SolverType::LiteralIdType;
	using ClauseRefType = typename SolverType::ClauseRefType;

	WorkerHooks(WorkerType *worker)
	: _worker{worker} { }

	void emitProof(ClauseRefType) { }
	void reduceProof(ClauseRefType) { }

	void onLearnClause(ClauseRefType clause) {
		constexpr bool enableExchange = true;

		if(!enableExchange)
			return;

		if(clause.length() > 1)
			return;

		std::vector<LiteralIdType> lits;
		for(auto it = clause.beginLits(); it != clause.endLits(); ++it)
			lits.push_back(it->id());

		_worker->exportQueue.push_back(CubeClause{clause.name(), lits, clause.globalLbd()});
		_worker->cycleQueue.push_back(CubeClause{clause.name(), std::move(lits), clause.globalLbd()});
		_worker->numExports++;
	}

	template<typename C>
	void onClauseCompaction(C *compactor) {
		_worker->inprocessor.onClauseCompaction(compactor);
	}
	void onReductionIncrement() { }

private:
	WorkerType *_worker;
};

template<typename... PT>
struct SharedDataStruct {
	using SolverType = cdcl::Solver<cdcl::UseHooks<WorkerHooks<PT...>>>;
	using LiteralIdType = typename SolverType::LiteralIdType;
	using VariableRefType = typename SolverType::VariableRefType;
	using LiteralRefType = typename SolverType::LiteralRefType;
	using ClauseNameType = typename SolverType::ClauseNameType;

	using SuiteType = SuiteStruct<PT...>;

	struct CubeClause {
		ClauseNameType name;
		std::vector<LiteralIdType> literals;
		unsigned int lbd;
	};

	struct CubeChild {
		CubeLink link;
		int childNumWorkers;
		bool childCollapsed;
	};

	struct CubeNode {
		CubeNode(SuiteType &suite, CubeLink this_link, CubeLink parent_link,
				std::vector<LiteralIdType> cube_literals, std::vector<CubeClause> cube_clauses);
		
		// --------------------------------------------------------------------
		// Standard routing path.
		// --------------------------------------------------------------------
public:
		void routeDown(std::unique_lock<std::mutex> &guard, std::vector<WorkerId> workers);
		void routeUp(std::unique_lock<std::mutex> &guard, CubeLink child_link, std::vector<WorkerId> workers);

private:
		void _performRoute(std::unique_lock<std::mutex> &guard);

		// --------------------------------------------------------------------
		// Divide- and conquer progress functions.
		// --------------------------------------------------------------------
public:
		void completeSplit(std::unique_lock<std::mutex> &guard,
				std::vector<CubeLink> child_links);
		void terminateSplit(std::unique_lock<std::mutex> &guard);

		void onProgress(std::unique_lock<std::mutex> &guard, uint64_t num_conflicts);
		void interruptSolve(std::unique_lock<std::mutex> &guard, WorkerId worker);
		void completeSolve(std::unique_lock<std::mutex> &guard, WorkerId worker);
		void terminateSolve(std::unique_lock<std::mutex> &guard, WorkerId worker);

		void shutdownWaiters(std::unique_lock<std::mutex> &guard);

		// Setup or reset this cube's clauses and failed literals.
		void setupCube(SolverType &solver);
		void resetCube(SolverType &solver);
		
		SuiteType &suite;

		const CubeLink thisLink;
		const CubeLink parentLink;
		
		const std::vector<LiteralIdType> cubeLiterals;
		const std::vector<CubeClause> cubeClauses;
		
		std::mutex mutex;
	
	private:
		bool _isActive() {
			return state != kWorkNone;
		}
		bool _isClosed() {
			return _conquerClosed || (_expanded && numCollapsedChildren == children.size());
		}
		bool _isOpen() {
			return _expanded && numCollapsedChildren < children.size();
		}
		bool _wantRace() {
			auto num_workers = activeTeam.size() + waitingWorkers.size();
			return num_workers <= 1 || _conflictProgress <= 10000;
		}

		// NOTE: local to the constructor; protected by the mutex
		std::vector<WorkerId> activeTeam;
		std::vector<WorkerId> waitingWorkers;
		
		// NOTE: local to the constructor; protected by the mutex
		bool _expanded;
		bool _conquerClosed;
		std::vector<CubeChild> children;

		WorkState state;
		bool _interrupted;
		uint64_t _conflictProgress;

		// number of children with childCollapsed == true
		// NOTE: local to the constructor; protected by the mutex
		int numCollapsedChildren;
	};

	SharedDataStruct(SuiteType *suite);

	std::vector<CubeNode *> gatherOwnVertices();	
	CubeNode *atNode(std::unique_lock<std::mutex> &guard, CubeLink link);
	CubeNode *findNode(std::unique_lock<std::mutex> &guard, CubeLink link);
	void insertNode(std::unique_lock<std::mutex> &guard, CubeLink link, std::unique_ptr<CubeNode> node);
	
	std::mutex treeMutex;

	// this is only relevant at the root
	boost::fibers::mutex globalMutex;
	SolveState globalSolveState;
	std::vector<LiteralIdType> model;
	
	// setting this to true shuts down the whole suite
	std::atomic<bool> terminateFlag;

private:
	SuiteType *_suite;

	std::map<CubeLink, std::unique_ptr<CubeNode>> cubeTree;
};

template<typename... PT>
struct WorkerStruct {
	using SolverType = cdcl::Solver<cdcl::UseHooks<WorkerHooks<PT...>>>;
	using VariableIdType = typename SolverType::VariableIdType;
	using LiteralIdType = typename SolverType::LiteralIdType;
	using VariableRefType = typename SolverType::VariableRefType;
	using LiteralRefType = typename SolverType::LiteralRefType;
	using ClauseRefType = typename SolverType::ClauseRefType;
	using ClauseNameType = typename SolverType::ClauseNameType;

	using SuiteType = SuiteStruct<PT...>;
	using SharedDataType = SharedDataStruct<PT...>;

	typedef typename SharedDataType::CubeClause CubeClause;
	typedef typename SharedDataType::CubeNode CubeNode;

	static constexpr size_t maxExchangeBuffer = 1024;

	struct WorkTask {
		WorkTask(WorkState state);

		WorkState state;
		CubeNode *node;
		std::vector<WorkerId> team;
	};

	WorkerStruct(SuiteType &suite, int index);

	void navigate(CubeLink link);
	
	CubeNode *currentVertex() {
		assert(!vertexStack.empty());
		return vertexStack.back();
	}
	
	void doSplit(CubeLink link);
	void splitAsCaptain();
	void splitAsWorker();
	void evaluateSplit(dist_balancer::Balancer<mpicxx::trivial_mapping<uint32_t>> *balancer,
			cdcl::LookaheadResult &result,
			std::vector<std::pair<LiteralRefType, cdcl::LookaheadValue>> &values,
			std::vector<ClauseRefType> &failed);
	
	void startSolve(CubeLink link);
	void doSolve();

	void setupCube();
	void resetCube();

	void collectClauses();

	void initialize(std::string instance);
	void initialize(SolverType *src_solver);
	void run();
	void join();
	
	void enqueue(std::unique_lock<std::mutex> &guard, WorkTask task);
	
	SuiteType &suite;
	WorkerId thisId;

	std::mutex queueMutex;

	SharedDataType &sharedData;
	SolverType solver;

	cdcl::ThoroughInprocessor<
		cdcl::UseHooks<WorkerHooks<PT...>>
	> inprocessor;

	cdcl::SatisfiedReduction<
		cdcl::UseHooks<WorkerHooks<PT...>>
	> satisfiedReduction;

//	SimplifyConfigStruct<Defs> p_simplifyConfig;
	
	WorkState workState;
	bool interruptState;
	uint64_t _lastReportConflicts;
	uint64_t _lastReportPropagations;
	std::vector<WorkerId> currentTeam;
	std::vector<CubeNode *> vertexStack;

	std::vector<uint32_t> exchangeRecvBuffer;
	std::vector<uint32_t> exchangeSendBuffer;
	std::vector<CubeClause> importQueue;
	std::vector<CubeClause> exportQueue;
	std::vector<CubeClause> cycleQueue;

	std::mutex intraMutex;
	std::atomic<bool> intraReady;
	std::vector<CubeClause> intraQueue;

	sys::HptCounter splitTime;
	sys::HptCounter solveTime;
	uint64_t numDivide;
	uint64_t numVertices;
	uint64_t numDirect;
	uint64_t numInterruptions;
	uint64_t numImports;
	uint64_t numExports;

	MPIx_Hub hub;

private:
	boost::fibers::fiber _fiber;
	dist_balancer::Context<mpicxx::trivial_mapping<uint32_t>> _balanceContext;

	std::queue<WorkTask> taskQueue;
};

template<typename... PT>
struct ServerStruct {
	using SolverType = cdcl::Solver<cdcl::UseHooks<WorkerHooks<PT...>>>;
	using LiteralIdType = typename SolverType::LiteralIdType;

	using SuiteType = SuiteStruct<PT...>;
	using SharedDataType = SharedDataStruct<PT...>;
	using WorkerType = WorkerStruct<PT...>;

	ServerStruct(SuiteType &suite);
	
	SharedDataType &sharedData();

	void run();
	void join();

	SuiteType &suite;

private:
	void receiveCommand(int source, int opcode, int peer);

	boost::fibers::fiber _fiber;
	bool _cancel;
};

template<typename... PT>
struct SuiteStruct {
	using SolverType = cdcl::Solver<cdcl::UseHooks<WorkerHooks<PT...>>>;
	using LiteralIdType = typename SolverType::LiteralIdType;
	using ClauseNameType = typename SolverType::ClauseNameType;

	using SharedDataType = SharedDataStruct<PT...>;
	using WorkerType = WorkerStruct<PT...>;
	using ServerType = ServerStruct<PT...>;
	
	typedef typename SharedDataType::CubeClause CubeClause;

	SuiteStruct(int workers_per_node);

	SolveState run(std::string instance);
	
	void mergeNode(CubeLink parent_link, CubeLink node_link);

	mpicxx::comm seqComm;
	mpicxx::comm balanceComm;
	mpicxx::comm exchangeComm;

	const int configuredWorkersPerNode;

	const int worldRank;
	const int worldSize;

	MPI_Datatype commandType;
	const MPI_Datatype workerIdType;
	const MPI_Datatype linkMsgType;
	const MPI_Datatype branchMsgType;
	const MPI_Datatype splitValueMsgType;

	size_t memoryBudget;

	int actualWorkersPerNode;

	std::atomic<int> nextGeneratedId;

	SharedDataType sharedData;

	// NOTE: we have to heap-allocate the workers because they contain non-moveable fields
	std::vector<std::unique_ptr<WorkerType>> workers;
};

} } // namespace satuzk::ddc

