
#include <stdint.h>

typedef int64_t sys_msecs_t;

sys_msecs_t sysGetWallTime();
sys_msecs_t sysGetCpuTime();

int sysPeakMemory();

#include <iostream>

