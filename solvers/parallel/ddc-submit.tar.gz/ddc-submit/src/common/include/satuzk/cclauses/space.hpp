
#include <stddef.h>

namespace satuzk {

namespace ClauseAllocation {
	enum { // TODO: Make this an enum class.
		permanent = 1,
		frozen = 2
	};
}

namespace cclauses {

// flags that disable expensive debugging checks
constexpr bool kDbgCheckNewClauses = false;

struct ClauseNameStruct {
	ClauseNameStruct() = default;

	ClauseNameStruct(uint64_t bits)
	: _bits(bits) { }

	ClauseNameStruct(uint16_t origin, uint64_t local)
	: _bits((uint64_t(origin) << 48) | local) {
		// make sure that the local part uses only 48-bits
		assert((local % (uint64_t(1) << 48)) == local);
	}

	bool operator== (ClauseNameStruct other) const {
		return _bits == other._bits;
	}
	bool operator< (ClauseNameStruct other) const {
		if(origin() != other.origin())
			return origin() < other.origin();
		return local() < other.local();
	}

	uint64_t bits() const {
		return _bits;
	}

	uint16_t origin() const {
		return _bits >> 48;
	}
	uint64_t local() const {
		return _bits % (uint64_t(1) << 48);
	}

private:
	uint64_t _bits;
};

std::ostream &operator<<(std::ostream &out, ClauseNameStruct name) {
	out << "(" << name.origin() << "/" << name.local() << ")";
	return out;
}

/*template<typename... PT>
struct NameToIdMapStruct {
	typedef ClauseId<PT...> ClauseIdType;
	typedef ClauseNameStruct ClauseNameType;

	void insert(ClauseNameType name, ClauseIdType id) { }

	ClauseIdType at(ClauseNameType name) {
		assert(!"NameToIdMap is disabled in this policy");
	}

	void update(ClauseNameType name, ClauseIdType id) { }
	void remove(ClauseNameType name) { }
};*/

static constexpr bool _profileNameToIdMap = false;

template<typename... PT>
struct NameToIdMapStruct {
	typedef ClauseId<PT...> ClauseIdType;
	typedef ClauseNameStruct ClauseNameType;
	typedef ClauseRef<PT...> ClauseRefType;
	typedef ClauseSpace<PT...> ClauseSpaceType;

	// The factor 4 was chosen empricially. Reducing the fill factor even more
	// does not seem to improve solve time.
	static constexpr unsigned int inverseFillLimit = 4;

public:
	// even the smallest instances contain thousands of clauses:
	// initialize the table size with 1024.
	NameToIdMapStruct(ClauseSpaceType *space)
	: _space(space), _maintain(true), _bucketShift(10), _table(size_t(1) << _bucketShift), _numItems(0),
			_maxProbes(0) {
		assert(_bucketShift < 32);
	}

	bool maintain() {
		return _maintain;
	}

	void insert(ClauseNameType name, ClauseIdType id, bool nested = false) {
		if(!_maintain)
			return;

		if(inverseFillLimit * _numItems >= (size_t(1) << _bucketShift)) {
			// for now the table only grows, so we just increment _bucketShift
			auto new_shift = _bucketShift + 1;
			assert(_numItems < (size_t(1) << new_shift));

			if(_profileNameToIdMap) {
				std::cout << "Fill factor: " << (float(_numItems) / (size_t(1) << _bucketShift))
						<< "; rehash to shift: " << new_shift << std::endl;
			}

			// TODO: this self-assignment is not the most beautiful construct
			assert(!nested);
			*this = NameToIdMapStruct(Rehash(), _space, new_shift,
					_table.begin(), _table.end());
		}

		size_t h = _hash(name);
		for(uint32_t k = 1; ; k++) {
			assert(k <= (size_t(1) << _bucketShift));

			// make sure the name does not already exist
			size_t p = (h + k - 1) % (size_t(1) << _bucketShift);
			assert(!(_table[p] && ClauseRefType(*_space, _table[p]).name() == name));

			if(!_table[p]) {
				_table[p] = id;

				if(k > _maxProbes) {
					if(_profileNameToIdMap)
						std::cout << "maxProbes: " << k << std::endl;
					_maxProbes = k;
				}
				_numItems++;
				break;
			}
		}
	}

	ClauseIdType at(ClauseNameType name) {
		assert(_maintain);

		size_t h = _hash(name);
		for(uint32_t k = 1; ; k++) {
			assert(k <= _maxProbes);

			size_t p = (h + k - 1) % (size_t(1) << _bucketShift);
			if(_table[p] && ClauseRefType(*_space, _table[p]).name() == name)
				return _table[p];
		}
	}

/*
	// This method must not assume that the table is currently correct!
	// It is called during clause compaction.
	void updateDirty(ClauseNameType name, ClauseIdType id, ClauseIdType prospective) {
		size_t h = _hash(name);
		for(uint32_t k = 1; ; k++) {
			assert(k <= _maxProbes);

			size_t p = (h + k - 1) % (size_t(1) << _bucketShift);
			if(_table[p] == id) {
				_table[p] = prospective;
				return;
			}
		}
	}

	// This method must not assume that the table is currently correct!
	// It is called during clause compaction.
	void removeDirty(ClauseNameType name, ClauseIdType id) {
		size_t h = _hash(name);
		for(uint32_t k = 1; ; k++) {
			assert(k <= _maxProbes);

			size_t p = (h + k - 1) % (size_t(1) << _bucketShift);
			if(_table[p] == id) {
				assert(_numItems > 0);
				_table[p] = ClauseIdType();
				_numItems--;
				return;
			}
		}
	}
*/
	template<typename C>
	void compact(C *compactor) {
		assert(_maintain);

		for(auto it = _table.begin(); it != _table.end(); ++it) {
			if(!(*it))
				continue;

			ClauseRefType clause{*_space, *it};
			if(clause.isPresent()) {
				compactor->compact(clause);
				*it = clause.prospectiveId();
			}else{
				assert(_numItems > 0);
				*it = ClauseIdType{};
				_numItems--;
			}
		}
	}

private:
	struct Rehash { };

	template<typename Iterator>
	NameToIdMapStruct(Rehash, ClauseSpaceType *space,
			size_t new_shift, Iterator begin, Iterator end)
	: _space(space), _maintain(true), _bucketShift(new_shift), _table(size_t(1) << _bucketShift), _numItems(0),
			_maxProbes(0) {
		// do not allow rehashing here 
		for(auto it = begin; it != end; ++it)
			if(*it)
				insert(ClauseRefType(*_space, *it).name(), *it, true);
	}

	size_t _hash(ClauseNameType name) {
		return name.local() * 0x1F1F1F1F1F1F1F1F + name.origin();
	}

	ClauseSpaceType *_space;
	bool _maintain;
	size_t _bucketShift;
	std::vector<ClauseIdType> _table;
	size_t _numItems;
	size_t _maxProbes;
};

template<typename... PT>
class ClauseSpaceStruct {
public:

	typedef LiteralId<PT...> LiteralIdType;
	typedef Index<PT...> IndexType;
	typedef ClauseId<PT...> ClauseIdType;
	typedef ClauseNameStruct ClauseNameType;
	typedef ClauseSize<PT...> ClauseSizeType;
	typedef Activity<PT...> ActivityType;
	
	typedef VariableSpace<PT...> VariableSpaceType;
	typedef typename VariableSpace<PT...>::LiteralRef LiteralRefType;
	typedef Hooks<PT...> HooksType;

	typedef util::memory::memory_arena AllocatorType;
	typedef NameToIdMapStruct<PT...> NameToIdType;
	
	struct ClauseHead {
		// Clause is deleted. The clause is still allocated but not used anymore.
		static const uint32_t kFlagDelete = 0x1;
		// Clause is frozen. It is not installed but will be reinstalled later.
		static const uint32_t kFlagFrozen = 0x2;
		// Marked essential. Essential clauses must must not be deleted or frozen.
		static const uint32_t kFlagEssential = 0x4;
		// Marked important. Important clauses must must not be deleted;
		// however they may be frozen.
		static const uint32_t kFlagImportant = 0x8;
		// Clause has been moved/dropped during garbage collection.
		static const uint32_t kFlagReducible = 0x10;
		// Clause has been moved/dropped during garbage collection.
		static const uint32_t kFlagCompacted = 0x20;
		// Clause will not be removed in next reduction.
		static const uint32_t kFlagSpared = 0x40;

		// The clause has been marked by some algorithm.
		// Algorithms should remove this mark after they are done.
		static const int stampShift = 24;
		static const uint32_t stampMask = 0xFF;

		// Flags defined above.
		uint32_t flags;

		// Number of literals of the clause.
		ClauseSizeType numLiterals;

		LiteralIdType literals[];
	};

	struct ActivityMixin {
		ActivityType activity;
		uint16_t globalLbd;
		uint16_t localLbd;
	};

	struct ClauseTail {
		union {
			struct {
				ClauseNameType name;
				uint64_t signature;
			} normalTail;
			
			struct {
				IndexType destination;
			} movedTail;
		};
	};

	struct BaseComplex : ClauseTail, ClauseHead { };
	struct ReducibleComplex : ActivityMixin, BaseComplex { };

	static_assert(std::is_trivially_copyable<ClauseHead>::value, "ClauseHead not trivial");
	static_assert(std::is_trivially_copyable<ClauseTail>::value, "ClauseTail not trivial");
	
	using SpaceSizeType = size_t;

	// The number of bits that we are going to use for our index.
	static constexpr int indexBits = sizeof(IndexType) * 8;

	// We can take advantage of clause alignment to increase the arena size.
	// This takes advantage of the fact that small shifts are free in x86 address calculations.
	static constexpr int extraShift = 2;
	static_assert(alignof(ClauseHead) >= size_t(1) << extraShift);

	// The limit for memory arena that are supported for this clause space.
	static constexpr SpaceSizeType arenaLimit = (SpaceSizeType(1) << (indexBits + extraShift)) - 1;

	struct ClauseRef;

	struct ReducibleView {
		struct Iterator
			: public std::iterator<std::forward_iterator_tag, ClauseIdType> {
		public:
			Iterator(ClauseSpaceStruct *space, IndexType index)
				: _space{space}, _index{index} { }
			
			void operator++ () {
				_index++;
			}
			bool operator== (const Iterator &other) const {
				return _index == other._index;
			}
			bool operator!= (const Iterator &other) const {
				return !(*this == other);
			}
			ClauseRef operator* () const {
				return ClauseRef{*_space, _space->_reducible[_index]};
			}
			ArrowProxy<ClauseRef> operator-> () const {
				return ArrowProxy<ClauseRef>(**this);
			}
			
		private:
			ClauseSpaceStruct *_space;
			// Index into the _reducible array.
			IndexType _index;
		};

		ReducibleView(ClauseSpaceStruct *space)
		: _space{space} { }

		Iterator begin() {
			return Iterator(_space, 0);
		}

		Iterator end() {
			return Iterator(_space, _space->_reducible.size());
		}

	private:
		ClauseSpaceStruct *_space;
	};

	struct PermanentView {
		struct Iterator
			: public std::iterator<std::forward_iterator_tag, ClauseIdType> {
		public:
			Iterator(ClauseSpaceStruct *space, IndexType index)
				: _space{space}, _index{index} { }
			
			void operator++ () {
				_index++;
			}
			bool operator== (const Iterator &other) const {
				return _index == other._index;
			}
			bool operator!= (const Iterator &other) const {
				return !(*this == other);
			}
			ClauseRef operator* () const {
				return ClauseRef{*_space, _space->_permanent[_index]};
			}
			ArrowProxy<ClauseRef> operator-> () const {
				return ArrowProxy<ClauseRef>(**this);
			}
			
		private:
			ClauseSpaceStruct *_space;
			// Index into the _permanent array.
			IndexType _index;
		};

		PermanentView(ClauseSpaceStruct *space)
		: _space{space} { }

		Iterator begin() {
			return Iterator(_space, 0);
		}

		Iterator end() {
			return Iterator(_space, _space->_permanent.size());
		}

	private:
		ClauseSpaceStruct *_space;
	};

	struct LiteralIterator {
	friend class ClauseRef;

		LiteralIterator(ClauseSpaceStruct &space, ClauseIdType id, ClauseSizeType index)
		: _varSpace(space.varSpace) {
			_pointer = &space._accessHead(id.getIndex())->literals[index];
		}

		// Iterator concept
		LiteralIterator &operator++ () {
			_pointer++;
			return *this;
		}
		LiteralRefType operator* () const {
			return LiteralRefType{*_varSpace, *_pointer};
		}

		// InputIterator concept
		bool operator== (const LiteralIterator &other) const {
			return _pointer == other._pointer;
		}
		bool operator!= (const LiteralIterator &other) const {
			return !(*this == other);
		}
		ArrowProxy<LiteralRefType> operator-> () const {
			return ArrowProxy<LiteralRefType>(**this);
		}
		LiteralIterator operator++ (int) {
			LiteralIterator copy = *this;
			++(*this);
			return copy;
		}
	
	public:
		// std::iterator_traits typedefs
		typedef std::input_iterator_tag iterator_category;
		typedef LiteralRefType value_type;

		typedef decltype(*std::declval<LiteralIterator>()) reference;
		typedef std::add_pointer_t<reference> pointer;
		typedef ptrdiff_t difference_type;
		
	private:
		VariableSpaceType *_varSpace;
		LiteralIdType *_pointer;
	};

	class ClauseRef {
	public:
		typedef ClauseSpaceStruct::LiteralIterator LiteralIterator;

		friend std::ostream &operator<<(std::ostream &out, ClauseRef clause) {
			for(auto it = clause.beginLits(); it != clause.endLits(); ++it)
				out << (it == clause.beginLits() ? "[" : ", ") << it->toNumber();
			out << "]";
			return out;
		}

		ClauseRef()
		: _space(nullptr) { }

		ClauseRef(ClauseSpaceStruct &space, ClauseIdType id)
		: _space(&space), _id(id) { }

		ClauseSpaceStruct &space() {
			return *_space;
		}

		ClauseIdType id() const {
			return _id;
		}

		explicit operator bool () {
			return _space;
		}

		bool operator== (const ClauseRef &other) {
			return other._space && _id == other._id;
		}

		IndexType getIndex() const {
			return _id.getIndex();
		}

		size_t length() {
			return _space->clauseLength(_id);
		}

		void prefetchHeadNonTemporal() {
			auto head = _space->_accessHead(getIndex());
			__builtin_prefetch(head, 0, 0);
		}

		void prefetchLits() {
			auto head = _space->_accessHead(getIndex());
			__builtin_prefetch(&head->literals[2]);
		}

		uint64_t signature() {
			auto head = _space->_accessHead(getIndex());
			assert(!(head->flags & ClauseHead::kFlagCompacted));

			auto tail = _space->_accessTail(getIndex());
			return tail->normalTail.signature;
		}

		LiteralIterator beginLits() {
			return LiteralIterator(*_space, _id, 0);
		}
		LiteralIterator endLits() {
			return LiteralIterator(*_space, _id, _space->clauseLength(_id));
		}

		LiteralIdType assertedWatch() {
			// TODO: this assertion is expensive as it is called from propagation
//			assert(length() >= 1);
			return beginLits()->id();
		}
		LiteralIdType triggerWatch() {
			// TODO: this assertion is expensive as it is called from propagation
//			assert(length() >= 2);
			return std::next(beginLits())->id();
		}
		void swapWatches() {
			// TODO: this assertion is expensive as it is called from propagation
//			assert(length() >= 2);
			std::swap(*beginLits()._pointer, *std::next(beginLits())._pointer);
		}
		void updateTriggerWatch(LiteralIterator it) {
			// TODO: this assertion is expensive as it is called from propagation
//			assert(length() >= 2);
			std::swap(*std::next(beginLits())._pointer, *it._pointer);
		}

		ClauseNameType name() {
			auto head = _space->_accessHead(getIndex());
			assert(!(head->flags & ClauseHead::kFlagCompacted));

			auto tail = _space->_accessTail(getIndex());
			return tail->normalTail.name;
		}

		bool isPresent() {
			auto head = _space->_accessHead(getIndex());
			return !(head->flags & ClauseHead::kFlagDelete);
		}
		void erase(bool urgent = false) {
			auto head = _space->_accessHead(getIndex());
			assert(!(head->flags & ClauseHead::kFlagEssential));
			assert(!(head->flags & ClauseHead::kFlagImportant));

			assert(!(head->flags & ClauseHead::kFlagDelete));
			head->flags |= ClauseHead::kFlagDelete;

			if(!(head->flags & ClauseHead::kFlagFrozen))
				_space->hooks.uninstallClause(*this, urgent);
			_space->hooks.onErase(*this, urgent);
			
			_space->_presentClauses--;
			_space->_presentLiterals -= head->numLiterals;
			_space->_deletedClauses++;
		}

		bool isReducible() {
			auto head = _space->_accessHead(getIndex());
			return head->flags & ClauseHead::kFlagReducible;
		}

		ClauseIdType prospectiveId() {
			auto head = _space->_accessHead(getIndex());
			assert((head->flags & ClauseHead::kFlagCompacted)
					&& !(head->flags & ClauseHead::kFlagDelete));

			auto tail = _space->_accessTail(getIndex());
			return ClauseIdType::fromIndex(tail->movedTail.destination);
		}
		
		void freeze(bool urgent = false) {
			auto head = _space->_accessHead(getIndex());
			assert(!(head->flags & ClauseHead::kFlagFrozen));
			assert(!(head->flags & ClauseHead::kFlagEssential));

			_space->hooks.uninstallClause(*this, urgent);
			head->flags |= ClauseHead::kFlagFrozen;
		}
		void unfreeze() {
			auto head = _space->_accessHead(getIndex());
			assert(head->flags & ClauseHead::kFlagFrozen);

			_space->hooks.installClause(*this);
			head->flags &= ~ClauseHead::kFlagFrozen;
		}
		bool isFrozen() {
			auto head = _space->_accessHead(getIndex());
			return head->flags & ClauseHead::kFlagFrozen;
		}

		bool isEssential() {
			auto head = _space->_accessHead(getIndex());
			return head->flags & ClauseHead::kFlagEssential;
		}
		void markAsEssential() {
			auto head = _space->_accessHead(getIndex());
			assert(!(head->flags & ClauseHead::kFlagEssential));
			head->flags |= ClauseHead::kFlagEssential;

			_space->currentEssentialClauses++;
		}
		void markAsNotEssential() {
			auto head = _space->_accessHead(getIndex());
			assert(head->flags & ClauseHead::kFlagEssential);
			head->flags &= ~ClauseHead::kFlagEssential;

			_space->currentEssentialClauses--;
		}

		bool isImportant() {
			auto head = _space->_accessHead(getIndex());
			return head->flags & ClauseHead::kFlagImportant;
		}
		void markAsImportant() {
			auto head = _space->_accessHead(getIndex());
			assert(!(head->flags & ClauseHead::kFlagImportant));
			head->flags |= ClauseHead::kFlagImportant;
		}
		void markAsNotImportant() {
			auto head = _space->_accessHead(getIndex());
			assert(head->flags & ClauseHead::kFlagImportant);
			head->flags &= ~ClauseHead::kFlagImportant;
		}

		void dropSpecifics() {
			if(isEssential())
				markAsNotEssential();
			if(isImportant())
				markAsNotImportant();
		}
		void forceErase(bool urgent = false) {
			dropSpecifics();
			erase(urgent);
		}
		
		ActivityType getActivity() {
			auto mixin = _space->_accessActivity(getIndex());
			return mixin->activity;
		}
		
		void setActivity(ActivityType activity) {
			auto mixin = _space->_accessActivity(getIndex());
			mixin->activity = activity;
		}
		
		unsigned int globalLbd() {
			auto mixin = _space->_accessActivity(getIndex());
			return mixin->globalLbd;
		}

		unsigned int localLbd() {
			auto mixin = _space->_accessActivity(getIndex());
			return mixin->localLbd;
		}

		void updateLbd(unsigned int lbd) {
			auto mixin = _space->_accessActivity(getIndex());
			assert(lbd <= mixin->globalLbd);
			assert(lbd <= mixin->localLbd);
			mixin->globalLbd = lbd;
			mixin->localLbd = lbd;
		}

		void resetLocalLbd() {
			auto mixin = _space->_accessActivity(getIndex());
			mixin->localLbd = mixin->globalLbd;
		}

		void decreaseLocalLbd(unsigned int lbd) {
			auto mixin = _space->_accessActivity(getIndex());
			assert(lbd <= mixin->localLbd);
			mixin->localLbd = lbd;
		}

		void spare() {
			auto head = _space->_accessHead(getIndex());
			head->flags |= ClauseHead::kFlagSpared;
		}
		bool willBeSpared() {
			auto head = _space->_accessHead(getIndex());
			return head->flags & ClauseHead::kFlagSpared;
		}
		void doNotSpare() {
			auto head = _space->_accessHead(getIndex());
			head->flags &= ~ClauseHead::kFlagSpared;
		}

		void stamp(unsigned int value) {
			assert((value & ClauseHead::stampMask) == value);
			auto head = _space->_accessHead(getIndex());
			head->flags &= ~(ClauseHead::stampMask << ClauseHead::stampShift);
			head->flags |= value << ClauseHead::stampShift;
		}
		unsigned int getStamp() {
			auto head = _space->_accessHead(getIndex());
			return (head->flags >> ClauseHead::stampShift) & ClauseHead::stampMask;
		}

	private:
		ClauseSpaceStruct *_space;
		ClauseIdType _id;
	};

	ClauseSpaceStruct(VariableSpaceType &var_space, HooksType hooks)
	: varSpace(&var_space), hooks(std::move(hooks)),
			_allClauses(0), _allLiterals(0), _presentClauses(0), _presentLiterals(0),
			_deletedClauses(0), currentEssentialClauses(0), _nameToIdMap(this) {
		_allocator.alter(arenaLimit);
		_allocator.reserve(0, 4 * 1024 * 1024);
	}

private:
	static ClauseHead *_accessHead(AllocatorType &allocator, IndexType index) {
		return reinterpret_cast<ClauseHead *>(allocator.get(SpaceSizeType(index) << extraShift));
	}
	static ClauseTail *_accessTail(AllocatorType &allocator, IndexType index) {
		return static_cast<BaseComplex *>(_accessHead(allocator, index));
	}
	static ActivityMixin *_accessActivity(AllocatorType &allocator, IndexType index) {
		auto head = _accessHead(allocator, index);
		assert(head->flags & ClauseHead::kFlagReducible);
		return static_cast<ReducibleComplex *>(head);
	}

	static IndexType calculateClauseSize(bool reducible, ClauseSizeType length) {
		if(reducible) {
			return sizeof(ReducibleComplex) + length * sizeof(LiteralIdType);
		}else{
			return sizeof(BaseComplex) + length * sizeof(LiteralIdType);
		}
	}

	static SpaceSizeType estimateSpaceSize(IndexType num_clauses, size_t num_lits) {
		return num_clauses * SpaceSizeType(alignof(ReducibleComplex) + sizeof(ReducibleComplex))
				+ num_lits * SpaceSizeType(sizeof(LiteralIdType));
	}

private:
	ClauseHead *_accessHead(IndexType index) {
		return _accessHead(_allocator, index);
	}
	ClauseTail *_accessTail(IndexType index) {
		return _accessTail(_allocator, index);
	}
	ActivityMixin *_accessActivity(IndexType index) {
		return _accessActivity(_allocator, index);
	}

public:
	template<typename Iterator>
	ClauseRef allocate(ClauseNameType name, ClauseSizeType length,
			Iterator begin, Iterator end, int allocation = 0) {
		// Sanity check (high performance overhead).
		if(kDbgCheckNewClauses)
			for(auto i = begin; i != end; ++i) {
//FIXME				assert(varIsPresent((*i).variable()));
				for(auto j = begin; j != end; ++j) {
					if(i == j)
						continue;
					assert(*i != *j && *i != (*j).inverse());
				}
			}

		// Actually allocate the clause.
		IndexType index;
		if(!(allocation & ClauseAllocation::permanent)) {
			auto offset = _allocator.reserve_and_allocate(calculateClauseSize(true, length), alignof(ReducibleComplex));
			index = (offset + sizeof(ActivityMixin) + sizeof(ClauseTail)) >> extraShift;
		}else{
			auto offset = _allocator.reserve_and_allocate(calculateClauseSize(false, length), alignof(BaseComplex));
			index = (offset + sizeof(ClauseTail)) >> extraShift;
		}
		ClauseRef clause{*this, ClauseIdType::fromIndex(index)};

		auto head = _accessHead(index);
		head->flags = 0;
		if(!(allocation & ClauseAllocation::permanent))
			head->flags |= ClauseHead::kFlagReducible;
		if(allocation & ClauseAllocation::frozen)
			head->flags |= ClauseHead::kFlagFrozen;
		head->numLiterals = length;

		// Setting LBD to clause length is a conservative estimate.
		auto tail = _accessTail(index);
		tail->normalTail.name = name;

		if(!(allocation & ClauseAllocation::permanent)) {
			auto mixin = _accessActivity(index);
			mixin->activity = 0.0f;
			mixin->globalLbd = length;
			mixin->localLbd = length;
		}

		// Setup the clause's literals.
		uint64_t signature = 0;
		unsigned int sig_size = sizeof(uint64_t) * 8;
		ClauseSizeType k = 0;
		for(Iterator it = begin; it != end && k < length; ++it, ++k) {
			head->literals[k] = *it;
			signature |= (uint64_t{1} << (it->variable().getIndex() % sig_size));
		}
		assert(k == length);
		tail->normalTail.signature = signature;

		// Set up the clause data structures.
		_allClauses++;
		_allLiterals += length;
		_presentClauses++;
		_presentLiterals += length;

		if(!(allocation & ClauseAllocation::permanent)) {
			_reducible.push_back(clause.id());
		}else{
			_permanent.push_back(clause.id());
		}
		_nameToIdMap.insert(name, clause.id());

		hooks.onAllocate(clause);
		if(!(head->flags & ClauseHead::kFlagFrozen))
			hooks.installClause(clause);
		return clause;
	}

	ReducibleView reducible() {
		return ReducibleView{this};
	}
	PermanentView permanent() {
		return PermanentView{this};
	}

	template<typename Functor>
	void forEach(Functor f) {
		// We cannot use _reducible/_permanent here as its iterators
		// might be invalidated by clause allocation.
		for(auto it = reducible().begin(); it != reducible().end(); ++it)
			f(*it);
		for(auto it = permanent().begin(); it != permanent().end(); ++it)
			f(*it);
	}

	ClauseRef findName(ClauseNameType name) {
		return ClauseRef(*this, _nameToIdMap.at(name));
	}

	unsigned int numClauses() {
		return _allClauses;
	}
	unsigned int numPresent() {
		return _presentClauses;
	}
	uint64_t presentLiterals() {
		return _presentLiterals;
	}
	unsigned int numDeleted() {
		return _deletedClauses;
	}
	size_t usedSpace() {
		return _allocator.used_space();
	}
	
	ClauseSizeType clauseLength(ClauseIdType clause) {
		return _accessHead(clause.getIndex())->numLiterals;
	}

	ClauseIdType getMoveDestination(ClauseIdType clause) {
		assert(wasMoved(clause));
		return ClauseIdType::fromIndex(_accessTail(clause.getIndex())->movedTail.destination);
	}

	struct CompactorStruct {
		CompactorStruct(ClauseSpaceStruct *space)
		: _space{space}, _compactedClauses{0}, _compactedLiterals{0} {
			auto current_size = estimateSpaceSize(_space->_presentClauses, _space->_presentLiterals);
			_destAllocator.alter(arenaLimit);
			_destAllocator.reserve(current_size, 4 * 1024 * 1024 + current_size + current_size / 2);
		}
		
		void process() {
			// Allow external code to update clause references.
			_space->hooks.onCompact(this);
		}

		void compact(ClauseRef clause) {
			auto head = _space->_accessHead(clause.getIndex());

			if(head->flags & ClauseHead::kFlagCompacted)
				return;
	
			if(!(head->flags & ClauseHead::kFlagDelete)) {
				IndexType dest_index;
				if(head->flags & ClauseHead::kFlagReducible) {
					size_t size = calculateClauseSize(true, head->numLiterals);	
					auto dest_offset = _destAllocator.allocate(size, alignof(ReducibleComplex));
					dest_index = (dest_offset + sizeof(ActivityMixin) + sizeof(ClauseTail)) >> extraShift;
				}else{
					size_t size = calculateClauseSize(false, head->numLiterals);	
					auto dest_offset = _destAllocator.allocate(size, alignof(BaseComplex));
					dest_index = (dest_offset + sizeof(ClauseTail)) >> extraShift;
				}

				// Copy the clause head, literals, and tail.
				auto dest_head = _accessHead(_destAllocator, dest_index);
				dest_head->flags = head->flags;
				dest_head->numLiterals = head->numLiterals;

				for(size_t k = 0; k < head->numLiterals; k++)
					dest_head->literals[k] = head->literals[k];

				auto tail = _space->_accessTail(clause.getIndex());
				auto dest_tail = _accessTail(_destAllocator, dest_index);
				dest_tail->normalTail.name = tail->normalTail.name;
				dest_tail->normalTail.signature = tail->normalTail.signature;

				if(head->flags & ClauseHead::kFlagReducible) {
					auto mixin = _space->_accessActivity(clause.getIndex());
					auto dest_mixin = _accessActivity(_destAllocator, dest_index);
					dest_mixin->activity = mixin->activity;
					dest_mixin->globalLbd = mixin->globalLbd;
					dest_mixin->localLbd = mixin->localLbd;
				}

				_compactedClauses++;
				_compactedLiterals += head->numLiterals;

				// Mark the original clause as compacted.
				head->flags |= ClauseHead::kFlagCompacted;
				tail->movedTail.destination = dest_index;
			}else{
				// Make sure currentEssentialClauses is correct.
				assert(!(head->flags & ClauseHead::kFlagEssential));

				head->flags |= ClauseHead::kFlagCompacted;
			}
		}

		void commit() {
			auto compactVector = [&] (std::vector<ClauseIdType> &vector) {
				auto wit = vector.begin();
				for(auto rit = vector.begin(); rit != vector.end(); ++rit) {
					ClauseRef clause{*_space, *rit};
					if(!clause.isPresent())
						continue;
					compact(clause);
					*wit++ = clause.prospectiveId();
				}
				vector.erase(wit, vector.end());
			};

			// We compact all remaining clauses here.
			compactVector(_space->_reducible);
			compactVector(_space->_permanent);

			if(_space->_nameToIdMap.maintain())
				_space->_nameToIdMap.compact(this);

			// Finally replace the current allocator by the new one.
			_space->_allocator = std::move(_destAllocator);
			_space->_allClauses = _compactedClauses;
			_space->_allLiterals = _compactedLiterals;
			_space->_presentClauses = _compactedClauses;
			_space->_presentLiterals = _compactedLiterals;
			_space->_deletedClauses = 0;

			// Allow external code to rebuild clause-dependent data structures.
			_space->hooks.afterCompact();
		}

	private:
		ClauseSpaceStruct *_space;

		AllocatorType _destAllocator;
		unsigned int _compactedClauses;
		uint64_t _compactedLiterals;
	};

	bool wantClauseCompaction() {
		return _presentClauses < _allClauses / 2
				|| _presentLiterals < _allLiterals / 2;
	}

	void compactClauses() {
		if(!wantClauseCompaction())
			return;

		CompactorStruct compactor{this};
		compactor.process();
		compactor.commit();
	}

	CompactorStruct grabCompactor() {
		CompactorStruct compactor{this};
		compactor.process();
		return compactor;
	}

	AllocatorType _allocator;
	
	VariableSpaceType *varSpace;
	HooksType hooks;

private:
	unsigned int _allClauses;
	uint64_t _allLiterals;
	unsigned int _presentClauses;
	uint64_t _presentLiterals;
	unsigned int _deletedClauses;

	std::vector<ClauseIdType> _reducible;
	std::vector<ClauseIdType> _permanent;

public:
	size_t currentEssentialClauses;

private:
	NameToIdType _nameToIdMap;
};

} } // namespace satuzk::cclauses

