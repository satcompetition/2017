
namespace satuzk {
namespace cdcl {

template<typename... PT>
class EliminationStack {
public:
	typedef VariableId<PT...> VariableIdType;
	typedef VariableRef<PT...> VariableRefType;
	typedef LiteralId<PT...> LiteralIdType;
	typedef ClauseId<PT...> ClauseIdType;
	typedef ClauseRef<PT...> ClauseRefType;

	typedef ClauseSpace<PT...> ClauseSpaceType;

	typedef satutils::Occlists<
		satutils::UseAtom<LiteralIdType>,
		satutils::UseConstraintId<ClauseIdType>,
		satutils::UseConstraintRef<ClauseRefType>,
		satutils::UseConstraintSpace<ClauseSpaceType>
	> OcclistsType;

private:
	typedef uint32_t Word;

	enum TagType {
		kTagNone,
		kTagFact,
		kTagEquivalent,
		kTagVariableResolution,
		kTagBlockedClause
	};

public:
	struct ModelExtender {
		ModelExtender(EliminationStack *stack)
		: _stack{stack} { }

		// --------------------------------------------------------------------
		// Model extension functions.
		// --------------------------------------------------------------------

		std::vector<LiteralIdType> extend(const std::vector<LiteralIdType> &premodel) {
			// Set all model assignments to the current assignment.
			for(auto literal : premodel)
				_assign(literal);

			for(auto it = _stack->_tags.rbegin(); it != _stack->_tags.rend(); /* no increment */) {
				Word tag = *it++;

				/*if(tag == TagType::kTagFact) {
					auto literal = LiteralIdType::fromIndex(*it++);
					model[literal.variable().toNumber()] = literal.isOneLiteral() ? true3() : false3();
				}else if(tag == TagType::kTagEquivalent) {
					extendEquivalent(solver, it, model);
				}else*/ if(tag == TagType::kTagVariableResolution) {
					_extendVariableResolution(it);
				}else if(tag == TagType::kTagBlockedClause) {
					_extendBlockedClause(it);
				}else throw std::logic_error("Illegal tag\n");
			}

			std::vector<LiteralIdType> model;
			for(const auto &entry : _map) {
				auto variable = VariableIdType::fromIndex(entry.first);
				if(entry.second > 0) {
					model.push_back(variable.positive());
				}else if(entry.second < 0) {
					model.push_back(variable.negative());
				}
			}
			return model;
		}

	private:
		void _extendVariableResolution(std::vector<Word>::reverse_iterator &it) {
			// Try to assign the positivie literal.
			auto variable = VariableIdType::fromIndex(*it++);
			assert(!_seen(variable));
			_assign(variable.positive());

			bool satisfied = true;

			Word ncount = *it++;
			for(Word i = 0; i < ncount; ++i) {
				if(!_checkStoredClause(it))
					satisfied = false;
			}
			
			// If that did not satisfy the formula the negative literal has to be assigned.
			if(!satisfied)
				_assign(variable.negative());
			
			Word pcount = *it++;
			for(Word i = 0; i < pcount; ++i)
				if(!_checkStoredClause(it))
					throw std::logic_error("Stored clause evaluates to false");
		}

		void _extendBlockedClause(std::vector<Word>::reverse_iterator &it) {
			auto blocking = LiteralIdType::fromIndex(*it++);
			if(_checkStoredClause(it))
				return;

			_assign(blocking);
		}

		// --------------------------------------------------------------------
		// Helper functions.
		// --------------------------------------------------------------------
	
		bool _checkStoredClause(std::vector<Word>::reverse_iterator &it) {
			bool satisfied = false;
			Word length = *it++;
			for(Word i = 0; i < length; ++i) {
				if(_isTrue(LiteralIdType::fromIndex(*it++)))
					satisfied = true;
			}
			return satisfied;
		}

	private:
		// --------------------------------------------------------------------
		// Assignment functions.
		// --------------------------------------------------------------------
		
		bool _seen(VariableIdType variable) {
			auto it = _map.find(variable.getIndex());
			return it != _map.end();
		}

		void _assign(LiteralIdType literal) {
			_map[literal.variable().getIndex()] = literal.polarity();
		}

		bool _isTrue(LiteralIdType literal) {
			auto it = _map.find(literal.variable().getIndex());
			if(it == _map.end())
				return false;
			return it->second == literal.polarity();
		}

		EliminationStack *_stack;

		// Maps variable IDs to assigned literal polarities.
		std::unordered_map<
			typename VariableIdType::IndexType,
			int8_t
		> _map;
	};

	void pushFact(SolverStruct<PT...> &solver, LiteralIdType fact);
	void pushEquivalent(SolverStruct<PT...> &solver, VariableIdType variable,
			LiteralIdType zero_equivalent);
	void pushVariableResolution(VariableRefType variable, OcclistsType *occlists);
	void pushBlockedClause(ClauseRefType clause, LiteralIdType blocking);

	void restore(SolverStruct<PT...> &solver);
	
	size_t getUsedSpace() {
		return _tags.size() * sizeof(Word);
	}

private:
	bool touchesEquivalent(SolverStruct<PT...> &solver, std::vector<Word>::iterator &it);
	bool touchesDistributed(SolverStruct<PT...> &solver, std::vector<Word>::iterator &it);
	bool touchesBlockedClause(SolverStruct<PT...> &solver, std::vector<Word>::iterator &it);

	void undoEquivalent(SolverStruct<PT...> &solver, std::vector<Word>::iterator &it);
	void undoDistributed(SolverStruct<PT...> &solver, std::vector<Word>::iterator &it);
	void undoBlockedClause(SolverStruct<PT...> &solver, std::vector<Word>::iterator &it);

	std::vector<Word> _tags;
};

template<typename... PT>
void EliminationStack<PT...>::pushFact(SolverStruct<PT...> &solver, LiteralIdType fact) {
	_tags.push_back(fact.getIndex());
	_tags.push_back(kTagFact);
}

template<typename... PT>
void EliminationStack<PT...>::pushEquivalent(SolverStruct<PT...> &solver, VariableIdType variable,
		LiteralIdType zero_equivalent) {
	_tags.push_back(zero_equivalent.getIndex());
	_tags.push_back(variable.getIndex());
	_tags.push_back(kTagEquivalent);
}

template<typename... PT>
void EliminationStack<PT...>::pushVariableResolution(VariableRefType variable,
			OcclistsType *occlists) {
	// Note that we only have to save the clauses containing either the positive or the negative literal
	// to build the model; but we need all clauses if we want to undo this step.
	
	Word pcount = 0;
	for(auto cit = occlists->begin(variable.positive().id()); cit != occlists->end(variable.positive().id()); ++cit) {
		if(!cit->isPresent() || !cit->isEssential())
			continue;
		for(auto it = cit->beginLits(); it != cit->endLits(); ++it)
			_tags.push_back(it->getIndex());
		_tags.push_back(cit->length());
		pcount++;
	}
	_tags.push_back(pcount);
	
	Word ncount = 0;
	for(auto cit = occlists->begin(variable.negative().id()); cit != occlists->end(variable.negative().id()); ++cit) {
		if(!cit->isPresent() || !cit->isEssential())
			continue;
		for(auto it = cit->beginLits(); it != cit->endLits(); ++it)
			_tags.push_back(it->getIndex());
		_tags.push_back(cit->length());
		ncount++;
	}
	_tags.push_back(ncount);

	_tags.push_back(variable.getIndex());
	_tags.push_back(kTagVariableResolution);
}

template<typename... PT>
void EliminationStack<PT...>::pushBlockedClause(ClauseRefType clause, LiteralIdType blocking) {
	assert(clause.isEssential());

	for(auto it = clause.beginLits(); it != clause.endLits(); ++it)
		_tags.push_back(it->getIndex());
	_tags.push_back(clause.length());

	_tags.push_back(blocking.getIndex());
	_tags.push_back(kTagBlockedClause);
}

/*
template<typename... PT>
template<typename ModelMap>
void EliminationStack<PT...>::extendEquivalent(SolverStruct<PT...> &solver,
		std::vector<Word>::reverse_iterator &it, ModelMap &map) {
	auto var = VariableIdType::fromIndex(*it++);
	auto zero_equivalent = LiteralIdType::fromIndex(*it++);

	Bool3 var_state = map[zero_equivalent.variable().toNumber()];
	if(zero_equivalent.isOneLiteral() ? var_state.isTrue() : var_state.isFalse()) {
		map[var.toNumber()] = false3();
	}else map[var.toNumber()] = true3();
}
*/

template<typename... PT>
void EliminationStack<PT...>::restore(SolverStruct<PT...> &solver) {
	auto first_it = _tags.end();

	int num_items = 0, num_undone = 0;

	auto touch_it = _tags.end();
	while(touch_it != _tags.begin()) {
		Word tag = *(--touch_it);

		if(tag == TagType::kTagFact) {
			// FIXME: implement this
			throw std::logic_error("Not implemented yet");
		}else if(tag == TagType::kTagEquivalent) {
			if(touchesEquivalent(solver, touch_it))
				first_it = touch_it;
		}else if(tag == TagType::kTagVariableResolution) {
			if(touchesDistributed(solver, touch_it))
				first_it = touch_it;
		}else if(tag == TagType::kTagBlockedClause) {
			if(touchesBlockedClause(solver, touch_it))
				first_it = touch_it;
		}else throw std::logic_error("Illegal tag\n");

		num_items++;
	}

	std::vector<VariableIdType> redo_stack;

	auto it = _tags.end();
	while(it != first_it) {
		Word tag = *(--it);
		
		auto it_copy = it, it_copy2 = it;

		if(tag == TagType::kTagFact) {
			// FIXME: implement this
			throw std::logic_error("Not implemented yet");
		}else if(tag == TagType::kTagEquivalent) {
			undoEquivalent(solver, it);
		}else if(tag == TagType::kTagVariableResolution) {
			undoDistributed(solver, it);

			if(!touchesDistributed(solver, it_copy))
				redo_stack.push_back(VariableIdType::fromIndex(*(--it_copy2)));
		}else if(tag == TagType::kTagBlockedClause) {
			undoBlockedClause(solver, it);
		}else throw std::logic_error("Illegal tag\n");

		num_undone++;
	}

	std::cout << "Undo " << num_undone
			<< " of " << num_items << " items" << std::endl;
	
	_tags.erase(it, _tags.end());

	int redo_ops = 0;
	for(auto rs = redo_stack.rbegin(); rs != redo_stack.rend(); ++rs) {
		assert(!solver.varIsProtected(*rs));
		
		if(!vecdIsWorthwhile(solver, *rs, solver.stat.simp.bve))
			continue;
	
		vecdEliminateVariable(solver, *rs, solver.stat.simp.bve);
		solver.deleteVar(*rs);
		redo_ops++;
	}

	std::cout << "Redo " << redo_ops << " of " << redo_stack.size() << " items" << std::endl;
	
	for(auto vp = solver.varsBegin(); vp != solver.varsEnd(); ++vp) {
		if(!solver.p_varConfig.getVarFlagRestore(*vp))
			continue;

		assert(solver.varIsPresent(*vp));
		solver.p_varConfig.clearVarFlagRestore(*vp);
		solver.p_varConfig.clearVarFlagRecoded(*vp);
	}
}

template<typename... PT>
bool EliminationStack<PT...>::touchesEquivalent(SolverStruct<PT...> &solver,
		std::vector<Word>::iterator &it) {
	auto variable = VariableIdType::fromIndex(*(--it));
	auto zero_equivalent = LiteralIdType::fromIndex(*(--it));
	
	return solver.p_varConfig.getVarFlagRestore(variable);
}

template<typename... PT>
bool EliminationStack<PT...>::touchesDistributed(SolverStruct<PT...> &solver,
		std::vector<Word>::iterator &it) {
	auto variable = VariableIdType::fromIndex(*(--it));

	Word zero_count = *(--it);
	for(Word i = 0; i < zero_count; i++) {
		Word length = *(--it);
		it -= length;
	}

	Word one_count = *(--it);
	for(Word i = 0; i < one_count; i++) {
		Word length = *(--it);
		it -= length;
	}
	
	return solver.p_varConfig.getVarFlagRestore(variable);
}

template<typename... PT>
bool EliminationStack<PT...>::touchesBlockedClause(SolverStruct<PT...> &solver,
		std::vector<Word>::iterator &it) {
	auto blocking = LiteralIdType::fromIndex(*(--it));
	
	Word length = *(--it);
	it -= length;

	return solver.p_varConfig.getVarFlagRestore(blocking.variable());
}

template<typename... PT>
void EliminationStack<PT...>::undoEquivalent(SolverStruct<PT...> &solver,
		std::vector<Word>::iterator &it) {
	auto variable = VariableIdType::fromIndex(*(--it));
	solver.undeleteVar(variable);
	
	auto zero_equivalent = LiteralIdType::fromIndex(*(--it));
	std::array<LiteralIdType, 2> lits1 = { variable.oneLiteral(), zero_equivalent };
	std::array<LiteralIdType, 2> lits2 = { variable.zeroLiteral(), zero_equivalent.inverse() };
	auto clause1 = solver.allocClause(2, lits1.begin(), lits1.end());
	auto clause2 = solver.allocClause(2, lits2.begin(), lits2.end());
	solver.clauseSetEssential(clause1);
	solver.clauseSetEssential(clause2);
	solver.installClause(clause1);
	solver.installClause(clause2);
}

template<typename... PT>
void EliminationStack<PT...>::undoDistributed(SolverStruct<PT...> &solver,
		std::vector<Word>::iterator &it) {
	auto variable = VariableIdType::fromIndex(*(--it));
	solver.undeleteVar(variable);

	Word zero_count = *(--it);
	for(Word i = 0; i < zero_count; i++) {
		Word length = *(--it);
		
		std::vector<LiteralIdType> literals;
		literals.resize(length);
		for(Word j = 0; j < length; j++)
			literals[j] = LiteralIdType::fromIndex(*(--it));

		auto clause = solver.allocClause(length, literals.begin(), literals.end());
		solver.clauseSetEssential(clause);
		solver.installClause(clause);
	}

	Word one_count = *(--it);
	for(Word i = 0; i < one_count; i++) {
		Word length = *(--it);
		
		std::vector<LiteralIdType> literals;
		literals.resize(length);
		for(Word j = 0; j < length; j++)
			literals[j] = LiteralIdType::fromIndex(*(--it));

		auto clause = solver.allocClause(length, literals.begin(), literals.end());
		solver.clauseSetEssential(clause);
		solver.installClause(clause);
	}
}

template<typename... PT>
void EliminationStack<PT...>::undoBlockedClause(SolverStruct<PT...> &solver,
		std::vector<Word>::iterator &it) {
	auto blocking = LiteralIdType::fromIndex(*(--it));
	assert(solver.varIsPresent(blocking.variable()));

	// read the blocked clause
	Word length = *(--it);
	
	std::vector<LiteralIdType> literals;
	literals.resize(length);
	for(Word j = 0; j < length; j++)
		literals[j] = LiteralIdType::fromIndex(*(--it));

	auto clause = solver.allocClause(length, literals.begin(), literals.end());
	solver.clauseSetEssential(clause);
	solver.installClause(clause);
}

} } // namespace satuzk::cdcl

