
namespace satuzk {

template<typename Solver>
bool hbImplies(Solver &solver, typename Solver::Literal literal,
		typename Solver::Literal implied) {
	for(auto it = solver.watchBegin(literal); it != solver.watchEnd(literal); ++it) {
		if(!(*it).isBinary())
			continue;

		if((*it).binaryGetImplied() == implied)
			return true;
	}
	return false;
}

template<typename Solver>
bool hbAllLitsInClauseExceptOneImply(Solver &solver, typename Solver::Clause clause,
		typename Solver::Literal except,
		typename Solver::Literal implied) {
	for(auto lp = solver.clauseBegin(clause); lp != solver.clauseEnd(clause); ++lp) {
		if(*lp == except)
			continue;
		if(!hbImplies(solver, *lp, implied))
			return false;
	}
	return true;
}		

template<typename Solver>
void hbResolveClause(Solver &solver, typename Solver::Clause clause,
		typename Solver::Literal literal) {
	assert(solver.clauseLength(clause) >= 3);
	typename Solver::Literal first = solver.clauseGetFirst(clause);
	if(first == literal)
		first = solver.clauseGetSecond(clause);
	for(auto it = solver.watchBegin(first); it != solver.watchEnd(first); ++it) {
		if(!(*it).isBinary())
			continue;
		if(!hbAllLitsInClauseExceptOneImply(solver, clause,
				literal, (*it).binaryGetImplied()))
			continue;
		
		std::array<typename Solver::Literal, 2> lits;
		lits[0] = literal;
		lits[1] = (*it).binaryGetImplied();

		typename Solver::Clause new_clause = solver.allocClause(2,
				lits.begin(), lits.end());
		solver.clauseSetEssential(new_clause);
		solver.installClause(new_clause);
		
		solver.stat.simp.hbNewClauses++;
		return;
	}
}

template<typename Solver>
void hbResolveClause(Solver &solver, typename Solver::Clause clause) {
	for(auto lp = solver.clauseBegin(clause); lp != solver.clauseEnd(clause); ++lp)
		hbResolveClause(solver, clause, *lp);
}

template<typename Solver>
void hbEliminateAll(Solver &solver) {
	std::vector<typename Solver::Clause> queue;
	for(auto cp = solver.clausesBegin(); cp != solver.clausesEnd(); ++cp) {
		if(solver.clauseLength(*cp) < 3)
			continue;
		queue.push_back(*cp);
	}
	
	for(auto cp = queue.begin(); cp != queue.end(); ++cp)
		hbResolveClause(solver, *cp);
}

} // namespace satuzk

