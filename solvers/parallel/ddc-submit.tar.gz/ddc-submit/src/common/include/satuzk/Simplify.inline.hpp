
namespace satuzk {

// --------------------------------------------------------
// BveTechniqueStruct
// --------------------------------------------------------

template<typename Defs>
void BveTechniqueStruct<Defs>::schedule(Solver<Defs> &solver) {
	if(varQueue.empty()) {
		runStats = BveStats();

		for(auto it = solver.varsBegin(); it != solver.varsEnd(); ++it) {
			if(!solver.varIsPresent(*it))
				continue;
			if(solver.varIsProtected(*it))
				continue;
			varQueue.push(*it);
		}
	}
}

template<typename Defs>
bool BveTechniqueStruct<Defs>::isActive() {
	return !varQueue.empty();
}

template<typename Defs>
void BveTechniqueStruct<Defs>::run(Solver<Defs> &solver) {
	assert(!varQueue.empty());

	BveStats step_stats;
	sys::HptCounter start = sys::hptCurrent();

	while(!varQueue.empty()) {
		if(step_stats.ops > 100000)
			break;

		Variable var = varQueue.front();
		varQueue.pop();
		
		if(!solver.varIsPresent(var))
			continue;

		if(!vecdIsWorthwhile(solver, var, step_stats))
			continue;
		vecdEliminateVariable(solver, var, step_stats);
		solver.deleteVar(var);
	}
	step_stats.time += sys::hptElapsed(start);

	runStats += step_stats;
	solver.stat.simp.bve += step_stats;
	solver.perf.inprocTime += step_stats.time;
	
	if(varQueue.empty())
		std::cout << "c [bve] elimVars: " << runStats.elimVars << std::endl;
}

// --------------------------------------------------------
// BceTechniqueStruct
// --------------------------------------------------------

template<typename Defs>
void BceTechniqueStruct<Defs>::schedule(Solver<Defs> &solver) {
	if(clauseQueue.empty()) {
		runStats = BceStats();

		for(auto it = solver.clausesBegin(); it != solver.clausesEnd(); ++it) {
			if(!solver.clauseIsPresent(*it))
				continue;
			if(solver.clauseLength(*it) <= 2)
				continue;
			clauseQueue.push(*it);
		}
	}
}

template<typename Defs>
bool BceTechniqueStruct<Defs>::isActive() {
	return !clauseQueue.empty();
}

template<typename Defs>
void BceTechniqueStruct<Defs>::run(Solver<Defs> &solver) {
	assert(!clauseQueue.empty());

	BceStats step_stats;
	sys::HptCounter start = sys::hptCurrent();

	while(!clauseQueue.empty()) {
		if(step_stats.ops > 100000)
			break;

		Clause clause = clauseQueue.front();
		clauseQueue.pop();
		
		if(!solver.clauseIsPresent(clause))
			continue;

		bceEliminateSingle(solver, clause, step_stats);
	}
	step_stats.time += sys::hptElapsed(start);

	runStats += step_stats;
	solver.stat.simp.bce += step_stats;
	solver.perf.inprocTime += step_stats.time;

	if(clauseQueue.empty())
		std::cout << "c [bce] elimClauses: " << runStats.elimClauses << std::endl;
}

template<typename Defs>
void BceTechniqueStruct<Defs>::collectClauses(Solver<Defs> &solver) {
	size_t num_elems = clauseQueue.size();
	for(size_t i = 0; i < num_elems; i++) {
		Clause clause = clauseQueue.front();
		clauseQueue.pop();

		if(solver.clauseWasMoved(clause))
			clauseQueue.push(solver.clauseMoveDestination(clause));
	}
}

// --------------------------------------------------------
// SubsumeTechniqueStruct
// --------------------------------------------------------

template<typename Defs>
void SubsumeTechniqueStruct<Defs>::schedule(Solver<Defs> &solver) {
	if(clauseQueue.empty()) {
		runStats = SubsumeStats();

		for(auto it = solver.clausesBegin(); it != solver.clausesEnd(); ++it) {
			if(!solver.clauseIsPresent(*it))
				continue;
			if(solver.clauseLength(*it) == 1)
				continue;
			clauseQueue.push(*it);
		}
	}
}

template<typename Defs>
bool SubsumeTechniqueStruct<Defs>::isActive() {
	return !clauseQueue.empty();
}

template<typename Defs>
void SubsumeTechniqueStruct<Defs>::run(Solver<Defs> &solver,
		EffortType<Defs> effort, bool inproc) {
	assert(!clauseQueue.empty());

	SubsumeStats step_stats;
	sys::HptCounter start = sys::hptCurrent();

	while(!clauseQueue.empty()) {
		if(step_stats.ops > effort)
			break;

		Clause clause = clauseQueue.front();
		clauseQueue.pop();
		
		if(!solver.clauseIsPresent(clause))
			continue;

		Literal literal = selfsubShortestOcclist(solver, clause);
		selfsubBackward(solver, clause, literal, step_stats);
	}
	step_stats.time += sys::hptElapsed(start);

	runStats += step_stats;
	solver.stat.simp.subsume += step_stats;
	if(inproc) {
		solver.stat.simp.inprocSubsume += step_stats;
		solver.perf.inprocTime += step_stats.time;
	}

	if(clauseQueue.empty())
		std::cout << "c [subsume] resClauses: " << runStats.resClauses
				<< ", subClauses: " << runStats.subClauses << std::endl;
}

template<typename Defs>
void SubsumeTechniqueStruct<Defs>::collectClauses(Solver<Defs> &solver) {
	size_t num_elems = clauseQueue.size();
	for(size_t i = 0; i < num_elems; i++) {
		Clause clause = clauseQueue.front();
		clauseQueue.pop();

		if(solver.clauseWasMoved(clause))
			clauseQueue.push(solver.clauseMoveDestination(clause));
	}
}

// --------------------------------------------------------
// UnhideTechniqueStruct
// --------------------------------------------------------

template<typename Defs>
void UnhideTechniqueStruct<Defs>::schedule(Solver<Defs> &solver) {
	if(currentPhase == kPhaseNone) {
		runStats = UnhideStats();
		
		observed.clear();
		preorder.clear();
		postorder.clear(),
		root.clear();
		parent.clear();
		stack.clear();
		redundant.clear();

		unsigned int lit_count = solver.numVariables() * 2;
		observed.resize(lit_count, 0);
		preorder.resize(lit_count, 0);
		postorder.resize(lit_count, 0);
		root.resize(lit_count, Literal::illegalLit());
		parent.resize(lit_count, Literal::illegalLit());

		nextTimestamp = 1;

		for(auto it = solver.varsBegin(); it != solver.varsEnd(); ++it) {
			if(!solver.varIsPresent(*it))
				continue;
			varQueue.push_back(*it);
		}
		std::shuffle(varQueue.begin(), varQueue.end(), solver.p_rndEngine);

		equivConfig.initialize(solver);

		currentPhase = kPhaseDiscover;
	}
}

template<typename Defs>
bool UnhideTechniqueStruct<Defs>::isActive() {
	return currentPhase == kPhaseDiscover
			|| currentPhase == kPhaseReduce;
}

template<typename Defs>
void UnhideTechniqueStruct<Defs>::run(Solver<Defs> &solver) {
	UnhideStats step_stats;
	sys::HptCounter start = sys::hptCurrent();

	if(currentPhase == kPhaseDiscover) {
		while(!varQueue.empty()) {
			if(step_stats.ops > 10000)
				break;

			Variable var = varQueue.front();
			varQueue.pop_front();
			
			if(!solver.varIsPresent(var))
				continue;

			Literal zero_lit = var.zeroLiteral();
			Literal one_lit = var.oneLiteral();
			if(preorder[zero_lit.getIndex()] == 0)
				unhideStamp(solver, zero_lit, zero_lit, 0, nextTimestamp,
						observed, preorder, postorder, root, parent, stack, redundant, equivConfig, step_stats);
			if(preorder[one_lit.getIndex()] == 0)
				unhideStamp(solver, one_lit, one_lit, 0, nextTimestamp,
						observed, preorder, postorder, root, parent, stack, redundant, equivConfig, step_stats);
		}
		step_stats.time += sys::hptElapsed(start);

		runStats += step_stats;
		solver.stat.simp.unhide += step_stats;
		solver.perf.inprocTime += step_stats.time;
		
		if(varQueue.empty()) {
			for(auto i = redundant.begin(); i != redundant.end(); ++i) {
				// NOTE: the redundant vector may contain the same clause twice
				if(!solver.clauseIsPresent(*i))
					continue;
				
				if(solver.clauseIsEssential(*i))
					solver.clauseUnsetEssential(*i);
				if(solver.clauseIsInstalled(*i))
					solver.uninstallClause(*i);
				solver.deleteClause(*i);
			}

			// substitute equivalent literals
			equivConfig.replaceAll(solver);

			// queue clauses for hle and hte
			for(auto i = solver.clausesBegin(); i != solver.clausesEnd(); ++i) {
				if(!solver.clauseIsPresent(*i))
					continue;
				clauseQueue.push(*i);
			}

			currentPhase = kPhaseReduce;
		}
	}else if(currentPhase == kPhaseReduce) {
		UnhidingPreoderLt<Defs> comparator(preorder);
		std::vector<Literal> s_plus;
		std::vector<Literal> s_minus;

		while(!clauseQueue.empty()) {
			if(step_stats.ops > 10000)
				break;

			Clause clause = clauseQueue.front();
			clauseQueue.pop();
			
			if(!solver.clauseIsPresent(clause))
				continue;

			s_plus.clear();
			s_minus.clear();
			for(auto j = solver.clauseBegin(clause); j != solver.clauseEnd(clause); ++j) {
				s_plus.push_back(*j);
				s_minus.push_back((*j).inverse());
			}
			std::sort(s_plus.begin(), s_plus.end(), comparator);
			std::sort(s_minus.begin(), s_minus.end(), comparator);
			
			if(unhideHte(solver, clause, preorder, postorder, s_plus, s_minus, step_stats)) {
				if(solver.clauseIsEssential(clause))
					solver.clauseUnsetEssential(clause);
				if(solver.clauseIsInstalled(clause))
					solver.uninstallClause(clause);
				solver.deleteClause(clause);
				
				step_stats.hteClauses++;
			}else unhideHle(solver, clause, preorder, postorder,
					s_plus, s_minus, step_stats);
		}
		step_stats.time += sys::hptElapsed(start);

		runStats += step_stats;
		solver.stat.simp.unhide += step_stats;
		solver.perf.inprocTime += step_stats.time;

		if(clauseQueue.empty()) {
			std::cout << "c [unhide] hteClauses: " << runStats.hteClauses
					<< ", hleLiterals: " << runStats.hleLiterals << std::endl;
			
			currentPhase = kPhaseNone;
		}
	}else throw std::logic_error("Illegal phase");
}

template<typename Defs>
void UnhideTechniqueStruct<Defs>::collectClauses(Solver<Defs> &solver) {
	// update the redundant clauses vector
	auto wp = redundant.begin();
	for(auto rp = redundant.begin(); rp != redundant.end(); ++rp) {
		if(solver.clauseWasMoved(*rp)) {
			*wp = solver.clauseMoveDestination(*rp);
			wp++;
		}
	}
	redundant.erase(wp, redundant.end());
	
	// update the clause queue
	size_t num_elems = clauseQueue.size();
	for(size_t i = 0; i < num_elems; i++) {
		Clause clause = clauseQueue.front();
		clauseQueue.pop();

		if(solver.clauseWasMoved(clause))
			clauseQueue.push(solver.clauseMoveDestination(clause));
	}
}

// --------------------------------------------------------
// SimplifyConfigStruct
// --------------------------------------------------------

template<typename Defs>
SimplifyConfigStruct<Defs>::SimplifyConfigStruct()
		: enableBve(true), enableBce(true), enableSubsume(true), enableUnhide(true) { }

template<typename Defs>
void SimplifyConfigStruct<Defs>::preprocess(Solver<Defs> &solver) {
	for(int i = 0; i < 100; i++) {
		if(enableBve)
			bveTechnique.schedule(solver);
		if(enableBce)
			bceTechnique.schedule(solver);
		if(enableSubsume)
			subsumeTechnique.schedule(solver);
		if(enableUnhide)
			unhideTechnique.schedule(solver);

		if(enableBve && bveTechnique.isActive())
			bveTechnique.run(solver);
		if(enableBce && bceTechnique.isActive())
			bceTechnique.run(solver);
		if(enableSubsume && subsumeTechnique.isActive())
			subsumeTechnique.run(solver, 100000, false);
		if(enableUnhide && unhideTechnique.isActive())
			unhideTechnique.run(solver);
	}
}

template<typename Defs>
void SimplifyConfigStruct<Defs>::simplifyPass(Solver<Defs> &solver) {
	if(enableBve)
		bveTechnique.schedule(solver);
	if(enableBce)
		bceTechnique.schedule(solver);
	if(enableSubsume)
		subsumeTechnique.schedule(solver);
	if(enableUnhide)
		unhideTechnique.schedule(solver);

	if(enableBve && bveTechnique.isActive())
		bveTechnique.run(solver);
	if(enableBce && bceTechnique.isActive())
		bceTechnique.run(solver);
	if(enableSubsume && subsumeTechnique.isActive())
		subsumeTechnique.run(solver, 10000, true);
	if(enableUnhide && unhideTechnique.isActive())
		unhideTechnique.run(solver);
}

template<typename Defs>
void SimplifyConfigStruct<Defs>::collectClauses(Solver<Defs> &solver) {
	bceTechnique.collectClauses(solver);
	subsumeTechnique.collectClauses(solver);
	unhideTechnique.collectClauses(solver);
}

} // namespace satuzk

