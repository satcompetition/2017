
namespace satuzk {
namespace satutils {

// --------------------------------------------------------
// Basic types extracted from policy tags
// --------------------------------------------------------

template<typename T>
struct UseHooks { };

template<typename... PT>
using Hooks = ExtractType<UseHooks, PT...>;

// for OcclistsStruct
template<typename T>
struct UseAtom { };

template<typename T>
struct UseConstraintId { };

template<typename T>
struct UseConstraintRef { };

template<typename T>
struct UseConstraintSpace { };

template<typename... PT>
using Atom = ExtractType<UseAtom, PT...>;

template<typename... PT>
using ConstraintId = ExtractType<UseConstraintId, PT...>;

template<typename... PT>
using ConstraintRef = ExtractType<UseConstraintRef, PT...>;

template<typename... PT>
using ConstraintSpace = ExtractType<UseConstraintSpace, PT...>;

// for AssignmentStruct
template<typename T>
struct UseVariableSpace { };

template<typename... PT>
using VariableSpace = ExtractType<UseVariableSpace, PT...>;

// for AssignmentStruct + TrailStruct
template<typename T>
struct UseAntecedent { };

template<typename T>
struct UseDecisionLevel { };

template<typename... PT>
using Antecedent = ExtractType<UseAntecedent, PT...>;

template<typename... PT>
using DecisionLevel = ExtractType<UseDecisionLevel, PT...>;

// for TrailStruct
template<typename T>
struct UseConflict { };

template<typename T>
struct UseAtomSpace { };

template<typename T>
struct UseTrailIndex { };

template<typename... PT>
using Conflict = ExtractType<UseConflict, PT...>;

template<typename... PT>
using AtomSpace = ExtractType<UseAtomSpace, PT...>;

template<typename... PT>
using TrailIndex = ExtractType<UseTrailIndex, PT...>;

// --------------------------------------------------------
// Forward declarations and normalized API types
// --------------------------------------------------------

template<typename... PT>
class OcclistsStruct;

template<typename... PT>
class AssignmentStruct;

template<typename... PT>
class TrailStruct;

template<typename... PT>
using Occlists = OcclistsStruct<PT...>;

template<typename... PT>
using Assignment = AssignmentStruct<PT...>;

template<typename... PT>
using Trail = TrailStruct<PT...>;

} } // namespace satuzk::satutils

#include "occlist.hpp"
#include "assignment.hpp"
#include "trail.hpp"
#include "dump.hpp"

