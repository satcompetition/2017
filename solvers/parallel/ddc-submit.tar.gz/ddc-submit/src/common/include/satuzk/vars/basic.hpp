
namespace satuzk {
namespace vars {

template<typename... PT>
class VariableIdStruct {
public:
	typedef Index<PT...> IndexType;
	typedef LiteralId<PT...> LiteralIdType;
	
	static VariableIdStruct illegalVar() {
		return VariableIdStruct(-1);
	}
	static VariableIdStruct fromIndex(IndexType index) {
		return VariableIdStruct(index);
	}
	static VariableIdStruct fromNumber(int64_t number) {
		return VariableIdStruct(number - 1);
	}
	
	VariableIdStruct() : p_index(-1) { }
	
	IndexType getIndex() const {
		return p_index;
	}
	int64_t toNumber() const {
		return p_index + 1;
	}
	
	bool operator== (const VariableIdStruct &other) const {
		return p_index == other.p_index;
	}
	bool operator!= (const VariableIdStruct &other) const {
		return p_index != other.p_index;
	}

	LiteralIdType zeroLiteral() const;
	LiteralIdType oneLiteral() const;

	LiteralIdType positive() const {
		return oneLiteral();
	}
	LiteralIdType negative() const {
		return zeroLiteral();
	}

private:
	explicit VariableIdStruct(IndexType index) : p_index(index) { }
	
	IndexType p_index;
};

template <typename... PT>
class LiteralIdStruct {
public:
	typedef Index<PT...> IndexType;
	typedef VariableId<PT...> VariableIdType;
	
	static LiteralIdStruct illegalLit() {
		return LiteralIdStruct(-1);
	}
	static LiteralIdStruct fromIndex(IndexType index) {
		return LiteralIdStruct(index);
	}
	static LiteralIdStruct fromNumber(int64_t number) {
		return number < 0 ? (VariableIdType::fromNumber(-number)).zeroLiteral()
				: (VariableIdType::fromNumber(number)).oneLiteral();
	}

	LiteralIdStruct() : p_index(-1) { }
	
	IndexType getIndex() const {
		return p_index;
	}
	int64_t toNumber() const {
		return isOneLiteral() ? variable().toNumber() : -variable().toNumber();
	}
	
	bool operator== (const LiteralIdStruct &other) const {
		return p_index == other.p_index;
	}
	bool operator!= (const LiteralIdStruct &other) const {
		return p_index != other.p_index;
	}
	bool operator< (const LiteralIdStruct &other) const {
		return p_index < other.p_index;
	}

	VariableIdType variable() const {
		return VariableIdType::fromIndex(p_index >> 1);
	}
	
	bool isPositive() const {
		return p_index & 1;
	}
	bool isNegative() const {
		return !(p_index & 1);
	}
	bool isOneLiteral() const {
		return p_index & 1;
	}
	int polarity() const {
		return isPositive() ? 1 : -1;
	}
	LiteralIdStruct inverse() const {
		return LiteralIdStruct::fromIndex(p_index ^ 1);
	}

private:
	explicit LiteralIdStruct(IndexType index) : p_index(index) { }
	
	IndexType p_index;
};

template <typename... PT>
auto VariableIdStruct<PT...>::zeroLiteral() const -> LiteralIdType{
	return LiteralIdType::fromIndex(p_index << 1);
}
template <typename... PT>
auto VariableIdStruct<PT...>::oneLiteral() const -> LiteralIdType {
	return LiteralIdType::fromIndex((p_index << 1) + 1);
}

} } // namespace satuzk::vars

namespace std {

template<typename... PT>
struct hash<satuzk::vars::VariableIdStruct<PT...>> {
	size_t operator() (satuzk::vars::VariableIdStruct<PT...> variable) const {
		return (size_t)variable.getIndex();
	}
};

} // namespace std

