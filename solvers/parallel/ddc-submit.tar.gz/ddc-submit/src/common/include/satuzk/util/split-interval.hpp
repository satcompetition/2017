#ifndef SATUZK_UTIL_SPLIT_INTERVAL_HPP
#define SATUZK_UTIL_SPLIT_INTERVAL_HPP

// result: (start index, part size, is_small_part)
std::tuple<int, int, bool> splitInterval(int work_size, int num_parts, int part_rank) {
	assert(num_parts > 0);
	assert(part_rank < num_parts);
	int part_size = work_size / num_parts;
	int plus1_break = work_size % num_parts;

	if(part_rank < plus1_break) {
		int start_index = (part_size + 1) * part_rank;
		return std::make_tuple(start_index, part_size + 1, false);
	}else{
		int start_index = (part_size + 1) * plus1_break
				+ part_size * (part_rank - plus1_break);
		return std::make_tuple(start_index, part_size,
				plus1_break == 0);
	}
}

#endif // SATUZK_UTIL_SPLIT_INTERVAL_HPP
