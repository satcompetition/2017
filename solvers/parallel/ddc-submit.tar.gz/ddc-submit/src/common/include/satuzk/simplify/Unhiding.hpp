
namespace satuzk {

struct UnhideStats {
	uint64_t transitiveEdges;
	uint64_t failedLiterals;
	uint64_t equivalentLiterals;
	uint64_t hleLiterals;
	uint64_t hleClauses;
	uint64_t hteClauses;
	std::chrono::nanoseconds time;
	
	inline UnhideStats() : transitiveEdges(0), failedLiterals(0), equivalentLiterals(0),
			hleLiterals(0), hleClauses(0), hteClauses(0), time(0) { }

	inline UnhideStats &operator+= (const UnhideStats &other) {
		transitiveEdges += other.transitiveEdges;
		failedLiterals += other.failedLiterals;
		equivalentLiterals += other.equivalentLiterals;
		hleLiterals += other.hleLiterals;
		hleClauses += other.hleClauses;
		hteClauses += other.hteClauses;
		time += other.time;
		return *this;
	}
};

} // namespace satuzk

