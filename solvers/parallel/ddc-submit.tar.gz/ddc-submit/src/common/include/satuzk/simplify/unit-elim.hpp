
namespace satuzk {
namespace cdcl {

template<typename... PT>
struct SimplificationTracker {
	using VariableIdType = VariableId<PT...>;
	using VariableRefType = VariableRef<PT...>;
	using ClauseIdType = ClauseId<PT...>;
	using ClauseRefType = ClauseRef<PT...>;
	using ClauseSpaceType = ClauseSpace<PT...>;

	SimplificationTracker(ClauseSpaceType *clause_space)
	: _clauseSpace{clause_space} { }

	~SimplificationTracker() {
		// The user should make sure that the queues are cleared.
	}

	template<typename C>
	void onClauseCompaction(C *compactor) {
		auto compact = [&] (std::vector<ClauseRefType> &v) {
			auto wit = v.begin();
			for(auto rit = v.begin(); rit != v.end(); ++rit) {
				if(!rit->isPresent())
					continue;
				compactor->compact(*rit);
				*wit++ = ClauseRefType{*_clauseSpace, rit->prospectiveId()};
			}
			v.erase(wit, v.end());
		};

		compact(_queuedNewClauses);
		compact(_queuedStrengthened);
		compact(_gatheredNewClauses);
		compact(_gatheredStrengthened);
	}

	void touch(VariableRefType variable) {
		if(variable.getStamp())
			return;
		variable.stamp(1);
		_queuedVars.push_back(variable);
	}

	void markNewClause(ClauseRefType clause) {
		if(clause.getStamp() & 1)
			return;
		clause.stamp(clause.getStamp() | 1);
		_queuedNewClauses.push_back(clause);
	}

	void markStrengthened(ClauseRefType clause) {
		if(clause.getStamp() & 2)
			return;
		clause.stamp(clause.getStamp() | 2);
		_queuedStrengthened.push_back(clause);
	}

	void gather() {
		for(auto variable : _queuedVars)
			variable.stamp(0);
		for(auto clause : _queuedNewClauses)
			clause.stamp(0);
		for(auto clause : _queuedStrengthened)
			clause.stamp(0);

		using std::swap;
		swap(_gatheredVars, _queuedVars);
		swap(_gatheredNewClauses, _queuedNewClauses);
		swap(_gatheredStrengthened, _queuedStrengthened);
		_queuedVars.clear();
		_queuedNewClauses.clear();
		_queuedStrengthened.clear();
	}

	// Variable iterators are valid until the next gather().
	size_t numVars() {
		return _gatheredVars.size();
	}
	auto beginVars() {
		return _gatheredVars.begin();
	}
	auto endVars() {
		return _gatheredVars.end();
	}

	// Clause iterators are valid until the next gather().
	size_t numNewClauses() {
		return _gatheredNewClauses.size();
	}
	auto beginNewClauses() {
		return _gatheredNewClauses.begin();
	}
	auto endNewClauses() {
		return _gatheredNewClauses.end();
	}

	size_t numStrengthened() {
		return _gatheredStrengthened.size();
	}
	auto beginStrengthened() {
		return _gatheredStrengthened.begin();
	}
	auto endStrengthened() {
		return _gatheredStrengthened.end();
	}

	auto clean() {
		for(auto variable : _queuedVars)
			variable.stamp(0);
		for(auto clause : _queuedNewClauses)
			clause.stamp(0);
		for(auto clause : _queuedStrengthened)
			clause.stamp(0);

		_queuedVars.clear();
		_queuedNewClauses.clear();
		_queuedStrengthened.clear();
		_gatheredVars.clear();
		_gatheredNewClauses.clear();
		_gatheredStrengthened.clear();
	}

private:
	ClauseSpaceType *_clauseSpace;

	// TODO: Storing RefTypes involves unnecessary overhead.
	std::vector<VariableRefType> _queuedVars;
	std::vector<ClauseRefType> _queuedNewClauses;
	std::vector<ClauseRefType> _queuedStrengthened;
	
	std::vector<VariableRefType> _gatheredVars;
	std::vector<ClauseRefType> _gatheredNewClauses;
	std::vector<ClauseRefType> _gatheredStrengthened;
};

struct UnitElimStats {
	uint64_t elimClauses;
	uint64_t strengthenedClauses;
	std::chrono::nanoseconds time;

	inline UnitElimStats() : elimClauses{0}, strengthenedClauses{0}, time{0} { }
};

template<typename... PT>
struct UnitElimination {
	using LiteralIdType = LiteralId<PT...>;
	using LiteralRefType = LiteralRef<PT...>;
	using ClauseRefType = ClauseRef<PT...>;
	using AntecedentType = Antecedent<PT...>;
	using SolverType = Solver<PT...>;

	static void perform(SolverType *solver, UnitElimStats &stats) {
		assert(solver->trail.isReset());
		auto start = sys::ThreadClock::now();

		solver->trail.start();
		assert(solver->trail.currentLevel() == 0);

		if(solver->trail.conflict()) {
			std::cerr << "c UnitElimination detected a conflict." << std::endl;
			solver->trail.reset();
			stats.time += sys::ThreadClock::now() - start;
			return;
		}

		auto num_units = solver->trail.indexOfNextLevel(0);

		// Only perform simplification if there are new units.
//		if(num_units == _lastUnitCount)
//			return;

		// Resolve all propagated units to unit clauses.
		for(size_t i = 0; i < num_units; i++) {
			auto literal = solver->trail.atomAt(i);
			auto antecedent = solver->assignment.antecedent(literal.variable());
			if(antecedent.isUnit())
				continue;
			assert(antecedent.isClause() || antecedent.isImplication());

			std::array<LiteralIdType, 1> lits{literal.id()};
			auto unit = solver->clauseSpace.allocate(solver->uniqueClauseName(), 1, lits.begin(), lits.end());
			unit.markAsEssential();

			solver->assignment.updateAntecedent(literal.variable().id(),
					AntecedentType::makeUnit(unit.id()));
		}

		std::vector<LiteralIdType> resolvent;

		// Find all clauses that are satisfied by units only.
		solver->clauseSpace.forEach([&] (ClauseRefType clause) {
			if(!clause.isPresent())
				return;
			if(clause.length() <= 1)
				return;

			auto it = clause.beginLits();
			for(; it != clause.endLits(); ++it) {
				if(solver->assignment.isTrue(*it))
					break;
				if(solver->assignment.isAssigned(it->variable()))
					continue;
				resolvent.push_back(it->id());
			}

			if(it != clause.endLits()) {
				// The clause is satisfied by units only.
				solver->_hooks.reduceProof(clause);
				clause.forceErase();
				stats.elimClauses++;
			}else if(resolvent.size() < clause.length()) {
				// The clause contains inverses of units and can be shortened.
				auto new_clause = solver->clauseSpace.allocate(solver->uniqueClauseName(), resolvent.size(),
						resolvent.begin(), resolvent.end());
				if(clause.isEssential())
					new_clause.markAsEssential();
				solver->_hooks.emitProof(new_clause);

				solver->_hooks.reduceProof(clause);
				clause.forceErase();
				stats.strengthenedClauses++;
			}
			resolvent.clear();
		});
		solver->varSpace.cleanWatches(&solver->clauseSpace);

		solver->trail.reset();
		stats.time += sys::ThreadClock::now() - start;
		return;
	}


private:
};

} } // namespace satuzk::cdcl

