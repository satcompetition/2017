
namespace satuzk {
namespace cdcl {

template<typename... PT>
class VsidsStateStruct {
private:
	typedef VariableId<PT...> VariableIdType;
	typedef Activity<PT...> ActivityType;
	typedef uint32_t HeapIndexType;
	
	struct VarState {
		VarState()
		: activity(0), heapIndex(HeapIndexType(-1)) { }

		ActivityType activity;
		HeapIndexType heapIndex;
	};

	struct HeapPolicy {
		typedef VariableIdType ItemType;

		typedef typename std::vector<VariableIdType>::iterator Iterator;

		HeapPolicy(VsidsStateStruct &state)
		: _state(&state) { }

		bool isLess(ItemType left, ItemType right) {
			// NOTE: we want a maximum heap so we are comparing for ">"
			return _state->getActivity(left) > _state->getActivity(right);
		}

		void insert(Iterator it) {
			HeapIndexType new_index = it - _state->_activityHeap.begin();

			HeapIndexType &heap_index = _state->_varState[it->getIndex()].heapIndex;
			assert(heap_index == HeapIndexType(-1));
			heap_index = new_index;
		}
		void remove(Iterator previous) {
			HeapIndexType previous_index = previous - _state->_activityHeap.begin();
			
			HeapIndexType &heap_index = _state->_varState[previous->getIndex()].heapIndex;
			assert(heap_index == previous_index);
			heap_index = HeapIndexType(-1);
		}
		void update(Iterator it, Iterator previous) {
			HeapIndexType new_index = it - _state->_activityHeap.begin();
			HeapIndexType previous_index = previous - _state->_activityHeap.begin();
			
			HeapIndexType &heap_index = _state->_varState[it->getIndex()].heapIndex;
			assert(heap_index == previous_index);
			heap_index = new_index;
		}
	
	private:
		VsidsStateStruct *_state;
	};
	
	typedef util::BinaryHeap<HeapPolicy> ActivityHeapType;
	
public:
	VsidsStateStruct() : _activityHeap(HeapPolicy(*this)) { }

	void resizeVariables(size_t num_variables) {
		_varState.resize(num_variables);
	}

	void onAllocVariable(VariableIdType variable) {
		_activityHeap.insert(variable);
	}
	
	ActivityType getActivity(VariableIdType variable) {
		return _varState[variable.getIndex()].activity;
	}
	
	ActivityType raiseActivity(VariableIdType variable, ActivityType value) {
		ActivityType activity = _varState[variable.getIndex()].activity + value;
		_varState[variable.getIndex()].activity = activity;
		
		if(isInserted(variable))
			_activityHeap.moveUp(_activityHeap.begin()
					+ _varState[variable.getIndex()].heapIndex);
		
		return activity;
	}

	void scaleActivity(ActivityType divisor) {
		for(auto it = _varState.begin(); it != _varState.end(); ++it)
			it->activity /= divisor;
	}

	void insertVariable(VariableIdType variable) {
		_activityHeap.insert(variable);
	}
	void removeVariable(VariableIdType variable) {
		_activityHeap.remove(_activityHeap.begin()
				+ _varState[variable.getIndex()].heapIndex);
	}

	bool isInserted(VariableIdType variable) {
		return _varState[variable.getIndex()].heapIndex != HeapIndexType(-1);
	}

	bool hasMaximum() {
		return !_activityHeap.empty();
	}
	VariableIdType removeMaximum() {
		assert(!_activityHeap.empty());

		VariableIdType minimum = _activityHeap.front();
		assert(isInserted(minimum));
		_activityHeap.remove(_activityHeap.begin());
		assert(!isInserted(minimum));
		return minimum;
	}
	
private:
	std::vector<VarState> _varState;
	util::BinaryHeap<HeapPolicy> _activityHeap;
};

} } // namespace satuzk::cdcl

