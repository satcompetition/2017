
namespace satuzk {

template<typename Defs>
void EquivConfigStruct<Defs>::replaceClause(Solver<Defs> &hooks, ClauseType<Defs> clause) {
	int changes = 0;
	std::vector<LiteralType<Defs>> new_literals;
	for(auto lp = hooks.clauseBegin(clause); lp != hooks.clauseEnd(clause); ++lp) {
		auto equivalent = getRoot(*lp);
		if(equivalent != *lp)
			changes++;		

		// TODO: unfortunately this has quadratic runtime
		// check if the literal became redundant
		int polarity = findPolarity(new_literals.begin(),
				new_literals.end(), equivalent.variable());
		if(polarity == equivalent.polarity())
			continue;
		
		// check if the new clause is a tautology
		if(polarity != 0) {
			if(hooks.clauseIsEssential(clause))
				hooks.clauseUnsetEssential(clause);
			if(hooks.clauseIsInstalled(clause))
				hooks.uninstallClause(clause);
			hooks.deleteClause(clause);
			return;
		}
		
		new_literals.push_back(equivalent);
	}
	if(changes == 0)
		return;
	
	auto new_clause = hooks.allocClause(new_literals.size(),
			new_literals.begin(), new_literals.end());
	if(hooks.clauseIsEssential(clause))
		hooks.clauseSetEssential(new_clause);
	
	if(hooks.clauseIsFrozen(clause)) {
		hooks.quickFreezeClause(new_clause);
	}else{
		hooks.installClause(new_clause);
	}
	
	if(hooks.clauseIsEssential(clause))
		hooks.clauseUnsetEssential(clause);
	if(hooks.clauseIsInstalled(clause))
		hooks.uninstallClause(clause);
	hooks.deleteClause(clause);
}

template<typename Defs>
void EquivConfigStruct<Defs>::replaceAll(Solver<Defs> &hooks) {
	for(auto it = hooks.varsBegin(); it != hooks.varsEnd(); ++it) {
		if(!hooks.varIsPresent(*it))
			continue;
		
		auto l0 = (*it).zeroLiteral();
		auto root0 = getRoot(l0);
		
		if(root0 == l0)
			continue;

		if(!hooks.varIsPresent(root0.variable()))
			resetEquivalent(*it);
	}

	std::vector<ClauseType<Defs>> queue;
	for(auto i = hooks.clausesBegin(); i != hooks.clausesEnd(); ++i) {
		if(!hooks.clauseIsPresent(*i))
			continue;
		queue.push_back(*i);
	}
	for(auto i = queue.begin(); i != queue.end(); ++i)
		replaceClause(hooks, *i);
	
	for(auto it = hooks.varsBegin(); it != hooks.varsEnd(); ++it) {
		if(!hooks.varIsPresent(*it))
			continue;
		
		auto l0 = (*it).zeroLiteral();
		auto root0 = getRoot(l0);

		if(root0 == l0)
			continue;

//		hooks.p_extModelConfig.pushEquivalent(hooks, *it, root0);
//		hooks.deleteVar(*it);
		hooks.stat.simp.sccVariables++;
	}
}

} // namespace satuzk

