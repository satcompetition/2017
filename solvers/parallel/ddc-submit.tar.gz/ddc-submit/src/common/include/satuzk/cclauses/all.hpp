
namespace satuzk {
namespace cclauses {

// --------------------------------------------------------
// Basic types extracted from policy tags
// --------------------------------------------------------

template<typename T>
struct UseIndex { };

template<typename T>
struct UseClauseSize { };

template<typename T>
struct UseLiteralId { };

template<typename T>
struct UseActivity { };

template<typename T>
struct UseVariableSpace { };

template<typename T>
struct UseHooks { };

template<typename... PT>
using Index = ExtractType<UseIndex, PT...>;

template<typename... PT>
using ClauseSize = ExtractType<UseClauseSize, PT...>;

template<typename... PT>
using LiteralId = ExtractType<UseLiteralId, PT...>;

template<typename... PT>
using Activity = ExtractType<UseActivity, PT...>;

template<typename... PT>
using VariableSpace = ExtractType<UseVariableSpace, PT...>;

template<typename... PT>
using Hooks = ExtractType<UseHooks, PT...>;

// --------------------------------------------------------
// Forward declarations and normalized API types
// --------------------------------------------------------

template<typename... PT>
class ClauseIdStruct;

class ClauseNameStruct;

template<typename... PT>
class ClauseSpaceStruct;

template<typename... PT>
using ClauseId = ClauseIdStruct<
	UseIndex<Index<PT...>>
>;

template<typename... PT>
using ClauseName = ClauseNameStruct;

template<typename... PT>
using ClauseSpace = ClauseSpaceStruct<
	UseIndex<Index<PT...>>,
	UseClauseSize<ClauseSize<PT...>>,
	UseLiteralId<LiteralId<PT...>>,
	UseActivity<Activity<PT...>>,
	UseVariableSpace<VariableSpace<PT...>>,
	UseHooks<Hooks<PT...>>
>;

template<typename... PT>
using ClauseRef = typename ClauseSpaceStruct<PT...>::ClauseRef;

} } // namespace satuzk::cclauses

#include "basic.hpp"
#include "space.hpp"

