
#include "split-interval.hpp"

struct MpiGuardStruct {
	MpiGuardStruct() {
		int provided;
		MPI_Init_thread(NULL, NULL, MPI_THREAD_MULTIPLE, &provided);
		if(provided != MPI_THREAD_MULTIPLE)
			throw std::runtime_error("Need MPI_THREAD_MULTIPLE");
	}

	~MpiGuardStruct() {
		MPI_Finalize();
	}
};

