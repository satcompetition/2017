
namespace satuzk {
namespace cdcl {

template<typename... PT>
class LearnStateStruct {
public:
	typedef VariableId<PT...> VariableIdType;
	typedef LiteralId<PT...> LiteralIdType;
	typedef VariableRef<PT...> VariableRefType;
	typedef LiteralRef<PT...> LiteralRefType;

	typedef Antecedent<PT...> AntecedentType;
	typedef Conflict<PT...> ConflictType;
	typedef DecisionLevel<PT...> DecisionLevelType;
	typedef TrailIndex<PT...> TrailIndexType;

	typedef uint64_t LevelSignatureType;

	struct VarState {
		enum {
			kFlagTouched = 1,
			kFlagMarked = 2,
			kFlagRedundant = 16,
			kFlagNotRedundant = 32
		};

		VarState()
		: flags(0) { }

		uint8_t flags;
	};

	static LevelSignatureType signatureOfLevel(DecisionLevelType level) {
		return LevelSignatureType(1) << (level % (sizeof(LevelSignatureType) * 8));
	}
	
	// variable state struct for each variable
	std::vector<VarState> _varState;

	// variables that were visited during conflict analysis
	std::vector<VariableIdType> _touchedVars;
	// variables that were visited at the current decision level
//	std::vector<VariableIdType> _touchedVarsOnCurrentLevel;

	// variables that are part of the non-minimized clause
	std::vector<LiteralIdType> _cutVars;
	
	std::vector<std::pair<VariableIdType, bool>> _minimizeStack;

	LevelSignatureType _cutSignature;

	unsigned int _numLiteralsInCut;
	
	LearnStateStruct() : _cutSignature{0}, _numLiteralsInCut{0} { }

public:
	unsigned int cutSize() {
		return _numLiteralsInCut;
	}

	size_t minSize() {
		return _cutVars.size();
	}
	typename std::vector<LiteralIdType>::iterator beginMin() {
		return _cutVars.begin();
	}
	typename std::vector<LiteralIdType>::iterator endMin() {
		return _cutVars.end();
	}

/*
	typename std::vector<VariableIdType>::iterator beginCurlevel() {
		return _touchedVarsOnCurrentLevel.begin();
	}
	typename std::vector<VariableIdType>::iterator endCurlevel() {
		return _touchedVarsOnCurrentLevel.end();
	}
*/

	void onAllocVariable() {
		_varState.push_back(VarState());
	}

	// reset the learning configuration	
	void reset() {
		for(auto it = _touchedVars.begin(); it != _touchedVars.end(); ++it)
			_varState[(*it).getIndex()] = VarState();
		_touchedVars.clear();
		_cutVars.clear();
//		_touchedVarsOnCurrentLevel.clear();
		_cutSignature = 0;
		_numLiteralsInCut = 0;
	}

	void cut(SolverStruct<PT...> &solver, ConflictType conflict) {
		// Reserve space for the 1UIP.
		assert(_cutVars.size() == 0);
		_cutVars.push_back(LiteralIdType::illegalLit());
		_numLiteralsInCut = 1;

		// Visit the cause of the conflict.
		TrailIndexType link_counter = 0;
		conflict.for_each(&solver, [&] (LiteralIdType literal) {
			assert(solver.assignment.isTrue(literal));
			_visitVariable(solver, literal, link_counter);
		});
		
		TrailIndexType trail_index = solver.trail.trailLength();
		while(true) {
			assert(trail_index > 0);
			trail_index--;

			LiteralIdType literal = solver.trail.atomAtIndex(trail_index);
			VariableIdType var = literal.variable();
			VarState &var_state = _varState[var.getIndex()];
			assert(solver.varDeclevel(var) == solver.trail.currentLevel());
		
			if((var_state.flags & VarState::kFlagMarked) == 0)
				continue;
			
			link_counter--;
			if(link_counter == 0) {
				// add the first-uip to the clause
				if((var_state.flags & VarState::kFlagTouched) == 0) {
					_touchedVars.push_back(var);
					var_state.flags |= VarState::kFlagTouched;
				}
				_cutSignature |= signatureOfLevel(solver.trail.currentLevel());
				_cutVars[0] = literal.inverse();
				break;
			}else{
				_visitAntecedent(solver, var, link_counter);
			}
		}

		// Minimize the conflict clause.
		auto p = [&] (LiteralIdType literal) -> bool {
			return _isRedundant(solver, literal.variable());
		};
		_cutVars.erase(std::remove_if(_cutVars.begin(), _cutVars.end(), p),
				_cutVars.end());

		// Swap the second watched literal to the front.
		assert(_cutVars.size());
		if(_cutVars.size() > 1) {
			auto c = [&] (LiteralIdType a, LiteralIdType b) -> bool {
				return solver.assignment.level(a.variable()) < solver.assignment.level(b.variable());
			};

			// The reordering below seems to perform better than this swap.
			// TODO: It seems that at least for some benchmarks, even sorting
			// the clause by decision level is beneficial.
//			std::swap(_cutVars[1], *std::max_element(std::next(_cutVars.begin()), _cutVars.end(), c));

			auto index = std::max_element(_cutVars.begin() + 1, _cutVars.end(), c) - _cutVars.begin();
			auto temp = _cutVars[index];
			for(size_t i = 1; i <= index; i++)
				std::swap(temp, _cutVars[i]);
		}
	}

private:
	void _visitVariable(SolverStruct<PT...> &solver,
			LiteralIdType literal, TrailIndexType &link_counter) {
		VarState &cause_state = _varState[literal.variable().getIndex()];
		if((cause_state.flags & VarState::kFlagMarked) != 0)
			return;

		// mark cause literals; increment activity
		_touchedVars.push_back(literal.variable());
		cause_state.flags |= VarState::kFlagTouched;
		cause_state.flags |= VarState::kFlagMarked;
		solver.onVarActivity(literal.variable());

		if(solver.varDeclevel(literal.variable()) < solver.trail.currentLevel()) {
			// add decision variables to the clause
			_cutSignature |= signatureOfLevel(solver.varDeclevel(literal.variable()));
			_cutVars.push_back(literal.inverse());
			_numLiteralsInCut++;
		}else{
//			_touchedVarsOnCurrentLevel.push_back(literal.variable());
			link_counter++;
		}
	}

	void _visitAntecedent(SolverStruct<PT...> &solver,
			VariableIdType var, TrailIndexType &link_counter) {
		auto antecedent = solver.varAntecedent(var);
		if(antecedent.isInitial())
			return;

		solver.onAntecedentActivity(antecedent);
		solver.recomputeLbd(antecedent.getClause());

		antecedent.for_each(&solver, [&] (LiteralIdType reason) {
			assert(solver.assignment.isTrue(reason));
			_visitVariable(solver, reason, link_counter);
		});
	}

	// checks whether a given literal is implied by the conflict clause
	bool _isRedundant(SolverStruct<PT...> &solver,
			VariableIdType variable) {
		auto knownRedundant = [&] (VariableIdType var) -> bool {
			return _varState[var.getIndex()].flags & VarState::kFlagRedundant;
		};
		
		auto knownNotRedundant = [&] (VariableIdType var) -> bool {
			return _varState[var.getIndex()].flags & VarState::kFlagNotRedundant;
		};

		auto markExpandedNotRedundant = [&] () {
			for(auto expanded : _minimizeStack) {
				if(!expanded.second)
					continue;

				if(!(_varState[expanded.first.getIndex()].flags & VarState::kFlagTouched)) {
					_touchedVars.push_back(expanded.first);
					_varState[expanded.first.getIndex()].flags |= VarState::kFlagTouched;
				}

				if(kDbgSlowAssertions)
					assert(!(_varState[expanded.first.getIndex()].flags & VarState::kFlagRedundant));
				_varState[expanded.first.getIndex()].flags |= VarState::kFlagNotRedundant;
			}
		};

		auto markRedundant = [&] (VariableIdType var) {
			if(!(_varState[var.getIndex()].flags & VarState::kFlagTouched)) {
				_touchedVars.push_back(var);
				_varState[var.getIndex()].flags |= VarState::kFlagTouched;
			}
			
			if(kDbgSlowAssertions)
				assert(!(_varState[var.getIndex()].flags & VarState::kFlagNotRedundant));
			_varState[var.getIndex()].flags |= VarState::kFlagRedundant;
		};

		auto root = solver.assignment.antecedent(variable);
		if(root.isInitial())
			return false;

		for(auto it = root.begin(solver); it != root.end(solver); ++it) {
			// The second component of each item on _minimizeStack determines
			// if the variable's antecedent is currently being expanded.
			_minimizeStack.push_back({it->variable(), false});
		}

		while(!_minimizeStack.empty()) {
			auto item = _minimizeStack.back();

			if(!item.second) {
				if(knownRedundant(item.first)) {
					_minimizeStack.pop_back();
					continue;
				}else{
					_minimizeStack.back().second = true;
				}

				auto antecedent = solver.assignment.antecedent(item.first);
				auto sig = signatureOfLevel(solver.assignment.level(item.first));
				if(_varState[item.first.getIndex()].flags & VarState::kFlagMarked) {
					continue;
				}else if(knownNotRedundant(item.first) || antecedent.isInitial() || !(sig & _cutSignature)) {
					markExpandedNotRedundant();
					_minimizeStack.clear();
					return false;
				}

				antecedent.for_each(&solver, [&] (LiteralIdType reason) {
					_minimizeStack.push_back({reason.variable(), false});
				});
			}else{
				markRedundant(item.first);
				_minimizeStack.pop_back();
			}
		}

		return true;
	}
};

} } // namespace satuzk::cdcl

