
// --------------------------------------------------------
// ExtractOr
// --------------------------------------------------------

template<template<typename...> typename P, typename D, typename... Tags>
struct ExtractOrStruct;

template<template<typename...> typename P, typename D,
		typename... E, typename... Tail>
struct ExtractOrStruct<P, D, P<E...>, Tail...> {
	typedef P<E...> Type;
};

template<template<typename...> typename P, typename D,
		typename X, typename... Tail>
struct ExtractOrStruct<P, D, X, Tail...> {
	typedef typename ExtractOrStruct<P, D, Tail...>::Type Type;
};

template<template<typename...> typename P, typename D>
struct ExtractOrStruct<P, D> {
	typedef D Type;
};

template<template<typename...> typename P, typename D, typename... Tags>
using ExtractOr = typename ExtractOrStruct<P, D, Tags...>::Type;

// --------------------------------------------------------
// Extract
// --------------------------------------------------------

template<template<typename...> typename P, typename... Tags>
struct ExtractStruct;

template<template<typename...> typename P,
		typename... E, typename... Tail>
struct ExtractStruct<P, P<E...>, Tail...> {
	typedef P<E...> Type;
};

template<template<typename...> typename P,
		typename X, typename... Tail>
struct ExtractStruct<P, X, Tail...> {
	typedef typename ExtractStruct<P, Tail...>::Type Type;
};

template<template<typename...> typename P, typename... Tags>
using Extract = typename ExtractStruct<P, Tags...>::Type;

// --------------------------------------------------------
// ExtractTypeOr and ExtractType
// --------------------------------------------------------

template<typename T>
struct MatchTypeStruct;

template<template<typename> typename P, typename T>
struct MatchTypeStruct<P<T>> {
	typedef T Type;
};

template<template<typename> typename P, typename D, typename... Tags>
using ExtractTypeOr = typename MatchTypeStruct<ExtractOr<P, P<D>, Tags...>>::Type;

template<template<typename> typename P, typename... Tags>
using ExtractType = typename MatchTypeStruct<Extract<P, Tags...>>::Type;


