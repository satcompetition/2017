
namespace satuzk {
namespace cdcl {

// returns true if the resolvent is trivial
template<typename... PT>
bool resolventTrivial(SolverStruct<PT...> &solver, ClauseId<PT...> clause1, ClauseId<PT...> clause2,
		VariableId<PT...> variable) {
	for(auto i = solver.clauseBegin(clause1); i != solver.clauseEnd(clause1); ++i) {
		auto var = (*i).variable();
		if(var == variable)
			continue;
		int polarity1 = (*i).polarity();
		int polarity2 = findPolarity(solver.clauseBegin(clause2),
				solver.clauseEnd(clause2), var);
		if(polarity1 == -polarity2)
			return true;
	}
	return false;
}

// returns true if the resolvent is trivial. calculates its size otherwise
template<typename... PT>
bool resolventLength(SolverStruct<PT...> &solver, ClauseId<PT...> clause1, ClauseId<PT...> clause2,
		VariableId<PT...> variable, unsigned int &length) {
	length = solver.clauseLength(clause1) + solver.clauseLength(clause2) - 2;
	for(auto i = solver.clauseBegin(clause1); i != solver.clauseEnd(clause1); ++i) {
		auto var = (*i).variable();
		if(var == variable)
			continue;
		int polarity1 = (*i).polarity();
		int polarity2 = findPolarity(solver.clauseBegin(clause2),
				solver.clauseEnd(clause2), var);
		if(polarity1 == -polarity2)
			return true;
		if(polarity1 == polarity2)
			length--;
	}
	return false;
}

// builds the resolvent of the two given clauses
template<typename... PT>
void resolventBuild(SolverStruct<PT...> &solver, ClauseId<PT...> clause1,
		ClauseId<PT...> clause2, VariableId<PT...> variable,
		std::vector<LiteralId<PT...>> &result) {
	for(auto i = solver.clauseBegin(clause1); i != solver.clauseEnd(clause1); ++i) {
		if((*i).variable() == variable)
			continue;
		result.push_back(*i);
	}
	for(auto i = solver.clauseBegin(clause2); i != solver.clauseEnd(clause2); ++i) {
		if((*i).variable() == variable)
			continue;
		if(solver.clauseContains(clause1, *i))
			continue;
		result.push_back(*i);
	}
}

} } // namespace satuzk::cdcl

