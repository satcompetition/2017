
#include <chrono>

namespace sys {

typedef uint64_t HptCounter;

//#define UTIL_PERFORMANCE_GETTIMEOFDAY
#ifdef UTIL_PERFORMANCE_GETTIMEOFDAY
#include <sys/time.h>
inline HptCounter hptCurrent() {
	struct timeval time_struct;
	if(gettimeofday(&time_struct, NULL) != 0)
		throw std::runtime_error("gettimeofday() failed\n");
	return time_struct.tv_sec * 1000LL * 1000LL * 1000LL + time_struct.tv_usec * 1000LL;
}
#else
#include <time.h>
inline HptCounter hptCurrent() {
	timespec time_struct;
	if(clock_gettime(CLOCK_THREAD_CPUTIME_ID, &time_struct) != 0)
		throw std::runtime_error("clock_gettime() failed\n");
	return time_struct.tv_sec * 1000LL * 1000LL * 1000LL + time_struct.tv_nsec;
}
#endif

inline HptCounter hptElapsed(HptCounter since) {
	return hptCurrent() - since;
}

struct ThreadClock {
	typedef int64_t rep;
	typedef std::nano period;
	typedef std::chrono::duration<rep, period> duration;
	typedef std::chrono::time_point<ThreadClock> time_point;

	static const bool is_steady = false;

	static time_point now() {
		timespec spec;
		if(clock_gettime(CLOCK_THREAD_CPUTIME_ID, &spec) != 0)
			throw std::runtime_error("clock_gettime() failed\n");

		duration since_epoch(rep(spec.tv_sec) * 1000000000 + spec.tv_nsec);
		return time_point(since_epoch);
	}

	ThreadClock() = delete;
};

};

