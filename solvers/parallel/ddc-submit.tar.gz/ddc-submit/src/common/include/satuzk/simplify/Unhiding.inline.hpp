
namespace satuzk {
namespace cdcl {

template<typename... PT>
struct Unhiding {
	using VariableIdType = VariableId<PT...>;
	using LiteralIdType = LiteralId<PT...>;
	using ClauseIdType = ClauseId<PT...>;

	using VariableRefType = VariableRef<PT...>;
	using ClauseRefType = ClauseRef<PT...>;
	
	using SolverType = Solver<PT...>;
	using VariableSpaceType = VariableSpace<PT...>;
	using ClauseSpaceType = ClauseSpace<PT...>;

public:
	Unhiding(SolverType *solver, VariableSpaceType *var_space, ClauseSpaceType *clause_space)
	: _solver{solver}, _varSpace{var_space}, _clauseSpace{clause_space} { }

	void processAll(UnhideStats &stats) {
		auto start = sys::ThreadClock::now();

		_observed.clear();
		_preorder.clear();
		_postorder.clear();
		_root.clear();
		_parent.clear();
		_marked.clear();

		unsigned int lit_count = _varSpace->count() * 2;
		_observed.resize(lit_count, 0);
		_preorder.resize(lit_count, 0);
		_postorder.resize(lit_count, 0);
		_root.resize(lit_count, LiteralIdType::illegalLit());
		_parent.resize(lit_count, LiteralIdType::illegalLit());
		_marked.resize(lit_count, false);
		
		_nextStamp = 1;

		std::vector<VariableIdType> var_queue;
		for(auto it = _varSpace->begin(); it != _varSpace->end(); ++it) {
			if(!it->isPresent())
				continue;
			var_queue.push_back(it->id());
		}
		std::shuffle(var_queue.begin(), var_queue.end(), _generator);

		for(auto it = var_queue.begin(); it != var_queue.end(); ++it) {
			if(!_preorder[it->positive().getIndex()]) {
				_stamp(it->positive(), stats);
				assert(_stack.empty());
			}
			if(!_preorder[it->negative().getIndex()]) {
				_stamp(it->negative(), stats);
				assert(_stack.empty());
			}
		}

		// TODO: Substitute equivalent literals.
//		equiv_config.replaceAll(hooks);
		
		// Perform HLE and HTE.
		auto p = [&] (LiteralIdType a, LiteralIdType b) -> bool {
			return _preorder[a.getIndex()] < _preorder[b.getIndex()];
		};
		std::vector<LiteralIdType> s_plus;
		std::vector<LiteralIdType> s_minus;
	
		_clauseSpace->forEach([&] (ClauseRefType clause) {
			if(!clause.isPresent())
				return;
			if(!clause.length())
				return;

			for(auto it = clause.beginLits(); it != clause.endLits(); ++it) {
				s_plus.push_back(it->id());
				s_minus.push_back(it->inverse().id());
			}
			std::sort(s_plus.begin(), s_plus.end(), p);
			std::sort(s_minus.begin(), s_minus.end(), p);

			constexpr bool enableHte = true;
			if(enableHte && _checkHte(clause, s_plus, s_minus)) {
				_solver->_hooks.reduceProof(clause);
				clause.forceErase();
				stats.hteClauses++;
			}else _performHle(clause, s_plus, s_minus, stats);

			s_plus.clear();
			s_minus.clear();
		});

		// Re-sort the watch lists.
		for(auto vit = _varSpace->begin(); vit != _varSpace->end(); ++vit) {
			auto sortWatches = [&] (LiteralIdType literal) {
				std::sort(_varSpace->watchBegin(literal), _varSpace->watchEnd(literal), [] (auto w1, auto w2) {
					return w1.getClause().getIndex() < w2.getClause().getIndex();
				});
			};

			sortWatches(vit->positive().id());
			sortWatches(vit->negative().id());
		}

		stats.time += sys::ThreadClock::now() - start;
	}

private:
	void _stamp(LiteralIdType this_root, UnhideStats &stats) {
		auto doCall = [&] (LiteralIdType argument) {
			std::shuffle(_varSpace->watchBegin(argument), _varSpace->watchEnd(argument), _generator);

			_calls.push_back({argument, _varSpace->watchBegin(argument), true});
			auto &f = _calls.back();

			VariableRefType ref{*_varSpace, f.literal.variable()};
			assert(ref.isPresent());
			assert(_preorder[f.literal.getIndex()] == 0);
			_nextStamp++;
			_preorder[f.literal.getIndex()] = _nextStamp;
			_observed[f.literal.getIndex()] = _nextStamp;
			_root[f.literal.getIndex()] = this_root;
			_stack.push_back(f.literal);
		};

		doCall(this_root);

		while(!_calls.empty()) {
			auto &f = _calls.back();
			if(f.it != _varSpace->watchEnd(f.literal)) {
				if(!f.it->isBinary()) {
					++f.it;
					continue;
				}

				auto clause = ClauseRefType{*_clauseSpace, f.it->getClause()};
				auto target = f.it->getImplied();
				if(!clause.isPresent()) {
					++f.it;
					continue;
				}

				// Check if we found a transitive edge.
				if(_preorder[f.literal.getIndex()] < _observed[target.getIndex()]) {
					_solver->_hooks.reduceProof(clause);
					clause.forceErase();
					stats.transitiveEdges++;
					++f.it;
					continue;
				}

				// If a literal and its inverse are both observed from the same root
				// all common ancestors of the literal are failed.
				if(_preorder[this_root.getIndex()] <= _observed[target.inverse().getIndex()]) {
					// Find the last common ancestor.
					auto failed = f.literal;
					while(_preorder[failed.getIndex()] > _observed[target.inverse().getIndex()])
						failed = _parent[failed.getIndex()];
					
					// Install a clause that forbids this literal.
					// Note that unit clauses are not added to the watch lists so this is safe.
					std::array<LiteralIdType, 1> unit_literals;
					unit_literals[0] = failed.inverse();

					auto unit_clause = _clauseSpace->allocate(_solver->uniqueClauseName(), 1,
							unit_literals.begin(), unit_literals.end());
					unit_clause.markAsEssential();
					_solver->_hooks.emitProof(unit_clause);
					stats.failedLiterals++;

					if(_preorder[target.inverse().getIndex()] != 0 && _postorder[target.inverse().getIndex()] == 0) {
						++f.it;
						continue;
					}
				}
				
				if(_preorder[target.getIndex()] == 0) {
					_parent[target.getIndex()] = f.literal;
					doCall(target);
					continue;
				}

				// Check if we found a backward edge.
				if(_postorder[target.getIndex()] == 0 && _preorder[target.getIndex()] < _preorder[f.literal.getIndex()]) {
					_preorder[f.literal.getIndex()] = _preorder[target.getIndex()];
					f.sccRoot = false;
				}
				_observed[target.getIndex()] = _nextStamp;
				
				++f.it;
			}else{
				// If there were no backward edges, this literal is the head of a SCC.
				if(f.sccRoot) {
					_nextStamp++;
					LiteralIdType equivalent;
					do {
						equivalent = _stack.back();
						_stack.pop_back();
						_preorder[equivalent.getIndex()] = _preorder[f.literal.getIndex()];
						_postorder[equivalent.getIndex()] = _nextStamp;

		/*
						// TODO: make sure this substitution is legal
						auto root1 = equiv_config.getRoot(f.literal);
						auto root2 = equiv_config.getRoot(equivalent);
						if(root1 != root2
								// TODO: allow substitution if equivalent.variable() is not locked
								&& !hooks.varIsProtected(equivalent.variable())
								&& !hooks.varIsProtected(f.literal.variable())) {
							equiv_config.joinRoots(root1, root2);
							stats.equivalentLiterals++;
						}
		*/
					} while(equivalent != f.literal);
				}

				auto callee = f.literal;
				_calls.pop_back();
				
				if(!_calls.empty()) {
					auto &g = _calls.back();
					assert(g.it->isBinary());
					auto target = g.it->getImplied();
					assert(target == callee);

					// Check if we found a backward edge.
					if(_postorder[target.getIndex()] == 0 && _preorder[target.getIndex()] < _preorder[g.literal.getIndex()]) {
						_preorder[g.literal.getIndex()] = _preorder[target.getIndex()];
						g.sccRoot = false;
					}
					_observed[target.getIndex()] = _nextStamp;

					++g.it;
				}
			}
		}

	}

	bool _checkHte(ClauseRefType clause, const std::vector<LiteralIdType> &s_plus,
			const std::vector<LiteralIdType> &s_minus) {
		// A clause C is HT if assigning all of its literals to false leads to a conflict via UP
		// and using only binary clauses, even without the clause C itself.
		// Therefore we look for a clause {u, v} with u, v in C.
		// That is, an implication -u -> v where -u in s_minus and v in s_plus.

		// The implication graph does not correctly capture HTs of length 1.
		// If there is an implications -u -> u then -u is a failed literal.
		// However we cannot necessarily remove the clause {u}.
		if(clause.length() == 1)
			return false;

		// HTs of length 2 are eliminated during the DFS.
		// Similar problem to the unary case would apply if we tried to do it here.
		if(clause.length() == 2)
			return false;

		auto pit = s_plus.begin(); // Iterates over our v.
		auto mit = s_minus.begin(); // Iterates over our -u.
		while(true) {
			if(_preorder[mit->getIndex()] > _preorder[pit->getIndex()]) {
				pit++;
				if(pit == s_plus.end())
					return false;
			}else if(_postorder[mit->getIndex()] < _postorder[pit->getIndex()]) {
				mit++;
				if(mit == s_minus.end())
					return false;
			}else return true;
		}
	}

	void _performHle(ClauseRefType clause, const std::vector<LiteralIdType> &s_plus,
			const std::vector<LiteralIdType> &s_minus, UnhideStats &stats) {
		// This is the number of HLs that are removed from the clause.
		unsigned int num_marked = 0;

		// A literal v in a clause C is HL if there is another literal u in C so that
		// there is a clause {u, -v}. v can then be removed via resolution.
		// Such a clause is an implication v -> u with v, u in s_plus
		// or an implication -u -> -v with -u, -v in s_minus.

		auto fp = _postorder[s_plus.back().getIndex()];
		for(auto it = std::next(s_plus.rbegin()); it != s_plus.rend(); ++it) {
			if(_postorder[it->getIndex()] > fp) {
				if(!_marked[it->getIndex()])
					num_marked++;
				_marked[it->getIndex()] = true;
			}else fp = _postorder[it->getIndex()];
		}

		auto fm = _postorder[s_minus.front().getIndex()];
		for(auto it = std::next(s_minus.begin()); it != s_minus.end(); ++it) {
			if(_postorder[it->getIndex()] < fm) {
				if(!_marked[it->inverse().getIndex()])
					num_marked++;
				_marked[it->inverse().getIndex()] = true;
			}else fm = _postorder[it->getIndex()];
		}

		if(!num_marked)
			return;

		std::vector<LiteralIdType> new_lits;
		for(auto it = clause.beginLits(); it != clause.endLits(); ++it) {
			if(!_marked[it->getIndex()])
				new_lits.push_back(it->id());
			_marked[it->getIndex()] = false;
		}

		auto new_clause = _clauseSpace->allocate(_solver->uniqueClauseName(), new_lits.size(),
				new_lits.begin(), new_lits.end());
		if(clause.isEssential())
			new_clause.markAsEssential();
		_solver->_hooks.emitProof(new_clause);
		
		_solver->_hooks.reduceProof(clause);
		clause.forceErase();
		stats.hleLiterals += num_marked;
		stats.hleClauses++;
	}

private:
	SolverType *_solver;
	VariableSpaceType *_varSpace;
	ClauseSpaceType *_clauseSpace;

	struct Item {
		LiteralIdType literal;
		typename VariableSpaceType::WatchIterator it;
		bool sccRoot;
	};

	std::vector<Item> _calls;

	std::vector<LiteralIdType> _stack;
	std::vector<unsigned int> _observed;
	std::vector<unsigned int> _preorder;
	std::vector<unsigned int> _postorder;
	std::vector<LiteralIdType> _root;
	std::vector<LiteralIdType> _parent;
	std::vector<bool> _marked;

	std::mt19937 _generator;
	unsigned int _nextStamp;
};

} } // namespace satuzk::cdcl

