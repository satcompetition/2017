
#include <type_traits>
#include <utility>

#if 1
#define LIKELY(x) __builtin_expect(x, true)
#define UNLIKELY(x) __builtin_expect(x, false)
#else
#define LIKELY(x) x
#define UNLIKELY(x) x
#endif

#include "normalize.hpp"

namespace satuzk {
//namespace util {

template<typename T>
struct ArrowProxy {
	explicit ArrowProxy(T item)
	: _item(std::move(item)) { }

	std::add_pointer_t<T> operator-> () {
		return &_item;
	}
	const std::add_pointer_t<T> operator-> () const {
		return &_item;
	}

private:
	T _item;
};

} // namespace satuzk::util

namespace satuzk {
	static constexpr bool kDbgSlowAssertions = false;
};

namespace satuzk {
namespace cdcl {

// --------------------------------------------------------
// Default implementation of utility classes
// --------------------------------------------------------

struct DefaultHooks {
	void onClauseCompaction() { }

	template<typename ClauseRef>
	void onLearnClause(ClauseRef) { }

	void onReductionIncrement() { }
};

} } // namespace satuzk::cdcl

#include "sys/Debug.inline.hpp"
#include "sys/Reporter.inline.hpp"
#include "sys/Performance.inline.hpp"
#include "util/BulkAlloc.inline.hpp"
#include "util/BinaryHeap.inline.hpp"
#include "util/Bool3.inline.hpp"
#include "util/SimpleVector.inline.hpp"
#include "util/FiniteIterator.inline.hpp"
#include "util/split-interval.hpp"

#include "vars/all.hpp"
#include "cclauses/all.hpp"
#include "iclauses/all.hpp"
#include "satutils/all.hpp"
#include "simplify/all.hpp"
#include "cdcl/all.hpp"

/*
//#include "simplify/BlockedClauseElim.hpp"
#include "simplify/Equivalent.hpp"
#include "Simplify.hpp"
*/

#include "Lbd.inline.hpp"
#include "ExtModel.inline.hpp"
#include "Config.hpp"
#include "SolverUtils.inline.hpp"
#include "Resolution.inline.hpp"
/*#include "simplify/FactElim.inline.hpp"
#include "simplify/VarElim.inline.hpp"
#include "simplify/VarIntro.inline.hpp"
#include "simplify/BlockedClauseElim.inline.hpp"
#include "simplify/HyperBinary.inline.hpp"*/
#include "simplify/Unhiding.hpp"
#include "simplify/Unhiding.inline.hpp"
#include "simplify/unit-elim.hpp"
#include "simplify/Subsumption.hpp"
#include "simplify/Subsumption.inline.hpp"
#include "simplify/Distillation.inline.hpp"
/*#include "simplify/Equivalent.inline.hpp"
#include "Simplify.inline.hpp"*/
#include "simplify/preprocessor.hpp"
#include "Dimacs.inline.hpp"
#include "Config.inline.hpp"
#include "Lookahead.inline.hpp"

#include "sys/Linux.inline.hpp"

