
#include <assert.h>
#include <experimental/optional>
#include <iostream>
#include <numeric>
#include <queue>
#include <stack>
#include <mpicxx/defs.hpp>
#include <mpicxx/async.hpp>
#include <mpicxx/type_mapping.hpp>

namespace satuzk {
namespace dist_balancer {

using Worker = std::pair<int, int>;

namespace tags {
	static constexpr int anotherAction = 1;
	static constexpr int join = 2;
	static constexpr int integrate = 3;
	static constexpr int checkWork = 4;
	static constexpr int iterateBalance = 5;
	static constexpr int distributeLoad = 6;
	static constexpr int distributeWork = 7;
}

int tag(int raw, int from, int to) {
	assert(!(raw & ~int(0xF)));
	assert(!(from & ~int(0xF)));
	assert(!(to & ~int(0xF)));
	return (raw << 8) | (from << 4) | to;
}

enum class ActionType {
	null,
	join
};

struct ActionData {
	ActionType type;
	std::vector<Worker> nodes;
};

template<typename M>
struct Context {
	explicit Context(mpicxx::dispatcher *dispatcher, mpicxx::comm comm, M item_mapping = M{})
	: _dispatcher{dispatcher}, _comm{comm}, _itemMapping{std::move(item_mapping)} {
		MPI_Comm_rank(comm, &_ownRank);
		MPI_Comm_size(comm, &_numNodes);
	}

	Context(const Context &) = delete;

	Context &operator= (const Context &) = delete;

	mpicxx::dispatcher *dispatcher() {
		return _dispatcher;
	}

	mpicxx::comm comm() {
		return _comm;
	}

	M itemMapping() {
		return _itemMapping;
	}

	int ownRank() {
		return _ownRank;
	}
	int numNodes() {
		return _numNodes;
	}

private:
	mpicxx::dispatcher *_dispatcher;
	mpicxx::comm _comm;
	int _ownRank, _numNodes;
	M _itemMapping;
};

template<typename M>
struct Balancer {
	using Item = typename M::item;
	using Representation = typename M::representation;

	Balancer(Worker self, Context<M> *context)
	: _self{self}, _context{context}, _active{true} { }

	void run() {
		_balanceFiber = boost::fibers::fiber{[=] {
			while(active()) {
				_balance();
				boost::this_fiber::sleep_for(std::chrono::milliseconds{200});
			}
		}};
		_balanceFiber.properties<mpicxx::props>().set_interaction(mpicxx::interaction::batch);
	}

	void shutdown() {
		_balanceFiber.join();
	}

	Worker masterRank() {
		assert(!_nodeRank.empty());
		return _nodeRank.front();
	}

	bool isMaster() {
		return masterRank() == _self;
	}

	bool active() {
		return _active;
	}

	template<typename Iterator>
	void initiate(std::vector<Worker> nodes, Iterator begin, Iterator end) {
		_nodeRank = std::move(nodes);

		for(auto it = begin; it != end; ++it)
			_queue.push(*it);
	}

	void integrate(Worker master) {
		mpicxx::recv_n<mpicxx::trivial_mapping<int>> nodes{_context->dispatcher(),
				_context->comm(), master.first,
				tag(tags::integrate, master.second, _self.second),
				_context->numNodes(), mpicxx::int_mapping};
		nodes.future().get();
		for(auto node : deserialize(nodes.value()))
			_nodeRank.push_back(node);
	}

	void join(std::vector<Worker> nodes) {
		assert(isMaster());
		_actions.push({ ActionType::join, std::move(nodes) });
	}

	std::experimental::optional<Item> steal() {
		while(true) {
			std::unique_lock<boost::fibers::mutex> lock(_mutex);

			if(!_active)
				return std::experimental::nullopt;

			if(_queue.empty()) {
				_cv.wait(lock);
				continue;
			}

			auto item = std::move(_queue.top());
			_queue.pop();
			return item;
		}
	}

private:
	void _balance() {
		if(!isMaster()) {
			while(true) {
				mpicxx::recv<mpicxx::trivial_mapping<int>> another_action{_context->dispatcher(),
						_context->comm(), masterRank().first,
						tag(tags::anotherAction, masterRank().second, _self.second),
						mpicxx::bool_mapping};
				another_action.future().get();
				if(!another_action.value())
					break;

				mpicxx::recv_n<mpicxx::trivial_mapping<int>> nodes(_context->dispatcher(),
						_context->comm(), masterRank().first,
						tag(tags::join, masterRank().second, _self.second),
						_context->numNodes(), mpicxx::int_mapping);
				nodes.future().get();
				for(auto node : deserialize(nodes.value()))
					_nodeRank.push_back(node);
			}
		}else{
			while(!_actions.empty()) {
				// Broadcast the join action to all slaves.
				for(auto rank : _nodeRank) {
					if(rank == masterRank())
						continue;

					mpicxx::send<mpicxx::trivial_mapping<int>> another_action{_context->dispatcher(),
							_context->comm(), rank.first,
							tag(tags::anotherAction, _self.second, rank.second),
							true, mpicxx::bool_mapping};
					mpicxx::send_n<mpicxx::trivial_mapping<int>> nodes{_context->dispatcher(),
							_context->comm(), rank.first,
							tag(tags::join, _self.second, rank.second),
							serialize(_actions.front().nodes), mpicxx::bool_mapping};
					another_action.future().get();
					nodes.future().get();
				}

				for(auto node : _actions.front().nodes)
					_nodeRank.push_back(node);

				// Send an integration message to all new nodes.
				for(auto rank : _actions.front().nodes) {
					mpicxx::send_n<mpicxx::trivial_mapping<int>> integrate{_context->dispatcher(),
							_context->comm(), rank.first,
							tag(tags::integrate, _self.second, rank.second),
							serialize(_nodeRank), mpicxx::int_mapping};
					integrate.future().get();
				}

				_actions.pop();
			}

			for(auto rank : _nodeRank)
				if(rank != masterRank()) {
					mpicxx::send<mpicxx::trivial_mapping<int>> another_action{_context->dispatcher(),
							_context->comm(), rank.first,
							tag(tags::anotherAction, _self.second, rank.second),
							false, mpicxx::bool_mapping};
					another_action.future().get();
				}
		}

		bool empty;
		{
			std::lock_guard<boost::fibers::mutex> lock(_mutex);
			empty = _queue.empty();
		}

		// Enquire if all nodes have already finished their work.
//		std::cout << "Enquire" << std::endl;
		if(!isMaster()) {
			mpicxx::send<mpicxx::trivial_mapping<int>> work_here{_context->dispatcher(),
					_context->comm(), masterRank().first,
					tag(tags::checkWork, _self.second, masterRank().second),
					!empty, mpicxx::bool_mapping};
			work_here.future().get();

			mpicxx::recv<mpicxx::trivial_mapping<int>> iterate{_context->dispatcher(),
					_context->comm(), masterRank().first,
					tag(tags::iterateBalance, masterRank().second, _self.second),
					mpicxx::bool_mapping};
			iterate.future().get();
			if(!iterate.value()) {
				{
					std::lock_guard<boost::fibers::mutex> lock(_mutex);
					_active = false;
				}
				_cv.notify_all();
				return;
			}
		}else{
			auto has_work = std::accumulate(_nodeRank.begin(), _nodeRank.end(),
					false, [&] (bool work_elsewhere, Worker rank) {
				if(rank == masterRank())
					return !empty || work_elsewhere;
				mpicxx::recv<mpicxx::trivial_mapping<int>> work_here{_context->dispatcher(),
						_context->comm(), rank.first,
						tag(tags::checkWork, rank.second, _self.second),
						mpicxx::bool_mapping};
				work_here.future().get();
				return work_here.value() || work_elsewhere;
			});

			for(auto rank : _nodeRank)
				if(rank != masterRank()) {
					mpicxx::send<mpicxx::trivial_mapping<int>> iterate{_context->dispatcher(),
							_context->comm(), rank.first,
							tag(tags::iterateBalance, _self.second, rank.second),
							has_work, mpicxx::bool_mapping};
					iterate.future().get();
				}
			if(!has_work) {
				{
					std::lock_guard<boost::fibers::mutex> lock(_mutex);
					_active = false;
				}
				_cv.notify_all();
				return;
			}
		}

		// Actually perform load balancing.
//		std::cout << "Distribute" << std::endl;
		for(size_t d = 0; (1 << d) <= _nodeRank.size(); d++) {
			// TODO: Do not recompute this.
			auto it = std::find(_nodeRank.begin(), _nodeRank.end(), _self);
			assert(it != _nodeRank.end());

			auto index = size_t(it - _nodeRank.begin());
			auto peer = index ^ (1 << d);
			if(peer >= _nodeRank.size())
				continue;

			size_t local_work;
			{
				std::lock_guard<boost::fibers::mutex> lock(_mutex);
				local_work = _queue.size();
			}

			// Exchange local and remote work information.
			size_t remote_work;
			if(index & (1 << d)) {
				mpicxx::send<mpicxx::trivial_mapping<int>> send_load(_context->dispatcher(),
						_context->comm(), _nodeRank[peer].first,
						tag(tags::distributeLoad, _self.second, _nodeRank[peer].second),
						local_work, mpicxx::int_mapping);
				mpicxx::recv<mpicxx::trivial_mapping<int>> recv_load{_context->dispatcher(),
						_context->comm(), _nodeRank[peer].first,
						tag(tags::distributeLoad, _nodeRank[peer].second, _self.second),
						mpicxx::int_mapping}; // TODO: Use size_t mapping!
				send_load.future().get();
				recv_load.future().get();
				remote_work = recv_load.value();
			}else{
				mpicxx::recv<mpicxx::trivial_mapping<int>> recv_load{_context->dispatcher(),
						_context->comm(), _nodeRank[peer].first,
						tag(tags::distributeLoad, _nodeRank[peer].second, _self.second),
						mpicxx::int_mapping};
				mpicxx::send<mpicxx::trivial_mapping<int>> send_load(_context->dispatcher(),
						_context->comm(), _nodeRank[peer].first,
						tag(tags::distributeLoad, _self.second, _nodeRank[peer].second),
						local_work, mpicxx::int_mapping); // TODO: Use size_t mapping!
				recv_load.future().get();
				send_load.future().get();
				remote_work = recv_load.value();
			}

			// Send or receive work based on this information.
			auto fair_work = (local_work + remote_work) / 2;
			if(fair_work == local_work && fair_work == remote_work)
				continue;
//			std::cout << "Fair work: " << fair_work
//					<< ", local: " << local_work
//					<< ", remote: " << remote_work << std::endl;
			
			if(local_work > fair_work) {
				std::vector<Item> stolen;
				{
					std::lock_guard<boost::fibers::mutex> lock(_mutex);	
					for(size_t i = 0; i < local_work - fair_work && !_queue.empty(); ++i) {
						stolen.push_back(_queue.top());
						_queue.pop();
					}
				}

				mpicxx::send_n<M> items{_context->dispatcher(),
						_context->comm(), _nodeRank[peer].first,
						tag(tags::distributeWork, _self.second, _nodeRank[peer].second),
						stolen, _context->itemMapping()};
				items.future().get();
			}else if(remote_work > fair_work) {
				mpicxx::recv_n<M> items{_context->dispatcher(),
						_context->comm(), _nodeRank[peer].first,
						tag(tags::distributeWork, _nodeRank[peer].second, _self.second),
						remote_work, _context->itemMapping()};
				items.future().get();
				
				{
					std::lock_guard<boost::fibers::mutex> lock(_mutex);
					for(auto item : items.value())
						_queue.push(item);
				}
			}
		}

		_cv.notify_all();
	}

private:
	std::vector<Worker> deserialize(std::vector<int> ser) {
		assert(ser.size() % 2 == 0);

		std::vector<Worker> rep;
		for(size_t i = 0; i < ser.size(); i += 2)
			rep.push_back(Worker{ser[i], ser[i + 1]});
		return rep;
	}

	std::vector<int> serialize(std::vector<Worker> rep) {
		std::vector<int> ser;
		for(auto item : rep) {
			ser.push_back(item.first);
			ser.push_back(item.second);
		}
		return ser;
	}

private:
	Worker _self;
	Context<M> *_context;

	boost::fibers::fiber _balanceFiber;

	// ------------------------------------------------------------------------

	// Protects the _queue and _active fields.
	boost::fibers::mutex _mutex;

	// Used to wake up fibers that wait until new items arrive from other nodes.
	boost::fibers::condition_variable _cv;
	
	bool _active;

	std::stack<Item> _queue;

	// ------------------------------------------------------------------------

	std::vector<Worker> _nodeRank;

	std::queue<ActionData> _actions;
};

template<typename M>
struct StaticBalancer {
	using Item = typename M::item;
	using Representation = typename M::representation;

	StaticBalancer(Worker self, Context<M> *context)
	: _self{self}, _context{context} { }

	void run() {
		// The static balancer does not start fibers.
	}

	void shutdown() {
		// The static balancer does not start fibers.
	}

	template<typename Iterator>
	void initiate(std::vector<Worker> nodes, Iterator begin, Iterator end) {
		assert(!nodes.empty());
		if(_self == nodes.front()) {
			std::deque<Item> all{begin, end};

			std::random_device dev;
			std::mt19937 random{dev()};
			std::shuffle(all.begin(), all.end(), random);

			const size_t n = all.size();
			for(size_t k = 0; k < nodes.size(); ++k) {
				std::tuple<int, int, bool> split = splitInterval(n, nodes.size(), k);
				
				std::vector<Item> chunk;
				for(size_t i = 0; i < std::get<1>(split); i++) {
					assert(!all.empty());
					chunk.push_back(std::move(all.front()));
					all.pop_front();
				}

				if(k) {
					mpicxx::send<mpicxx::trivial_mapping<int>> load{_context->dispatcher(),
							_context->comm(), nodes[k].first,
							tag(tags::distributeLoad, _self.second, nodes[k].second),
							chunk.size(), mpicxx::int_mapping}; // TODO: Use size_t mapping!
					mpicxx::send_n<M> items{_context->dispatcher(),
							_context->comm(), nodes[k].first,
							tag(tags::distributeWork, _self.second, nodes[k].second),
							chunk, _context->itemMapping()};
					load.future().get();
					items.future().get();
				}else{
					for(auto item : chunk)
						_queue.push_back(item);
				}
			}
		}else{
			assert(begin == end);
			
			mpicxx::recv<mpicxx::trivial_mapping<int>> load{_context->dispatcher(),
					_context->comm(), nodes[0].first,
					tag(tags::distributeLoad, nodes[0].second, _self.second),
					mpicxx::int_mapping};
			load.future().get();

			mpicxx::recv_n<M> items{_context->dispatcher(),
					_context->comm(), nodes[0].first,
					tag(tags::distributeWork, nodes[0].second, _self.second),
					load.value(), _context->itemMapping()};
			items.future().get();
			
			for(auto item : items.value())
				_queue.push_back(item);
		}
	}

	std::experimental::optional<Item> steal() {
		if(_queue.empty())
			return std::experimental::nullopt;
		
		auto item = std::move(_queue.front());
		_queue.pop_front();
		return item;
	}

private:
	Worker _self;
	Context<M> *_context;

	std::deque<Item> _queue;
};

} } // namespace satuzk::dist_balancer

