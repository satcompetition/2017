
namespace satuzk {

template<typename Defs>
struct EffortAlias {
	typedef uint64_t type;
};

template<typename Defs>
using EffortType = typename EffortAlias<Defs>::type;

template<typename Defs>
class BveTechniqueStruct {
public:
	typedef VariableType<Defs> Variable;

	void schedule(Solver<Defs> &solver);
	bool isActive();
	void run(Solver<Defs> &solver);

private:
	std::queue<Variable> varQueue;
	BveStats runStats;
};

template<typename Defs>
class BceTechniqueStruct {
public:
	typedef ClauseType<Defs> Clause;

	void schedule(Solver<Defs> &solver);
	bool isActive();
	void run(Solver<Defs> &solver);
	
	void collectClauses(Solver<Defs> &solver);

private:
	std::queue<Clause> clauseQueue;
	BceStats runStats;
};

template<typename Defs>
class SubsumeTechniqueStruct {
public:
	typedef LiteralType<Defs> Literal;
	typedef ClauseType<Defs> Clause;

	void schedule(Solver<Defs> &solver);
	bool isActive();
	void run(Solver<Defs> &solver, EffortType<Defs> effort, bool inproc);
	
	void collectClauses(Solver<Defs> &solver);

private:
	std::queue<Clause> clauseQueue;
	SubsumeStats runStats;
};

template<typename Defs>
class UnhideTechniqueStruct {
public:
	typedef VariableType<Defs> Variable;
	typedef LiteralType<Defs> Literal;
	typedef ClauseType<Defs> Clause;

	void schedule(Solver<Defs> &solver);
	bool isActive();
	void run(Solver<Defs> &solver);
	
	void collectClauses(Solver<Defs> &solver);

private:
	enum Phase {
		kPhaseNone, kPhaseDiscover, kPhaseReduce
	};

	std::vector<unsigned int> observed;
	std::vector<unsigned int> preorder;
	std::vector<unsigned int> postorder;
	std::vector<Literal> root;
	std::vector<Literal> parent;
	std::vector<Literal> stack;
	std::vector<Clause> redundant;
	EquivConfigStruct<Defs> equivConfig;
	unsigned int nextTimestamp;

	std::deque<Variable> varQueue;
	std::queue<Clause> clauseQueue;
	Phase currentPhase;
	UnhideStats runStats;
};

template<typename Defs>
class SimplifyConfigStruct {
public:
	typedef EffortType<Defs> Effort;
	typedef VariableType<Defs> Variable;
	typedef LiteralType<Defs> Literal;

	SimplifyConfigStruct();

	void preprocess(Solver<Defs> &solver);

	void simplifyPass(Solver<Defs> &solver);
	
	void collectClauses(Solver<Defs> &solver);

	bool enableBve, enableBce, enableSubsume, enableUnhide;

private:
	BveTechniqueStruct<Defs> bveTechnique;
	BceTechniqueStruct<Defs> bceTechnique;
	SubsumeTechniqueStruct<Defs> subsumeTechnique;
	UnhideTechniqueStruct<Defs> unhideTechnique;
};

} // namespace satuzk

