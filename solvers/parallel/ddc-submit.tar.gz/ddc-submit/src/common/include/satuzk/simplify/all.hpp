
namespace satuzk {
namespace simplify {

// --------------------------------------------------------
// Basic types extracted from policy tags
// --------------------------------------------------------

template<typename T>
struct UseClauseNameAllocator { };

template<typename T>
struct UseVariableSpace { };

template<typename T>
struct UseClauseSpace { };

template<typename T>
struct UseOcclists { };

template<typename T>
struct UseEliminationStack { };

template<typename T>
struct UseProofHandler { };

template<typename T>
struct UseSimplificationTracker { };

template<typename... PT>
using ClauseNameAllocator = ExtractType<UseClauseNameAllocator, PT...>;

template<typename... PT>
using VariableSpace = ExtractType<UseVariableSpace, PT...>;

template<typename... PT>
using ClauseSpace = ExtractType<UseClauseSpace, PT...>;

template<typename... PT>
using Occlists = ExtractType<UseOcclists, PT...>;

template<typename... PT>
using EliminationStack = ExtractType<UseEliminationStack, PT...>;

template<typename... PT>
using ProofHandler = ExtractType<UseProofHandler, PT...>;

template<typename... PT>
using SimplificationTracker = ExtractType<UseSimplificationTracker, PT...>;

// --------------------------------------------------------
// Forward declarations and normalized API types
// --------------------------------------------------------

template<typename... PT>
using VariableId = typename VariableSpace<PT...>::VariableIdType;

template<typename... PT>
using LiteralId = typename VariableSpace<PT...>::LiteralIdType;

template<typename... PT>
using VariableRef = typename VariableSpace<PT...>::VariableRef;

template<typename... PT>
using LiteralRef = typename VariableSpace<PT...>::LiteralRef;

template<typename... PT>
using ClauseId = typename ClauseSpace<PT...>::ClauseIdType;

template<typename... PT>
using ClauseRef = typename ClauseSpace<PT...>::ClauseRef;

} } // namespace satuzk::simplify

#include "var-elim.hpp"

