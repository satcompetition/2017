
namespace satuzk {
namespace satutils {

template<typename T>
struct sized_stack {
	using size_type = uint32_t;

	sized_stack()
	: _array{nullptr}, _top{0}, _capacity{0} { }

	sized_stack(const sized_stack &) = delete;

	sized_stack &operator= (const sized_stack &) = delete;

	~sized_stack() {
		if(_array)
			operator delete(_array);
	}

	void reserve(size_type desired) {
		if(_capacity >= desired)
			return;

		auto new_array = reinterpret_cast<T *>(operator new(sizeof(T) * desired));
		if(_array) {
			memcpy(new_array, _array, sizeof(T) * _top);
			operator delete(_array);
		}
		_array = new_array;
		_capacity = desired;
	}

	size_type size() {
		return _top;
	}

	T &back() {
		return _array[_top - 1];
	}

	T &operator[] (size_type index) {
		return _array[index];
	}

	void push_back(T element) {
		_array[_top++] = std::move(element);
	}

	void pop_back() {
		--_top;
	}

private:
	T *_array;
	size_type _top;
	size_type _capacity;
};

struct DefaultPropagationFilter {
	template<typename ClauseRef>
	bool doesParticipate(ClauseRef clause) {
		return true;
	}
};

template<typename... PT>
class TrailStruct {
public:
	typedef AtomSpace<PT...> AtomSpaceType;
	// TODO: rename Literal{IdType,Ref} to Atom{IdType,Ref} in VariableSpace
	typedef typename AtomSpaceType::LiteralIdType AtomIdType;
	typedef typename AtomSpaceType::LiteralRef AtomRefType;

	typedef Antecedent<PT...> AntecedentType;
	typedef Conflict<PT...> ConflictType;
	typedef DecisionLevel<PT...> DecisionLevelType;
	typedef TrailIndex<PT...> TrailIndexType;

	typedef Hooks<PT...> HooksType;

	struct DecisionInfo {
		DecisionInfo(TrailIndexType offset)
		: firstIndex{offset} { }

		// index of the first assignment at this decision level
		TrailIndexType firstIndex;
	};

	TrailStruct(AtomSpaceType &atom_space, HooksType hooks)
	: _atomSpace{&atom_space}, _hooks{std::move(hooks)}, _propagatePointer{0},
			propagationCounter{0}, conflictCounter{0} { }

	void resizeAtoms(size_t count) {
		_trailStack.reserve(count);
	}

	bool isReset() {
		return _decisionStack.empty();
	}

	DecisionLevelType currentLevel() {
		return _decisionStack.size() - 1;
	}
	
	TrailIndexType trailLength() {
		return _trailStack.size();
	}

	// Decision level after all initial levels have been processed.
	DecisionLevelType initialPoint() {
		return _hooks.numInitialLevels() - 1;
	}

	// TODO: Rename this function to initialize().
	void start() {
		assert(_decisionStack.empty());
		assert(!_conflict);

		for(DecisionLevelType i = 0; i < _hooks.numInitialLevels(); i++) {
			assert(_propagatePointer == _trailStack.size());
			_decisionStack.push_back(DecisionInfo{static_cast<TrailIndexType>(_trailStack.size())});
			auto conflict = _hooks.initializeLevel(i);
			if(conflict) {
				raiseConflict(std::move(conflict));
				break;
			}

			propagate();
			if(_conflict)
				break;
		}
	}

	void reinitialize() {
		assert(!_decisionStack.empty());
		assert(!_conflict);

		for(DecisionLevelType i = _decisionStack.size(); i < _hooks.numInitialLevels(); i++) {
			assert(_propagatePointer == _trailStack.size());
			_decisionStack.push_back(DecisionInfo{static_cast<TrailIndexType>(_trailStack.size())});
			auto conflict = _hooks.initializeLevel(i);
			if(conflict) {
				raiseConflict(std::move(conflict));
				break;
			}

			propagate();
			if(_conflict)
				break;
		}
	}

	void enqueue(AtomRefType atom, AntecedentType antecedent) {
		assert(!_decisionStack.empty());

		_hooks.onAssign(atom, antecedent, currentLevel());
		_trailStack.push_back(atom.id());
	}
	// TODO: remove this transition function
	void enqueue(AtomIdType atom, AntecedentType antecedent) {
		enqueue(AtomRefType(*_atomSpace, atom), antecedent);
	}

	template<typename PropagationFilter = DefaultPropagationFilter>
	void propagate(PropagationFilter f = PropagationFilter{}) {
		if(UNLIKELY(_conflict))
			return;

		auto pointer = _propagatePointer;
		while(pointer < _trailStack.size()) {
			AtomIdType literal = _trailStack[pointer];
			
			ConflictType conflict = _hooks.propagate(literal, f);
			pointer++;
			if(conflict) {
				raiseConflict(std::move(conflict));
				break;
			}
		}

		propagationCounter += pointer - _propagatePointer;
		_propagatePointer = pointer;
	}

	bool isPropagated() {
		return _propagatePointer == _trailStack.size();
	}

	void repropagate() {
		propagate();
		if(!_conflict)
			reinitialize();
	}

	void pushInitialLevel() {
		auto next_level = _decisionStack.size();
		assert(next_level < _hooks.numInitialLevels());

		assert(_propagatePointer == _trailStack.size());
		_decisionStack.push_back(DecisionInfo{static_cast<TrailIndexType>(_trailStack.size())});
		auto conflict = _hooks.initializeLevel(next_level);
		if(conflict)
			raiseConflict(std::move(conflict));
	}

	void beginLevel() {
		assert(_decisionStack.size() >= _hooks.numInitialLevels());
		assert(_propagatePointer == _trailStack.size());
		_decisionStack.push_back(DecisionInfo{static_cast<TrailIndexType>(_trailStack.size())});
	}

	void backtrackLevel() {
		assert(!_decisionStack.empty());
		assert(currentLevel() >= _hooks.numInitialLevels());
		_unassignLevel();
	}

	// Backtracks until the specified level is reached.
	void backjump(DecisionLevelType level) {
		assert(level <= currentLevel());
		while(level != currentLevel())
			_unassignLevel();
	}

private:
	void _unassignLevel() {
		assert(_decisionStack.size() > 1);

		DecisionInfo decision = _decisionStack.back();
		_decisionStack.pop_back();

		while(_trailStack.size() > decision.firstIndex) {
			_hooks.onUnassign(AtomRefType(*_atomSpace, _trailStack.back()));
			_trailStack.pop_back();
		}

		_propagatePointer = decision.firstIndex;
	}

public:
	void raiseConflict(ConflictType conflict) {
		assert(!_conflict);

		conflictCounter++;
		_conflict = std::move(conflict);
	}

	void clearConflict() {
		assert(_decisionStack.size() > 0);
		assert(_conflict);

		// TODO: ensure the conflict can be cleared at the current level
		_conflict = ConflictType{};
	}
	
	const ConflictType &conflict() {
		return _conflict;
	}

	// resets the complete trail including initial assignments and conflicts
	void reset() {
		while(!_decisionStack.empty()) {
			DecisionInfo decision = _decisionStack.back();
			_decisionStack.pop_back();
			
			while(_trailStack.size() > decision.firstIndex) {
				_hooks.onUnassign(AtomRefType(*_atomSpace, _trailStack.back()));
				_trailStack.pop_back();
			}
		}

		_propagatePointer = 0;
		_conflict = ConflictType();
	}

	AtomIdType atomAtIndex(TrailIndexType order) {
		return _trailStack[order];
	}
	AtomRefType atomAt(TrailIndexType order) {
		return AtomRefType(*_atomSpace, _trailStack[order]);
	}

	TrailIndexType indexOfLevel(DecisionLevelType declevel) {
		assert(declevel < _decisionStack.size());
		return _decisionStack[declevel].firstIndex;
	}
	TrailIndexType indexOfNextLevel(DecisionLevelType declevel) {
		assert(declevel + 1 <= _decisionStack.size());
		if(declevel + 1 == _decisionStack.size())
			return _trailStack.size();
		return indexOfLevel(declevel + 1);
	}

private:
	std::vector<DecisionInfo> _decisionStack;
	sized_stack<AtomIdType> _trailStack;

	AtomSpaceType *_atomSpace;
	ConflictType _conflict;
	HooksType _hooks;

	TrailIndexType _propagatePointer;

public:
	// some statistics. TODO: provide accessor functions
	uint64_t propagationCounter;
	uint64_t conflictCounter;
};

} } // namespace satuzk::satutils

