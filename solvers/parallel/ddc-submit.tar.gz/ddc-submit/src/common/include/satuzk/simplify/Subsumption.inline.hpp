
namespace satuzk {
namespace simplify {

/*// checks whether the resolvent of both clauses subsumes the
// second clause. the resolved variable must be in both clauses, with opposite polarity.
template<typename Defs, typename Stats>
bool resolventSubsumes(Solver<Defs> &solver,
		ClauseType<Defs> clause,
		ClauseType<Defs> subsumed,
		VariableType<Defs> resolved,
		Stats &stats) {
	if(solver.clauseLength(clause) > solver.clauseLength(subsumed))
		return false;
	
	auto clause_sig = solver.clauseGetSignature(clause);
	auto subsumed_sig = solver.clauseGetSignature(subsumed);
	if((subsumed_sig & clause_sig) != clause_sig) {
		stats.resShortcuts++;
		return false;
	}

	stats.resChecks++;
	for(auto i = solver.clauseBegin(clause); i != solver.clauseEnd(clause); ++i) {
		VariableType<Defs> var = (*i).variable();
		if(var == resolved)	
			continue;
		auto it = std::find(solver.clauseBegin(subsumed), solver.clauseEnd(subsumed), *i);
		if(it == solver.clauseEnd(subsumed))
			return false;
	}
	return true;
}

// tests if the first clause self-subsumes the second
// and returns the variable that can be resolved
template<typename Defs, typename Stats>
bool clauseSelfsubs(Solver<Defs> &solver,
		ClauseType<Defs> clause,
		ClauseType<Defs> subsumed,
		VariableType<Defs> &resolved,
		Stats &stats) {
	resolved = VariableType<Defs>::illegalVar();
	
	if(solver.clauseLength(clause) > solver.clauseLength(subsumed))
		return false;
	
	auto clause_sig = solver.clauseGetSignature(clause);
	auto subsumed_sig = solver.clauseGetSignature(subsumed);
	if((subsumed_sig & clause_sig) != clause_sig) {
		stats.resShortcuts++;
		return false;
	}

	stats.resExpensiveChecks++;
	for(auto i = solver.clauseBegin(clause); i != solver.clauseEnd(clause); ++i) {
		// test if the variable is in the subsumed clause
		VariableType<Defs> var = (*i).variable();
		int subsumed_pol = findPolarity(solver.clauseBegin(subsumed),
				solver.clauseEnd(subsumed), var);
		if(subsumed_pol == 0)
			return false;
		
		// test if both polarities are equal
		int clause_pol = (*i).polarity();
		if(clause_pol == subsumed_pol)
			continue;
		
		// test if there are two literals of opposite polarities
		if(resolved != VariableType<Defs>::illegalVar())
			return false;
		resolved = var;
	}
	return true;
}

// determine the literal with the shortest occurrence list
template<typename Defs>
LiteralType<Defs> selfsubShortestOcclist(Solver<Defs> &solver,
		ClauseType<Defs> clause) {
	unsigned int best_length = 0;
	LiteralType<Defs> best_literal = LiteralType<Defs>::illegalLit();
	for(auto i = solver.clauseBegin(clause); i != solver.clauseEnd(clause); ++i) {
		LiteralType<Defs> inverse = (*i).inverse();
		unsigned int length = solver.occurSize(*i) + solver.occurSize(inverse);
		if(best_literal == LiteralType<Defs>::illegalLit() || length < best_length) {
			best_length = length;
			best_literal = *i;
		}
	}
	return best_literal;
}

// checks whether the given clause subsumes any other one
template<typename Defs, typename Stats>
void selfsubBackward(Solver<Defs> &solver,
		ClauseType<Defs> clause,
		LiteralType<Defs> sub_literal,
		Stats &stats) {
	assert(solver.clauseIsPresent(clause));
	LiteralType<Defs> sub_inverse = sub_literal.inverse();

	std::vector<ClauseType<Defs>> queue;	
	for(auto j = solver.occurBegin(sub_inverse); j != solver.occurEnd(sub_inverse); ++j)
		queue.push_back(*j);

	std::vector<LiteralType<Defs>> res_lits;

	// check the clauses containing the inverse:
	// we only have to check if the resolvent subsumes the second clause
	VariableType<Defs> sub_var = sub_literal.variable();
	for(auto j = queue.begin(); j != queue.end(); ++j) {
		stats.ops++;

		if(!solver.clauseIsPresent(*j))
			continue;
		if(solver.clauseIsAntecedent(*j))
			continue;
		if(!resolventSubsumes(solver, clause, *j, sub_var, stats))
			continue;
		
		// build the resolvent and delete the subsumed clause
		res_lits.clear();
		resolventBuild(solver, *j, clause, sub_var, res_lits);
		
		ClauseType<Defs> res_clause = solver.allocClause
				(res_lits.size(), res_lits.begin(), res_lits.end());
		if(solver.clauseIsEssential(*j))
			solver.clauseSetEssential(res_clause);
		
		if(solver.clauseIsFrozen(*j)) {
			solver.quickFreezeClause(res_clause);
		}else{
			solver.installClause(res_clause);
		}

		if(solver.clauseIsEssential(*j))
			solver.clauseUnsetEssential(*j);
		if(solver.clauseIsInstalled(*j))
			solver.uninstallClause(*j);
		solver.deleteClause(*j);
		
		if(res_lits.size() == 1)
			stats.resFacts++;
		stats.resClauses++;
	}
	
	queue.clear();
	for(auto j = solver.occurBegin(sub_literal); j != solver.occurEnd(sub_literal); ++j)
		queue.push_back(*j);
	
	// check the clauses containing the same literal as our clause:
	// we have to do a full subsumption/self-subsumption check
	for(auto j = queue.begin(); j != queue.end(); ++j) {
		stats.ops++;

		if(*j == clause)
			continue;
		if(!solver.clauseIsPresent(*j))
			continue;
		if(solver.clauseIsAntecedent(*j))
			continue;
		
		VariableType<Defs> res_var = VariableType<Defs>::illegalVar();
		if(!clauseSelfsubs(solver, clause, *j, res_var, stats))
			continue;
		
		if(res_var == VariableType<Defs>::illegalVar()) {
			// regular subsumption: delete the subsumed clause
			if(solver.clauseIsEssential(*j) && !solver.clauseIsEssential(clause)) {
				if(solver.clauseIsFrozen(clause))
					solver.unfreezeClause(clause);
				solver.clauseSetEssential(clause);
				assert(solver.clauseIsInstalled(clause));
			}
			
			if(solver.clauseIsEssential(*j))
				solver.clauseUnsetEssential(*j);
			if(solver.clauseIsInstalled(*j))
				solver.uninstallClause(*j);
			solver.deleteClause(*j);
			
			stats.subClauses++;
		}else{
			// self-subsumption: build the resolvent and delete the subsumed clause
			res_lits.clear();
			resolventBuild(solver, *j, clause, res_var, res_lits);
			
			ClauseType<Defs> res_clause = solver.allocClause
					(res_lits.size(), res_lits.begin(), res_lits.end());
			if(solver.clauseIsEssential(*j))
				solver.clauseSetEssential(res_clause);
			
			if(solver.clauseIsFrozen(*j)) {
				solver.quickFreezeClause(res_clause);
			}else{
				solver.installClause(res_clause);
			}
			
			if(solver.clauseIsEssential(*j))
				solver.clauseUnsetEssential(*j);
			if(solver.clauseIsInstalled(*j))
				solver.uninstallClause(*j);
			solver.deleteClause(*j);
			
			if(res_lits.size() == 1)
				stats.resFacts++;
			stats.resClauses++;
		}
	}
}*/

template<typename... PT>
struct Subsumption {
	typedef VariableSpace<PT...> VariableSpaceType;
	typedef ClauseSpace<PT...> ClauseSpaceType;
	typedef Occlists<PT...> OcclistsType;
	typedef ClauseNameAllocator<PT...> ClauseNameAllocatorType;
	typedef ProofHandler<PT...> ProofHandlerType;
	typedef SimplificationTracker<PT...> SimplificationTrackerType;

	using LiteralIdType = typename VariableSpaceType::LiteralIdType;
	typedef VariableRef<PT...> VariableRefType;
	typedef LiteralRef<PT...> LiteralRefType;
	typedef ClauseRef<PT...> ClauseRefType;

	// Prefetching seems to be good on some instances but bad on others.
	static constexpr bool enablePrefetch = false;

	// Considering binary clauses has a large performance penalty.
	// Binary clauses can be processed by unhiding instead.
	static constexpr bool considerBinariesInSubsumption = false;
	static constexpr bool considerBinariesInResolution = false;

	Subsumption(ClauseSpaceType *clause_space, OcclistsType *occlists,
			ClauseNameAllocatorType *name_allocator, ProofHandlerType proof_handler,
			SimplificationTrackerType *tracker)
	: _clauseSpace{clause_space}, _occlists{occlists},
			_nameAllocator{name_allocator}, _proofHandler{std::move(proof_handler)},
			_tracker{tracker} { }

	template<typename Iterator>
	static bool doesSubsume(Iterator begin, Iterator end,
			size_t length, uint64_t signature, ClauseRefType other) {
		if(other.length() < length)
			return false;
		if(LIKELY((other.signature() & signature) != signature))
			return false;
		for(auto it = begin; it != end; ++it)
			if(LIKELY(std::find(other.beginLits(), other.endLits(), *it) == other.endLits()))
				return false;
		return true;
	}

private:
	void _backwardSubsume(ClauseRefType clause, SubsumeStats &stats) {
		assert(clause.isPresent());
		if(clause.length() <= 1)
			return;
		if(!considerBinariesInSubsumption && clause.length() <= 2)
			return;
		
		_occlists->maybeClean(4);

		// We only need to walk though the shortest occlist.
		auto less = [&] (LiteralRefType a1, LiteralRefType a2) -> bool {
			auto size1 = _occlists->size(a1.id());
			auto size2 = _occlists->size(a2.id());
			if(size1 != size2)
				return size1 < size2;
			// Prefer one of the occlists for cache locality.
			return a1.id() < a2.id();
		};
		auto sit = std::min_element(clause.beginLits(), clause.endLits(), less);
		assert(sit != clause.endLits());

		// On some instances with large occlists prefetching improves performance a lot.
		auto end = _occlists->end(sit->id());
		auto pit = _occlists->begin(sit->id());
		if(enablePrefetch)
			for(int i = 0; i < 16 && pit != end; i++) {
				pit->prefetchHeadNonTemporal();
				++pit;
			}

		for(auto cit = _occlists->begin(sit->id()); cit != end; ++cit) {
			if(enablePrefetch && pit != end) {
				pit->prefetchHeadNonTemporal();
				++pit;
			}

			if(UNLIKELY(*cit == clause))
				continue;
			if(UNLIKELY(!cit->isPresent()))
				continue;

			if(LIKELY(!doesSubsume(clause.beginLits(), clause.endLits(),
					clause.length(), clause.signature(), *cit)))
				continue;

			// Unfreeze to preserve unit propagations.
			// Also ensures that markAsEssential() below works correctly.
			if(!cit->isFrozen() && clause.isFrozen())
				clause.unfreeze();
			// We have to mark the clause as essential if it subsumes an essential clause.
			if(cit->isEssential() && !clause.isEssential())
				clause.markAsEssential();

			for(auto it = cit->beginLits(); it != cit->endLits(); ++it)
				_tracker->touch(it->variable());

			_proofHandler.reduce(*cit);
			cit->forceErase();
			stats.subClauses++;
		}
	}

	void _backwardResolve(ClauseRefType clause, SubsumeStats &stats) {
		if(!clause.isPresent())
			return;
		if(clause.length() <= 1)
			return;
		if(!considerBinariesInResolution && clause.length() <= 2)
			return;

		for(auto ait = clause.beginLits(); ait != clause.endLits(); ++ait)
			_inverted.push_back(*ait);

		for(size_t i = 0; i < _inverted.size(); i++) {
			// Flip exactly one literal of the clause.
			auto literal = _inverted[i];
			_inverted[i] = literal.inverse();

			_occlists->maybeClean(4);

			// Do the same trick as in _backwardSubsume, just for the vector we just constructed.
			auto less = [&] (LiteralRefType a1, LiteralRefType a2) -> bool {
				auto size1 = _occlists->size(a1.id());
				auto size2 = _occlists->size(a2.id());
				if(size1 != size2)
					return size1 < size2;
				// Prefer one of the occlists for cache locality.
				return a1.id() < a2.id();
			};
			auto sit = std::min_element(_inverted.begin(), _inverted.end(), less);
			assert(sit != _inverted.end());
			
			// On some instances with large occlists prefetching improves performance a lot.
			auto end = _occlists->end(sit->id());
			auto pit = _occlists->begin(sit->id());
			if(enablePrefetch)
				for(int i = 0; i < 16 && pit != end; i++) {
					pit->prefetchHeadNonTemporal();
					++pit;
				}

			for(auto cit = _occlists->begin(sit->id()); cit != end; ++cit) {
				if(enablePrefetch && pit != end) {
					pit->prefetchHeadNonTemporal();
					++pit;
				}

				if(UNLIKELY(*cit == clause))
					continue;
				if(UNLIKELY(!cit->isPresent()))
					continue;

				if(UNLIKELY(!doesSubsume(_inverted.begin(), _inverted.end(),
						clause.length(), clause.signature(), *cit)))
					continue;

				for(auto ait = cit->beginLits(); ait != cit->endLits(); ++ait) {
					if(*ait == literal.inverse())
						continue;
					_literals.push_back(ait->id());
				}

				auto new_clause = _clauseSpace->allocate(_nameAllocator->allocate(),
						_literals.size(), _literals.begin(), _literals.end());
				if(cit->isEssential())
					new_clause.markAsEssential();
				_proofHandler.emit(new_clause);

				for(auto it = cit->beginLits(); it != cit->endLits(); ++it)
					_tracker->touch(it->variable());
				_tracker->markStrengthened(new_clause);

				_proofHandler.reduce(*cit);
				cit->forceErase();
				stats.resClauses++;

				_literals.clear();
			}

			// Flip it back.
			_inverted[i] = literal;
		}
		_inverted.clear();
	}

public:
	void backwardSubsumeSingle(ClauseRefType clause, SubsumeStats &stats) {
		auto start = sys::ThreadClock::now();
		_backwardSubsume(clause, stats);
		stats.time += sys::ThreadClock::now() - start;
	}

	// Applies forward subsumption to all clauses.
	template<typename Iterator>
	void backwardSubsumeAll(Iterator begin, Iterator end, SubsumeStats &stats) {
		auto start = sys::ThreadClock::now();
		for(auto cit = begin; cit != end; ++cit) {
			if(!cit->isPresent())
				continue;

			_backwardSubsume(*cit, stats);
		}
		stats.time += sys::ThreadClock::now() - start;
	}
	
	void backwardResolveSingle(ClauseRefType clause, SubsumeStats &stats) {
		auto start = sys::ThreadClock::now();
		_backwardResolve(clause, stats);
		stats.time += sys::ThreadClock::now() - start;
	}

	// Applies backward subsumption to all clauses.
	template<typename Iterator>
	void backwardResolveAll(Iterator begin, Iterator end, SubsumeStats &stats) {
		auto start = sys::ThreadClock::now();
		for(auto cit = begin; cit != end; ++cit) {
			if(!cit->isPresent())
				continue;

			_backwardResolve(*cit, stats);
		}
		stats.time += sys::ThreadClock::now() - start;
	}

	// ------------------------------------------------------------------------
	// Forward subsumption.
	// ------------------------------------------------------------------------
	
	template<typename Iterator>
	void forwardSubsumeAll(Iterator begin, Iterator end, SubsumeStats &stats) {
		auto start = sys::ThreadClock::now();
		for(auto cit = begin; cit != end; ++cit) {
			if(!cit->isPresent())
				continue;

			_forwardSubsume(*cit, stats);
		}
		stats.time += sys::ThreadClock::now() - start;
	}

private:
	void _forwardSubsume(ClauseRefType clause, SubsumeStats &stats) {
		assert(clause.isPresent());

		for(auto ait = clause.beginLits(); ait != clause.endLits(); ++ait)
			for(auto cit = _occlists->begin(ait->id()); cit != _occlists->end(ait->id()); ++cit) {
				if(*cit == clause)
					return;
				if(!cit->isPresent())
					return;

				if(!doesSubsume(cit->beginLits(), cit->endLits(),
							cit->length(), cit->signature(), clause))
					return;

				// Unfreeze to preserve unit propagations.
				// Also ensures that markAsEssential() below works correctly.
				if(!clause.isFrozen() && cit->isFrozen())
					cit->unfreeze();
				// We have to mark the clause as essential if it subsumes an essential clause.
				if(clause.isEssential() && !cit->isEssential())
					cit->markAsEssential();

				for(auto it = clause.beginLits(); it != clause.endLits(); ++it)
					_tracker->touch(it->variable());

				_proofHandler.reduce(clause);
				clause.forceErase();
				stats.subClauses++;
				return;
			}
	}

private:
	ClauseSpaceType *_clauseSpace;
	OcclistsType *_occlists;
	ClauseNameAllocatorType *_nameAllocator;
	ProofHandlerType _proofHandler;
	SimplificationTrackerType *_tracker;

	std::vector<LiteralRefType> _inverted;
	std::vector<LiteralIdType> _literals;
};

} } // namespace satuzk::simplify

