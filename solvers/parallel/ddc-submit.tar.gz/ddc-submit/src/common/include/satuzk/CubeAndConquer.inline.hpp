
#include <boost/fiber/barrier.hpp>

namespace satuzk {
namespace ddc {

static const bool setAffinity = false;

static const bool minimalOutput = true;
static const bool logRoute = false;
static const bool logSteps = false;
static const bool logProgress = false;
static const bool logDebug = false;

// TODO: move this to a .cpp file
thread_local bool commandsAllowed = false;
thread_local int workerPeer;
thread_local mpicxx::dispatcher localDispatcher;
thread_local OffloaderStruct *localOffloader;

std::mutex globalStdoutMutex;

int encodeTag(std::pair<int, int> pair) {
	assert(pair.first <= 0xF);
	assert(pair.second <= 0xF);
	return (pair.first << 4) | pair.second;
}

std::pair<int, int> decodeTag(int tag) {
	return { tag >> 4, tag & 0xF };
}

/*FIXME:
template<typename P>
HookStruct<DefsStruct<P>>::HookStruct(WorkerStruct<P> &worker)
: worker(worker) { }

template<typename P>
void HookStruct<DefsStruct<P>>::onLearnedClause(ClauseType<DefsStruct<P>> clause) {
	// do nothing
}

template<typename P>
void HookStruct<DefsStruct<P>>::onCollectClauses() {
	worker.collectClauses();
}*/

// --------------------------------------------------------
// OffloaderStruct
// --------------------------------------------------------

OffloaderStruct::OffloaderStruct()
: _active{true} { }

void OffloaderStruct::enqueue(std::function<void()> tasklet) {
	{
		std::lock_guard<boost::fibers::mutex> lock{_mutex};
		_tasklets.push(std::move(tasklet));
	}
	_cv.notify_one();
}

void OffloaderStruct::run() {
	_fiber = boost::fibers::fiber([this] () {
		commandsAllowed = true;

		std::unique_lock<boost::fibers::mutex> lock{_mutex};
		while(_active) {
			if(_tasklets.empty()) {
				_cv.wait(lock);
				continue;
			}

			auto tasklet = std::move(_tasklets.front());
			_tasklets.pop();

			int rank;
			MPI_Comm_rank(MPI_COMM_WORLD, &rank);
			
			lock.unlock();
			tasklet();
			lock.lock();
		}
	});
}

void OffloaderStruct::shutdown() {
	{
		std::lock_guard<boost::fibers::mutex> lock{_mutex};
		_active = false;
	}
	_cv.notify_all();

	_fiber.join();
}

// --------------------------------------------------------
// SharedDataStruct
// --------------------------------------------------------

template<typename... PT>
SharedDataStruct<PT...>::SharedDataStruct(SuiteType *suite)
: globalSolveState(SolveState::kStateUnknown), terminateFlag(false),
		_suite{suite} { }

template<typename... PT>
auto SharedDataStruct<PT...>::gatherOwnVertices() -> std::vector<CubeNode *> {
	std::lock_guard<std::mutex> lock{treeMutex};

	std::vector<CubeNode *> result;
	for(auto it = cubeTree.begin(); it != cubeTree.end(); ++it) {
		if(it->first.first != _suite->worldRank)
			continue;
		result.push_back(it->second.get());
	}
	return result;
}

template<typename... PT>
auto SharedDataStruct<PT...>::atNode(std::unique_lock<std::mutex> &guard, CubeLink link) -> CubeNode * {
	assert(guard && guard.mutex() == &treeMutex);
	return cubeTree.at(link).get();
}

template<typename... PT>
auto SharedDataStruct<PT...>::findNode(std::unique_lock<std::mutex> &guard, CubeLink link) -> CubeNode * {
	assert(guard && guard.mutex() == &treeMutex);
	auto iterator = cubeTree.find(link);
	return iterator == cubeTree.end() ? nullptr : iterator->second.get();
}

template<typename... PT>
void SharedDataStruct<PT...>::insertNode(std::unique_lock<std::mutex> &guard, CubeLink link, std::unique_ptr<CubeNode> node) {
	assert(guard && guard.mutex() == &treeMutex);
	auto result = cubeTree.emplace(link, std::move(node));
	assert(result.second);
}

// --------------------------------------------------------
// SharedDataStruct::CubeNode
// --------------------------------------------------------

template<typename... PT>
SharedDataStruct<PT...>::CubeNode::CubeNode(SuiteType &suite, CubeLink this_link, CubeLink parent_link,
		std::vector<LiteralIdType> cube_literals, std::vector<CubeClause> cube_clauses)
: suite(suite), thisLink(this_link), parentLink(parent_link),
		cubeLiterals{std::move(cube_literals)}, cubeClauses{std::move(cube_clauses)},
		_expanded(false), _conquerClosed(false), state(kWorkNone), _interrupted(false),
		_conflictProgress(0), numCollapsedChildren(0) { }

template<typename... PT>
void SharedDataStruct<PT...>::CubeNode::routeDown(std::unique_lock<std::mutex> &guard, std::vector<WorkerId> workers) {
	assert(guard && guard.mutex() == &mutex);
	assert(thisLink.first == suite.worldRank);

	assert(!workers.empty());
	waitingWorkers.insert(waitingWorkers.end(), workers.begin(), workers.end());
	_performRoute(guard);
}

template<typename... PT>
void SharedDataStruct<PT...>::CubeNode::routeUp(std::unique_lock<std::mutex> &guard, CubeLink child_link,
		std::vector<WorkerId> workers) {
	assert(guard && guard.mutex() == &mutex);
	assert(thisLink.first == suite.worldRank);

	auto child_it = std::find_if(children.begin(), children.end(), [&] (const auto &child) -> bool {
		return child.link == child_link;
	});
	assert(child_it != children.end());

	if(!child_it->childCollapsed) {
		assert(state == kWorkNone);
		assert(numCollapsedChildren < children.size());
		child_it->childCollapsed = true;
		numCollapsedChildren++;
	}

	assert(child_it->childNumWorkers >= workers.size());
	child_it->childNumWorkers -= workers.size();

	assert(!workers.empty());
	waitingWorkers.insert(waitingWorkers.end(), workers.begin(), workers.end());
	_performRoute(guard);
}

template<typename... PT>
void SharedDataStruct<PT...>::CubeNode::_performRoute(std::unique_lock<std::mutex> &guard) {
	assert(guard && guard.mutex() == &mutex);
	assert(thisLink.first == suite.worldRank);

	assert(!waitingWorkers.empty());

	if(logRoute) {
		std::lock_guard<std::mutex> stdout_lock{globalStdoutMutex};
		std::cout << "c Routing";
		for(auto wp = waitingWorkers.begin(); wp != waitingWorkers.end(); ++wp)
			std::cout << " [" << wp->rank << ", " << wp->index << "]";
		std::cout << " at (" << thisLink.first << ", " << thisLink.second << ")" << std::endl;
	}

	// Shutdown the workers if we are in the termination phase.
	if(suite.sharedData.terminateFlag.load()) {
		for(auto wp = waitingWorkers.begin(); wp != waitingWorkers.end(); ++wp) {
			assert(commandsAllowed);
			msg::Command command;
			command.opcode = Commands::kCmdShutdownWorker;
			command.peer = 0;
			int command_tag = encodeTag({ 0, MsgTags::kTagCommand });
			int argument_tag = encodeTag({ 0, MsgTags::kTagCmdArgument });
			mpicxx::single_send(&localDispatcher, command, suite.commandType,
					wp->rank, command_tag, MPI_COMM_WORLD);
			mpicxx::single_send(&localDispatcher, *wp, suite.workerIdType,
					wp->rank, argument_tag, MPI_COMM_WORLD);
		}
		waitingWorkers.clear();
		return;
	}

	// Route the workers to the parent.
	if(state == kWorkNone && _isClosed()) {
		if(parentLink.first == kNoRank && parentLink.second == kIllegalId) {
			// We arrived at the root and it is exhausted.
			std::lock_guard<boost::fibers::mutex> global_lock{suite.sharedData.globalMutex};
			if(suite.sharedData.globalSolveState == SolveState::kStateUnknown) {
				suite.sharedData.globalSolveState = SolveState::kStateUnsatisfiable;

				for(int wp = 0; wp < suite.worldSize; wp++) {
					assert(commandsAllowed);
					msg::Command command;
					command.opcode = Commands::kCmdTerminateSuite;
					command.peer = 0;
					int command_tag = encodeTag({ 0, kTagCommand });
					mpicxx::single_send(&localDispatcher, command, suite.commandType,
							wp, command_tag, MPI_COMM_WORLD);
				}
			}else{
				assert(suite.sharedData.globalSolveState == SolveState::kStateUnsatisfiable);
			}
			return;
		}

		auto workers = std::move(waitingWorkers);
		waitingWorkers.clear();

		// Send a routing command to the parent node.
		assert(commandsAllowed);
		msg::Command command;
		command.opcode = Commands::kCmdLeaveChild;
		command.peer = 0;
		int command_tag = encodeTag({ 0, kTagCommand });
		int argument_tag = encodeTag({ 0, kTagCmdArgument });
		mpicxx::single_send(&localDispatcher, command, suite.commandType,
				parentLink.first, command_tag, MPI_COMM_WORLD);
		mpicxx::single_send(&localDispatcher, LinkMsgStruct(parentLink), suite.linkMsgType,
				parentLink.first, argument_tag, MPI_COMM_WORLD);
		mpicxx::single_send(&localDispatcher, LinkMsgStruct(thisLink), suite.linkMsgType,
				parentLink.first, argument_tag, MPI_COMM_WORLD);
		mpicxx::vector_send(&localDispatcher, workers, suite.workerIdType,
				parentLink.first, argument_tag, MPI_COMM_WORLD);
		return;
	}

	// Distribute the workers to the children.
	if(state == kWorkNone && _isOpen()) {
		int unfinished = children.size() - numCollapsedChildren;
		int tree_num_workers = waitingWorkers.size();
		for(auto it = children.begin(); it != children.end(); ++it) {
			if(it->childCollapsed)
				continue;

			tree_num_workers += it->childNumWorkers;
		}

		int k = 0;
		for(auto it = children.begin(); it != children.end(); ++it) {
			if(it->childCollapsed)
				continue;

			std::tuple<int, int, bool> split = splitInterval(tree_num_workers, unfinished, k);
			assert(std::get<1>(split) >= it->childNumWorkers);

			std::vector<WorkerId> workers_slice;
			for(int i = 0; i < std::get<1>(split) - it->childNumWorkers; i++) {
				assert(!waitingWorkers.empty());
				workers_slice.push_back(waitingWorkers.back());
				waitingWorkers.pop_back();
			}

			it->childNumWorkers += workers_slice.size();

			// Send a routing command to the child node.
			if(workers_slice.size()) {
				assert(commandsAllowed);
				msg::Command command;
				command.opcode = Commands::kCmdEnterNode;
				command.peer = 0;
				int command_tag = encodeTag({ 0, kTagCommand });
				int argument_tag = encodeTag({ 0, kTagCmdArgument });
				mpicxx::single_send(&localDispatcher, command, suite.commandType,
						it->link.first, command_tag, MPI_COMM_WORLD);
				mpicxx::single_send(&localDispatcher, LinkMsgStruct(it->link), suite.linkMsgType,
						it->link.first, argument_tag, MPI_COMM_WORLD);
				mpicxx::vector_send(&localDispatcher, workers_slice, suite.workerIdType,
						it->link.first, argument_tag, MPI_COMM_WORLD);
			}

			k++;
		}
		assert(k == unfinished);
		assert(waitingWorkers.empty());
		return;
	}

	auto tracePath = [&] () -> std::vector<LinkMsgStruct> {
		std::vector<LinkMsgStruct> path;

		CubeNode *vertex = this;
		while(true) {
			path.push_back(LinkMsgStruct(vertex->thisLink));
			
			if(vertex->parentLink.first == kNoRank
					&& vertex->parentLink.second == kIllegalId)
				break;

			std::unique_lock<std::mutex> guard(suite.sharedData.treeMutex);
			vertex = suite.sharedData.atNode(guard, vertex->parentLink);
			guard.unlock();
		}

		return path;
	};

	// Never interrupt divide-steps.
	if(state == kWorkSplit)
		return;

	// Wait for interrupted conquer-steps to complete.
	if(state == kWorkSolve && _interrupted)
		return;

	// Decide if we want to interrupt the current conquer-step.
	if(state == kWorkSolve && !_wantRace()) {
		if(logProgress) {
			std::lock_guard<std::mutex> stdout_lock{globalStdoutMutex};
			std::cout << "c Requesting interrupt of (" << thisLink.first << ", " << thisLink.second << ")" << std::endl;
		}
		_interrupted = true;

		for(auto worker : activeTeam) {
			assert(commandsAllowed);
			msg::Command command;
			command.opcode = Commands::kCmdRequestInterrupt;
			command.peer = 0;
			int command_tag = encodeTag({ 0, MsgTags::kTagCommand });
			int argument_tag = encodeTag({ 0, MsgTags::kTagCmdArgument });
			mpicxx::single_send(&localDispatcher, command, suite.commandType,
					worker.rank, command_tag, MPI_COMM_WORLD);
			mpicxx::single_send(&localDispatcher, worker, suite.workerIdType,
					worker.rank, argument_tag, MPI_COMM_WORLD);
		}
		return;
	}

	// Decide if we want to issue a conquer-step or commit more workers
	// to the currently active conquer-step.
	if((state == kWorkNone || state == kWorkSolve) && !_isClosed() && _wantRace()) {
		assert(!_isOpen());
		assert(!_interrupted);

		auto workers = std::move(waitingWorkers);
		waitingWorkers.clear();

		if(logRoute) {
			std::lock_guard<std::mutex> stdout_lock{globalStdoutMutex};
			std::cout << "c Issuing conquer-step at (" << thisLink.first << ", " << thisLink.second << ")" << std::endl;
		}
		state = kWorkSolve;
		activeTeam.insert(activeTeam.end(), workers.begin(), workers.end());

		for(auto wp = workers.begin(); wp != workers.end(); ++wp) {
			assert(commandsAllowed);
			msg::Command command;
			command.opcode = Commands::kCmdSolve;
			command.peer = 0;
			int command_tag = encodeTag({ 0, MsgTags::kTagCommand });
			int argument_tag = encodeTag({ 0, MsgTags::kTagCmdArgument });
			mpicxx::single_send(&localDispatcher, command, suite.commandType,
					wp->rank, command_tag, MPI_COMM_WORLD);
			mpicxx::single_send(&localDispatcher, *wp, suite.workerIdType,
					wp->rank, argument_tag, MPI_COMM_WORLD);
			mpicxx::vector_send(&localDispatcher, tracePath(), suite.linkMsgType,
					wp->rank, argument_tag, MPI_COMM_WORLD);
		}
		return;
	}

	// Decide if we want to issue a divide-step.
	if(state == kWorkNone && !_isClosed()) {
		assert(!_isOpen());

		assert(activeTeam.empty());
		assert(waitingWorkers.size() > 1);
		activeTeam = std::move(waitingWorkers);
		waitingWorkers.clear();

		std::random_device device;
		std::mt19937 mt(device());
		std::shuffle(activeTeam.begin(), activeTeam.end(), mt);
		auto captain = activeTeam.front();

		if(logRoute) {
			std::lock_guard<std::mutex> stdout_lock{globalStdoutMutex};
			std::cout << "c Issuing divide-step at (" << thisLink.first << ", " << thisLink.second << ")"
					" with captain [" << captain.rank << ", " << captain.index << "]" << std::endl;
		}
		state = kWorkSplit;

		for(auto wp = activeTeam.begin(); wp != activeTeam.end(); ++wp) {
			assert(commandsAllowed);
			msg::Command command;
			command.opcode = Commands::kCmdSplit;
			command.peer = 0;
			int command_tag = encodeTag({ 0, MsgTags::kTagCommand });
			int argument_tag = encodeTag({ 0, MsgTags::kTagCmdArgument });
			mpicxx::single_send(&localDispatcher, command, suite.commandType,
					wp->rank, command_tag, MPI_COMM_WORLD);
			mpicxx::single_send(&localDispatcher, *wp, suite.workerIdType,
					wp->rank, argument_tag, MPI_COMM_WORLD);
			mpicxx::vector_send(&localDispatcher, activeTeam, suite.workerIdType,
					wp->rank, argument_tag, MPI_COMM_WORLD);
			mpicxx::vector_send(&localDispatcher, tracePath(), suite.linkMsgType,
					wp->rank, argument_tag, MPI_COMM_WORLD);
		}
		return;
	}
}

template<typename... PT>
void SharedDataStruct<PT...>::CubeNode::completeSplit(std::unique_lock<std::mutex> &guard,
		std::vector<CubeLink> child_links) {
	assert(guard && guard.mutex() == &mutex);

	if(logProgress) {
		std::lock_guard<std::mutex> stdout_lock{globalStdoutMutex};
		std::cout << "c Divide-step of (" << thisLink.first << ", " << thisLink.second << ")"
			" resulted in " << child_links.size() << " children" << std::endl;
	}

	assert(state == kWorkSplit);
	state = kWorkNone;
	_expanded = true;
	
	assert(!activeTeam.empty());
	waitingWorkers.insert(waitingWorkers.end(), activeTeam.begin(), activeTeam.end());
	activeTeam.clear();

	for(auto it = child_links.begin(); it != child_links.end(); ++it)
		children.push_back({ *it, 0, false });

	_performRoute(guard);
}

template<typename... PT>
void SharedDataStruct<PT...>::CubeNode::terminateSplit(std::unique_lock<std::mutex> &guard) {
	assert(guard && guard.mutex() == &mutex);

	if(logProgress) {
		std::lock_guard<std::mutex> stdout_lock{globalStdoutMutex};
		std::cout << "c Divide-step of (" << thisLink.first << ", " << thisLink.second << ")"
			" resulted in termination" << std::endl;
	}

	assert(state == kWorkSplit);
	state = kWorkNone;

	suite.sharedData.terminateFlag.store(true);
	
	assert(!activeTeam.empty());
	waitingWorkers.insert(waitingWorkers.end(), activeTeam.begin(), activeTeam.end());
	activeTeam.clear();

	_performRoute(guard);
}

template<typename... PT>
void SharedDataStruct<PT...>::CubeNode::onProgress(std::unique_lock<std::mutex> &guard, uint64_t num_conflicts) {
	assert(guard && guard.mutex() == &mutex);
	assert(thisLink.first == suite.worldRank);

	assert(state == kWorkSolve);
	_conflictProgress += num_conflicts;

	{
		std::lock_guard<std::mutex> stdout_lock{globalStdoutMutex};
//		std::cout << "c Vertex (" << thisLink.first << ", " << thisLink.second << ")"
//				" is at " << _conflictProgress << " conflicts." << std::endl;
	}

	if(_interrupted)
		return;

	if(!_wantRace()) {
		if(logProgress) {
			std::lock_guard<std::mutex> stdout_lock{globalStdoutMutex};
			std::cout << "c Requesting interrupt of (" << thisLink.first << ", " << thisLink.second << ")" << std::endl;
		}
		_interrupted = true;

		for(auto worker : activeTeam) {
			assert(commandsAllowed);
			msg::Command command;
			command.opcode = Commands::kCmdRequestInterrupt;
			command.peer = 0;
			int command_tag = encodeTag({ 0, MsgTags::kTagCommand });
			int argument_tag = encodeTag({ 0, MsgTags::kTagCmdArgument });
			mpicxx::single_send(&localDispatcher, command, suite.commandType,
					worker.rank, command_tag, MPI_COMM_WORLD);
			mpicxx::single_send(&localDispatcher, worker, suite.workerIdType,
					worker.rank, argument_tag, MPI_COMM_WORLD);
		}
	}
}

template<typename... PT>
void SharedDataStruct<PT...>::CubeNode::interruptSolve(std::unique_lock<std::mutex> &guard, WorkerId worker) {
	assert(guard && guard.mutex() == &mutex);

	if(logProgress) {
		std::lock_guard<std::mutex> stdout_lock{globalStdoutMutex};
		std::cout << "c Acknowledging interrupt from [" << worker.rank
			<< ", " << worker.index << "] at (" << thisLink.first << ", " << thisLink.second << ")" << std::endl;
	}

	assert(state == kWorkSolve && _interrupted);

	auto it = std::find(activeTeam.begin(), activeTeam.end(), worker);
	assert(it != activeTeam.end());
	activeTeam.erase(it);
	waitingWorkers.push_back(worker);

	if(activeTeam.empty()) {
		state = kWorkNone;
		_interrupted = false;

		_performRoute(guard);
	}
}

template<typename... PT>
void SharedDataStruct<PT...>::CubeNode::completeSolve(std::unique_lock<std::mutex> &guard, WorkerId worker) {
	assert(guard && guard.mutex() == &mutex);
	
	if(logProgress) {
		std::lock_guard<std::mutex> stdout_lock{globalStdoutMutex};
		std::cout << "c Conquer-step of (" << thisLink.first << ", " << thisLink.second << ") completed" << std::endl;
	}

	assert(state == kWorkSolve);
	assert(!(parentLink.first == kNoRank && parentLink.second == kIllegalId));
	_conquerClosed = true;

	auto it = std::find(activeTeam.begin(), activeTeam.end(), worker);
	assert(it != activeTeam.end());
	activeTeam.erase(it);
	waitingWorkers.push_back(worker);

	if(activeTeam.empty()) {
		state = kWorkNone;
	
		_performRoute(guard);
	}else if(!_interrupted) {
		if(logProgress) {
			std::lock_guard<std::mutex> stdout_lock{globalStdoutMutex};
			std::cout << "c Requesting interrupt of (" << thisLink.first << ", " << thisLink.second << ")" << std::endl;
		}
		_interrupted = true;

		for(auto worker : activeTeam) {
			assert(commandsAllowed);
			msg::Command command;
			command.opcode = Commands::kCmdRequestInterrupt;
			command.peer = 0;
			int command_tag = encodeTag({ 0, MsgTags::kTagCommand });
			int argument_tag = encodeTag({ 0, MsgTags::kTagCmdArgument });
			mpicxx::single_send(&localDispatcher, command, suite.commandType,
					worker.rank, command_tag, MPI_COMM_WORLD);
			mpicxx::single_send(&localDispatcher, worker, suite.workerIdType,
					worker.rank, argument_tag, MPI_COMM_WORLD);
		}
	}
}

template<typename... PT>
void SharedDataStruct<PT...>::CubeNode::terminateSolve(std::unique_lock<std::mutex> &guard, WorkerId worker) {
	assert(guard && guard.mutex() == &mutex);
	
	if(logProgress) {
		std::lock_guard<std::mutex> stdout_lock{globalStdoutMutex};
		std::cout << "c Conquer-step of (" << thisLink.first << ", " << thisLink.second << ") resulted"
				" in termination!" << std::endl;
	}

	assert(state == kWorkSolve);

	suite.sharedData.terminateFlag.store(true);

	auto it = std::find(activeTeam.begin(), activeTeam.end(), worker);
	assert(it != activeTeam.end());
	activeTeam.erase(it);
	waitingWorkers.push_back(worker);

	_performRoute(guard);
}

template<typename... PT>
void SharedDataStruct<PT...>::CubeNode::shutdownWaiters(std::unique_lock<std::mutex> &guard) {
	assert(guard && guard.mutex() == &mutex);

	if(state == kWorkSolve && !_interrupted) {
		if(logProgress) {
			std::lock_guard<std::mutex> stdout_lock{globalStdoutMutex};
			std::cout << "c Requesting interrupt of (" << thisLink.first << ", " << thisLink.second
					<< ") because of termination." << std::endl;
		}
		_interrupted = true;

		for(auto worker : activeTeam) {
			assert(commandsAllowed);
			msg::Command command;
			command.opcode = Commands::kCmdRequestInterrupt;
			command.peer = 0;
			int command_tag = encodeTag({ 0, MsgTags::kTagCommand });
			int argument_tag = encodeTag({ 0, MsgTags::kTagCmdArgument });
			mpicxx::single_send(&localDispatcher, command, suite.commandType,
					worker.rank, command_tag, MPI_COMM_WORLD);
			mpicxx::single_send(&localDispatcher, worker, suite.workerIdType,
					worker.rank, argument_tag, MPI_COMM_WORLD);
		}
	}

	for(auto wp = waitingWorkers.begin(); wp != waitingWorkers.end(); ++wp) {
		assert(commandsAllowed);
		msg::Command command;
		command.opcode = Commands::kCmdShutdownWorker;
		command.peer = 0;
		int command_tag = encodeTag({ 0, MsgTags::kTagCommand });
		int argument_tag = encodeTag({ 0, MsgTags::kTagCmdArgument });
		mpicxx::single_send(&localDispatcher, command, suite.commandType,
				wp->rank, command_tag, MPI_COMM_WORLD);
		mpicxx::single_send(&localDispatcher, *wp, suite.workerIdType,
				wp->rank, argument_tag, MPI_COMM_WORLD);
	}
	waitingWorkers.clear();
}

template<typename... PT>
void SharedDataStruct<PT...>::CubeNode::setupCube(SolverType &solver) {
	for(auto it = cubeLiterals.begin(); it != cubeLiterals.end(); ++it) {
		solver.lockVariable(it->variable());
		solver.assumptionEnable(*it);
	}

	for(auto cp = cubeClauses.begin(); cp != cubeClauses.end(); ++cp) {
//			std::cout << "c @" << suite.worldRank << " clause:";
//			for(auto it = cp->begin(); it != cp->end(); ++it)
//				std::cout << " " << it->toNumber();
//			std::cout << std::endl;

		auto clause = solver.clauseSpace.allocate(solver.uniqueClauseName(),
				cp->literals.size(), cp->literals.begin(), cp->literals.end());
		clause.updateLbd(cp->lbd);
		clause.markAsImportant();
	}
}

template<typename... PT>
void SharedDataStruct<PT...>::CubeNode::resetCube(SolverType &solver) {
	for(auto it = cubeLiterals.begin(); it != cubeLiterals.end(); ++it) {
		solver.assumptionDisable(*it);
		solver.unlockVariable(it->variable());
	}
}

// --------------------------------------------------------
// WorkerStruct::WorkTask
// --------------------------------------------------------

template<typename... PT>
WorkerStruct<PT...>::WorkTask::WorkTask(WorkState state)
: state(state), node(nullptr) { }

// --------------------------------------------------------
// WorkerStruct
// --------------------------------------------------------

//FIXME: solver configuration id
template<typename... PT>
WorkerStruct<PT...>::WorkerStruct(SuiteType &suite, int index)
: suite(suite), thisId(suite.worldRank, index), sharedData(suite.sharedData),
		solver(WorkerHooks<PT...>(this), suite.worldRank * suite.configuredWorkersPerNode + index + 1),
		inprocessor{&solver},
		satisfiedReduction{&solver, &solver.clauseSpace, &solver.trail,
			&solver.assignment},
		workState(WorkState::kWorkNone), intraReady(false),
		splitTime(0), solveTime(0),
		numDivide(0), numVertices(0),
		numDirect(0), numInterruptions(0),
		numImports(0), numExports(0),
		_balanceContext(&localDispatcher, suite.balanceComm) {
	exchangeRecvBuffer.resize(maxExchangeBuffer);

	/*FIXME p_simplifyConfig.enableBve = false;
	p_simplifyConfig.enableBce = false;
	p_simplifyConfig.enableUnhide = false;*/
}

template<typename... PT>
void WorkerStruct<PT...>::navigate(CubeLink link) {
	std::vector<CubeNode *> path;
	do {
		std::unique_lock<std::mutex> tree_guard(sharedData.treeMutex);
		auto node = sharedData.atNode(tree_guard, link);
		tree_guard.unlock();

		path.push_back(node);
		link = node->parentLink;
	} while(link != CubeLink{kNoRank, kIllegalId});

	// Find the common prefix of the new path and the current stack.
	auto current = vertexStack.begin();
	auto desired = path.rbegin();
	while(current != vertexStack.end() && desired != path.rend()
			&& *current == *desired) {
		current++;
		desired++;
	}

	// Uninstall the remaining vertices of the current stack.
	for(auto it = vertexStack.rbegin(); it.base() != current; it++)
		(*it)->resetCube(solver);
	vertexStack.erase(current, vertexStack.end());

	// Install the remaining vertex of the new path.
	for(auto it = desired; it != path.rend(); it++)
		(*it)->setupCube(solver);
	vertexStack.insert(vertexStack.end(), desired, path.rend());

	// We also reset the LBD after changing assumptions.
	for(auto clause : solver.clauseSpace.reducible()) {
		// We spare clauses from the first reduction to give them the chance
		// to decrease their local LBDs before they are deleted.
		// TODO: This magic constant is not backed by experimentation.
		if(clause.localLbd() <= 5)
			clause.spare();
		clause.resetLocalLbd();
	}
}

template<typename... PT>
void WorkerStruct<PT...>::doSplit(CubeLink link) {
	assert(workState == WorkState::kWorkNone);
	navigate(link);

	WorkerId captain = currentTeam.front();
	if(captain == thisId) {
		splitAsCaptain();
	}else{
		splitAsWorker();
	}
}

template<typename... PT>
void WorkerStruct<PT...>::splitAsCaptain() {
	if(logSteps) {
		std::lock_guard<std::mutex> stdout_lock{globalStdoutMutex};
		std::cout << "c [" << thisId.rank << ", " << thisId.index << "] Split "
				<< "(" << currentVertex()->thisLink.first << ", " << currentVertex()->thisLink.second
				<< ") as captain" << std::endl;
	}

	solver.varSpace.cleanWatches(&solver.clauseSpace);
	solver.trail.start();

	// Check if all workers were able to setup the trail.
	bool trail_okay = !solver.trail.conflict();
	for(auto tp = currentTeam.begin() + 1; tp != currentTeam.end(); ++tp) {
		int local_trail;
		mpicxx::single_recv(&localDispatcher, local_trail, MPIx_primitive<int>,
				tp->rank, encodeTag({ tp->index, kTagSplitLocalTrail }),
				MPI_COMM_WORLD, MPI_STATUS_IGNORE);

		trail_okay = trail_okay && local_trail;
	}

	for(auto tp = currentTeam.begin() + 1; tp != currentTeam.end(); ++tp)
		mpicxx::single_send(&localDispatcher, static_cast<int>(trail_okay), MPIx_primitive<int>,
				tp->rank, encodeTag({ tp->index, kTagSplitGlobalTrail }), MPI_COMM_WORLD);

	if(!trail_okay) {
		solver.trail.reset();

		if(logProgress) {
			std::lock_guard<std::mutex> stdout_lock{globalStdoutMutex};
			std::cout << "c [" << thisId.rank << ", " << thisId.index << "]"
				" Trail is already conflicting!" << std::endl;
		}

		msg::Command command;
		command.opcode = Commands::kCmdCompleteSplit;
		command.peer = workerPeer;
		int command_tag = encodeTag({ 0, kTagCommand });
		int argument_tag = encodeTag({ workerPeer, kTagCmdArgument });
		mpicxx::single_send(&localDispatcher, command, suite.commandType,
				currentVertex()->thisLink.first, command_tag, MPI_COMM_WORLD);
		mpicxx::single_send(&localDispatcher, LinkMsgStruct(currentVertex()->thisLink), suite.linkMsgType,
				currentVertex()->thisLink.first, argument_tag, MPI_COMM_WORLD);
		mpicxx::vector_send(&localDispatcher, std::vector<LinkMsgStruct>(), suite.linkMsgType,
				currentVertex()->thisLink.first, argument_tag, MPI_COMM_WORLD);

		numDivide++;

		return;
	}
	
	// Select variables to initialize the load balancer.
	std::vector<VariableRefType> preselected = cdcl::Lookahead<cdcl::UseHooks<WorkerHooks<PT...>>>::preselect(solver.varSpace,
			solver.occlists, solver.assignment);
	std::shuffle(preselected.begin(), preselected.end(), solver.p_rndEngine);

	// If we could not preselect variables then the formula is SAT.
	std::vector<uint32_t> model_data;
	if(preselected.empty()) {
		std::vector<LiteralIdType> premodel;
		for(auto var : solver.varSpace) {
			if(solver.assignment.isTrue(var.positive()))
				premodel.push_back(var.positive().id());
			if(solver.assignment.isTrue(var.negative()))
				premodel.push_back(var.negative().id());
		}

		typename SolverType::EliminationStackType::ModelExtender me{&solver.eliminationStack};
		auto model = me.extend(premodel);
		for(auto literal : model)
			model_data.push_back(literal.getIndex());
	}

	// Setup the load balancer.
	dist_balancer::Balancer<mpicxx::trivial_mapping<uint32_t>> balancer({ thisId.rank, thisId.index },
			&_balanceContext);

	std::vector<dist_balancer::Worker> balance_workers;
	for(auto tp = currentTeam.begin(); tp != currentTeam.end(); ++tp)
		balance_workers.push_back({tp->rank, tp->index});

	std::vector<uint32_t> balance_vars;
	for(auto var : preselected)
		balance_vars.push_back(var.getIndex());

	balancer.initiate(balance_workers, balance_vars.begin(), balance_vars.end());
	balancer.run();

	// Do the actual evaluation.
	bool global_unsat = false, vertex_failed = false;
	cdcl::LookaheadResult local_result = cdcl::LookaheadResult::kResOkay;
	std::vector<std::pair<LiteralRefType, cdcl::LookaheadValue>> values;
	std::vector<ClauseRefType> failed;
	evaluateSplit(&balancer, local_result, values, failed);

	balancer.shutdown();

	solver.trail.reset();
	
	if(local_result == cdcl::LookaheadResult::kResFailedAssumption) {
		vertex_failed = true;
	}else if(local_result == cdcl::LookaheadResult::kResFormulaUnsat) {
		global_unsat = true;
	}else{
		assert(local_result == cdcl::LookaheadResult::kResOkay);
	}
	
	// Turn the local failed literals into CubeClause objects.
	std::vector<CubeClause> cube_clauses;
	for(auto cit = failed.begin(); cit != failed.end(); ++cit) {
		std::vector<LiteralIdType> lits;
		for(auto it = cit->beginLits(); it != cit->endLits(); ++it)
			lits.push_back(it->id());
		cube_clauses.push_back(CubeClause{cit->name(), std::move(lits), cit->globalLbd()});
	}

	// receive local best literals from the team and determine the global best literal
	std::vector<std::pair<LiteralRefType, cdcl::LookaheadValue>> global_values(values.begin(), values.end());
	
	for(auto tp = currentTeam.begin(); tp != currentTeam.end(); ++tp) {
		if(*tp == thisId)
			continue;

		// merge the remote result
		int remote_result;
		int result_tag = encodeTag({ tp->index, MsgTags::kTagSplitResult });
		mpicxx::single_recv(&localDispatcher, remote_result, MPIx_primitive<int>,
				tp->rank, result_tag, MPI_COMM_WORLD, MPI_STATUS_IGNORE);
		if(remote_result == cdcl::LookaheadResult::kResFailedAssumption) {
			vertex_failed = true;
		}else if(remote_result == cdcl::LookaheadResult::kResFormulaUnsat) {
			global_unsat = true;
		}else{
			assert(remote_result == cdcl::LookaheadResult::kResOkay);
		}
	}

	// TODO: fuse with the above loop after the command thread has been fixed
	for(auto tp = currentTeam.begin(); tp != currentTeam.end(); ++tp) {
		if(*tp == thisId)
			continue;
		
		// receive the lookahead heuristic values
		std::vector<SplitValueMsgStruct> remote_values;
		int value_tag = encodeTag({ tp->index, MsgTags::kTagSplitValues });
		remote_values.resize(mpicxx::size_probe(&localDispatcher, suite.splitValueMsgType,
				tp->rank, value_tag, MPI_COMM_WORLD));
		mpicxx::vector_recv(&localDispatcher, remote_values, suite.splitValueMsgType,
				tp->rank, value_tag, MPI_COMM_WORLD, MPI_STATUS_IGNORE);

		for(auto result_msg : remote_values) {
			auto literal = LiteralRefType(solver.varSpace, LiteralIdType::fromIndex(result_msg.literal));
			global_values.push_back(std::make_pair(literal, result_msg.value));
		}

		// receive the failed literals
		std::vector<uint32_t> failed_data;
		int failed_tag = encodeTag({ tp->index, MsgTags::kTagSplitFailed });
		failed_data.resize(mpicxx::size_probe(&localDispatcher, MPIx_primitive<uint32_t>,
				tp->rank, failed_tag, MPI_COMM_WORLD));
		mpicxx::vector_recv(&localDispatcher, failed_data, MPIx_primitive<uint32_t>,
				tp->rank, failed_tag, MPI_COMM_WORLD, MPI_STATUS_IGNORE);

		for(auto it = failed_data.begin(); it != failed_data.end(); /* no increment */) {
			uint64_t name_low = *it++;
			assert(it != failed_data.end());
			uint64_t name_high = *it++;
			assert(it != failed_data.end());

			auto lbd = *it++;
			assert(it != failed_data.end());

			std::vector<LiteralIdType> lits;
			while(*it != 0) {
				lits.push_back(LiteralIdType::fromIndex(*it++ - 1));
				assert(it != failed_data.end());
			}
			it++;
		
			auto name = ClauseNameType{(name_high << 32) | name_low};
			cube_clauses.push_back(CubeClause{name, std::move(lits), lbd});
		}
	}

	if(global_unsat) {
		int command_tag = encodeTag({ 0, MsgTags::kTagCommand });
		int argument_tag = encodeTag({ workerPeer, kTagCmdArgument });

		msg::Command res_command;
		res_command.opcode = Commands::kCmdUnsatisfiable;
		res_command.peer = workerPeer;
		mpicxx::single_send(&localDispatcher, res_command, suite.commandType,
				0, command_tag, MPI_COMM_WORLD);

		msg::Command term_command;
		term_command.opcode = Commands::kCmdTerminateSplit;
		term_command.peer = workerPeer;
		mpicxx::single_send(&localDispatcher, term_command, suite.commandType,
				currentVertex()->thisLink.first, command_tag, MPI_COMM_WORLD);
		mpicxx::single_send(&localDispatcher, LinkMsgStruct(currentVertex()->thisLink), suite.linkMsgType,
				currentVertex()->thisLink.first, argument_tag, MPI_COMM_WORLD);
	}else if(vertex_failed) {
		if(logProgress) {
			std::lock_guard<std::mutex> stdout_lock{globalStdoutMutex};
			std::cout << "[" << thisId.rank << ", " << thisId.index << "]"
					" Failed assumptions during split" << std::endl;
		}

		msg::Command command;
		command.opcode = Commands::kCmdCompleteSplit;
		command.peer = workerPeer;
		int command_tag = encodeTag({ 0, kTagCommand });
		int argument_tag = encodeTag({ workerPeer, kTagCmdArgument });
		mpicxx::single_send(&localDispatcher, command, suite.commandType,
				currentVertex()->thisLink.first, command_tag, MPI_COMM_WORLD);
		mpicxx::single_send(&localDispatcher, LinkMsgStruct(currentVertex()->thisLink), suite.linkMsgType,
				currentVertex()->thisLink.first, argument_tag, MPI_COMM_WORLD);
		mpicxx::vector_send(&localDispatcher, std::vector<LinkMsgStruct>(), suite.linkMsgType,
				currentVertex()->thisLink.first, argument_tag, MPI_COMM_WORLD);
	}else if(preselected.empty()) {
		// No variables could be preselected. This means that all variables are
		// already assigned and that the formula is SAT.
		// Note that this case relies on the fact that we handle unsatisfiability first!
		std::cerr << "c Model found during lookahead. Please verify this case." << std::endl;
		
		int command_tag = encodeTag({ 0, MsgTags::kTagCommand });
		int argument_tag = encodeTag({ workerPeer, kTagCmdArgument });
		
		msg::Command res_command;
		res_command.opcode = Commands::kCmdSatisfied;
		res_command.peer = workerPeer;
		mpicxx::single_send(&localDispatcher, res_command, suite.commandType,
				0, command_tag, MPI_COMM_WORLD);
		mpicxx::vector_send(&localDispatcher, model_data, MPIx_primitive<uint32_t>,
				0, argument_tag, MPI_COMM_WORLD);

		msg::Command term_command;
		term_command.opcode = Commands::kCmdTerminateSplit;
		term_command.peer = workerPeer;
		mpicxx::single_send(&localDispatcher, term_command, suite.commandType,
				currentVertex()->thisLink.first, command_tag, MPI_COMM_WORLD);
		mpicxx::single_send(&localDispatcher, LinkMsgStruct(currentVertex()->thisLink), suite.linkMsgType,
				currentVertex()->thisLink.first, argument_tag, MPI_COMM_WORLD);
	}else if(global_values.empty()) {
		// The lookahead yielded no usable variables.
		// We generate a single child node without any branching variables.
		// It still contains all failed literal though.
		std::cerr << "The global_values.empty() case is untested" << std::endl;
		
		CubeLink scatter_link = std::make_pair(suite.worldRank, suite.nextGeneratedId.fetch_add(1));
		CubeNode *scatter_node = new CubeNode(suite, scatter_link, currentVertex()->thisLink,
				{}, cube_clauses);

		numVertices++; // This variable is just a statistic.

		std::unique_lock<std::mutex> guard(sharedData.treeMutex);
		sharedData.insertNode(guard, scatter_link, std::unique_ptr<CubeNode>(scatter_node));
		guard.unlock();

		std::vector<LinkMsgStruct> children_msgs;
		children_msgs.push_back(LinkMsgStruct(scatter_link));
		
		msg::Command command;
		command.opcode = Commands::kCmdCompleteSplit;
		command.peer = workerPeer;
		int command_tag = encodeTag({ 0, kTagCommand });
		int argument_tag = encodeTag({ workerPeer, kTagCmdArgument });
		mpicxx::single_send(&localDispatcher, command, suite.commandType,
				currentVertex()->thisLink.first, command_tag, MPI_COMM_WORLD);
		mpicxx::single_send(&localDispatcher, LinkMsgStruct(currentVertex()->thisLink), suite.linkMsgType,
				currentVertex()->thisLink.first, argument_tag, MPI_COMM_WORLD);
		mpicxx::vector_send(&localDispatcher, children_msgs, suite.linkMsgType,
				currentVertex()->thisLink.first, argument_tag, MPI_COMM_WORLD);
	}else{
		std::sort(global_values.begin(), global_values.end(),
			[] (std::pair<LiteralRefType, cdcl::LookaheadValue> p,
					std::pair<LiteralRefType, cdcl::LookaheadValue> q) {
				return p.second > q.second;
		});

		using Cube = std::vector<LiteralIdType>;
		std::vector<Cube> cubes;

		assert(!global_values.empty());
/*		if(global_values.size() >= 3) {
			cubes.push_back(Cube({ global_values[0].first.id() }));
			cubes.push_back(Cube({ global_values[1].first.id() }));
			cubes.push_back(Cube({ global_values[2].first.id() }));
		}else if(global_values.size() >= 2) {
			cubes.push_back(Cube({ global_values[0].first.id() }));
			cubes.push_back(Cube({ global_values[1].first.id() }));
		}else{
			cubes.push_back(Cube({ global_values.front().first.id() }));
		}*/

		cubes.push_back(Cube({ global_values[0].first.id() }));

		auto desired_cubes = currentTeam.size() - 1;
		for(size_t i = 1; i < std::min(global_values.size(), desired_cubes); i++) {
			if(global_values[i].second < 0.8 * global_values[0].second)
				break;
			cubes.push_back(Cube({ global_values[i].first.id() }));
		}

		// Scatter the cubes.
		std::vector<LinkMsgStruct> children_msgs;
		for(size_t i = 0; i <= cubes.size(); i++) {
			std::vector<LiteralIdType> cube_literals;

			// Add negations of the previous cubes.
			for(size_t j = 0; j < i; j++) {
				if(cubes[j].size() == 1) {
					cube_literals.push_back(cubes[j].front().inverse());
				}else{
					assert(!"Introduce new variables here");
				}
			}

			// Add unit clauses for the current cube.
			if(i < cubes.size()) {
				for(auto it = cubes[i].begin(); it != cubes[i].end(); ++it)
					cube_literals.push_back(*it);
			}
			
			CubeLink scatter_link = std::make_pair(suite.worldRank, suite.nextGeneratedId.fetch_add(1));
			CubeNode *scatter_node = new CubeNode(suite, scatter_link, currentVertex()->thisLink,
					std::move(cube_literals), cube_clauses);

			numVertices++; // This variable is just a statistic.

			std::unique_lock<std::mutex> guard(sharedData.treeMutex);
			sharedData.insertNode(guard, scatter_link, std::unique_ptr<CubeNode>(scatter_node));
			guard.unlock();

			children_msgs.push_back(LinkMsgStruct(scatter_link));
		}

		msg::Command command;
		command.opcode = Commands::kCmdCompleteSplit;
		command.peer = workerPeer;
		int command_tag = encodeTag({ 0, kTagCommand });
		int argument_tag = encodeTag({ workerPeer, kTagCmdArgument });
		mpicxx::single_send(&localDispatcher, command, suite.commandType,
				currentVertex()->thisLink.first, command_tag, MPI_COMM_WORLD);
		mpicxx::single_send(&localDispatcher, LinkMsgStruct(currentVertex()->thisLink), suite.linkMsgType,
				currentVertex()->thisLink.first, argument_tag, MPI_COMM_WORLD);
		mpicxx::vector_send(&localDispatcher, children_msgs, suite.linkMsgType,
				currentVertex()->thisLink.first, argument_tag, MPI_COMM_WORLD);
	}

	numDivide++;
}

template<typename... PT>
void WorkerStruct<PT...>::splitAsWorker() {
	if(logSteps) {
		std::lock_guard<std::mutex> stdout_lock{globalStdoutMutex};
		std::cout << "c [" << thisId.rank << ", " << thisId.index << "] Split "
				<< "(" << currentVertex()->thisLink.first << ", " << currentVertex()->thisLink.second
				<< ") as worker" << std::endl;
	}

	WorkerId captain = currentTeam.front();

	// Receive selected variables from the captain
/*
	std::vector<VariableRefType> selected;
	int selected_tag = encodeTag({ thisId.index, kTagSplitSelected });
	MPIx_Deserialize_multiple<uint32_t>([&] (uint32_t var_index) {
		selected.push_back(VariableRefType(solver.varSpace, VariableIdType::fromIndex(var_index)));
	}, MPIx_primitive<uint32_t>, captain.rank, selected_tag);
*/
	solver.varSpace.cleanWatches(&solver.clauseSpace);
	solver.trail.start();

	// Check if all workers were able to setup the trail.
	mpicxx::single_send(&localDispatcher, static_cast<int>(!solver.trail.conflict()), MPIx_primitive<int>,
			captain.rank, encodeTag({ thisId.index, kTagSplitLocalTrail }), MPI_COMM_WORLD);

	int trail_okay;
	mpicxx::single_recv(&localDispatcher, trail_okay, MPIx_primitive<int>,
			captain.rank, encodeTag({ thisId.index, kTagSplitGlobalTrail }),
			MPI_COMM_WORLD, MPI_STATUS_IGNORE);

	if(!trail_okay) {	
		solver.trail.reset();
		return;
	}
	
	// Setup the load balancer.
	dist_balancer::Balancer<mpicxx::trivial_mapping<uint32_t>> balancer({ thisId.rank, thisId.index },
			&_balanceContext);

	std::vector<dist_balancer::Worker> balance_workers;
	for(auto tp = currentTeam.begin(); tp != currentTeam.end(); ++tp)
		balance_workers.push_back({tp->rank, tp->index});

	std::vector<uint32_t> balance_vars;
	balancer.initiate(balance_workers, balance_vars.begin(), balance_vars.end());
	balancer.run();

	// Do the actual evaluation.
	cdcl::LookaheadResult result = cdcl::LookaheadResult::kResOkay;
	std::vector<std::pair<LiteralRefType, cdcl::LookaheadValue>> values;
	std::vector<ClauseRefType> failed;
	evaluateSplit(&balancer, result, values, failed);

	balancer.shutdown();

	solver.trail.reset();

	// Send the lookahead result to the captain.
	int result_tag = encodeTag({ thisId.index, kTagSplitResult });
	mpicxx::single_send(&localDispatcher, static_cast<int>(result), MPIx_primitive<int>,
			captain.rank, result_tag, MPI_COMM_WORLD);
	
	// Send the lookahead heuristic values.
	std::vector<SplitValueMsgStruct> local_values;
	for(auto value : values) {
		SplitValueMsgStruct msg;
		msg.literal = value.first.getIndex();
		msg.value = value.second;
		local_values.push_back(msg);
	}

	int value_tag = encodeTag({ thisId.index, kTagSplitValues });
	mpicxx::vector_send(&localDispatcher, local_values, suite.splitValueMsgType,
			captain.rank, value_tag, MPI_COMM_WORLD);
	
	// Send the failed literals.
	std::vector<uint32_t> failed_data;
	for(auto clause : failed) {
		// Note that we assume that the clause name fits into 64 bits.
		auto bits = clause.name().bits();
		failed_data.push_back(bits & 0xFFFFFFFF);
		failed_data.push_back(bits >> 32);

		failed_data.push_back(clause.globalLbd());
		
		for(auto it = clause.beginLits(); it != clause.endLits(); ++it)
			failed_data.push_back(it->getIndex() + 1);
		failed_data.push_back(0);
	}

	int failed_tag = encodeTag({ thisId.index, kTagSplitFailed });
	mpicxx::vector_send(&localDispatcher, failed_data, MPIx_primitive<uint32_t>,
			captain.rank, failed_tag, MPI_COMM_WORLD);
}

template<typename... PT>
void WorkerStruct<PT...>::evaluateSplit(dist_balancer::Balancer<mpicxx::trivial_mapping<uint32_t>> *balancer,
		cdcl::LookaheadResult &result,
		std::vector<std::pair<LiteralRefType, cdcl::LookaheadValue>> &values,
		std::vector<ClauseRefType> &failed) {

	sys::HptCounter start = sys::hptCurrent();
	while(true) {
		auto stolen_var = balancer->steal();
		if(!stolen_var)
			break;

		VariableRefType ref(solver.varSpace, VariableIdType::fromIndex(*stolen_var));
		if(!ref.isPresent())
			continue;

		if(solver.assignment.isAssigned(ref.id()))
			continue;
	
		std::tuple<cdcl::LookaheadResult, LiteralRefType, ClauseRefType, cdcl::LookaheadValue> var_result
				= cdcl::Lookahead<cdcl::UseHooks<WorkerHooks<PT...>>>::lookaheadVar(ref, solver, solver.occlists,
						solver.assignment, solver.trail);
		
		assert(result == cdcl::kResOkay);
		if(std::get<0>(var_result) == cdcl::kResFailedAssumption
				|| std::get<0>(var_result) == cdcl::kResFormulaUnsat) {
			result = std::get<0>(var_result);
			break;
		}else if(std::get<0>(var_result) == cdcl::kResFailedLiteral) {
			failed.push_back(std::get<2>(var_result));
		}else{
			assert(std::get<0>(var_result) == cdcl::kResOkay);
			values.push_back(std::make_pair(std::get<1>(var_result), std::get<3>(var_result)));
		}

		boost::this_fiber::yield();
	}
	splitTime += sys::hptElapsed(start);

	// We break the previous loop if we encounter a failed assumption.
	// In this case we need to drain the load balancer to allow it to shut down.	
	while(true) {
		auto stolen_var = balancer->steal();
		if(!stolen_var)
			break;
	}

	std::sort(values.begin(), values.end(),
		[] (const std::pair<LiteralRefType, cdcl::LookaheadValue> &a,
				const std::pair<LiteralRefType, cdcl::LookaheadValue> &b) {
			return a.second > b.second;
		});
}

template<typename... PT>
void WorkerStruct<PT...>::startSolve(CubeLink link) {
	assert(workState == WorkState::kWorkNone);
	workState = WorkState::kWorkSolve;
	interruptState = false;
	_lastReportConflicts = solver.trail.conflictCounter;
	_lastReportPropagations = solver.trail.propagationCounter;
	navigate(link);

	if(logSteps) {
		std::lock_guard<std::mutex> stdout_lock{globalStdoutMutex};
		std::cout << "c [" << thisId.rank << ", " << thisId.index << "] Solve "
				<< "(" << currentVertex()->thisLink.first << ", " << currentVertex()->thisLink.second << ")" << std::endl;
	}

	solver.varSpace.cleanWatches(&solver.clauseSpace);
	solver.trail.start();
}

template<typename... PT>
void WorkerStruct<PT...>::doSolve() {
	// 4'000'000 was the median propagations/second value of the
	// sequential solver on a Intel Xeon E5-2690 v2 CPU for
	// the SAT Competition 2016 Application benchmarks.
	constexpr uint64_t approxPropsPerSecond = 4000000;

	cdcl::SearchLimits limits;
	limits.propagations = approxPropsPerSecond / 50;

	auto start = sys::hptCurrent();

	SolveState state = cdcl::search(solver, limits);

	auto elapsed = sys::hptElapsed(start);
	solveTime += elapsed;

	if(state == SolveState::kStateBreak) {
		satisfiedReduction.simplify();		

		if(interruptState) {
			numInterruptions++;

			msg::Command command;
			command.opcode = Commands::kCmdInterruptSolve;
			command.peer = workerPeer;
			int command_tag = encodeTag({ 0, kTagCommand });
			int argument_tag = encodeTag({ workerPeer, kTagCmdArgument });
			mpicxx::single_send(&localDispatcher, command, suite.commandType,
					currentVertex()->thisLink.first, command_tag, MPI_COMM_WORLD);
			mpicxx::single_send(&localDispatcher, LinkMsgStruct(currentVertex()->thisLink), suite.linkMsgType,
					currentVertex()->thisLink.first, argument_tag, MPI_COMM_WORLD);
			mpicxx::single_send(&localDispatcher, thisId, suite.workerIdType,
					currentVertex()->thisLink.first, argument_tag, MPI_COMM_WORLD);
		}else{
			 if(solver.trail.propagationCounter > _lastReportPropagations + approxPropsPerSecond) {
				auto progress = solver.trail.conflictCounter - _lastReportConflicts;

				msg::Command command;
				command.opcode = Commands::kCmdProgress;
				command.peer = workerPeer;
				int command_tag = encodeTag({ 0, kTagCommand });
				int argument_tag = encodeTag({ workerPeer, kTagCmdArgument });
				mpicxx::single_send(&localDispatcher, command, suite.commandType,
						currentVertex()->thisLink.first, command_tag, MPI_COMM_WORLD);
				mpicxx::single_send(&localDispatcher, LinkMsgStruct(currentVertex()->thisLink), suite.linkMsgType,
						currentVertex()->thisLink.first, argument_tag, MPI_COMM_WORLD);
				mpicxx::single_send(&localDispatcher, static_cast<uint64_t>(progress), MPIx_primitive<uint64_t>,
						currentVertex()->thisLink.first, argument_tag, MPI_COMM_WORLD);

				_lastReportConflicts = solver.trail.conflictCounter;
				_lastReportPropagations = solver.trail.propagationCounter;
			}

			return;
		}
	}else if(state == SolveState::kStateAssumptionFail) {
		numDirect++;

		msg::Command command;
		command.opcode = Commands::kCmdCompleteSolve;
		command.peer = workerPeer;
		int command_tag = encodeTag({ 0, kTagCommand });
		int argument_tag = encodeTag({ workerPeer, kTagCmdArgument });
		mpicxx::single_send(&localDispatcher, command, suite.commandType,
				currentVertex()->thisLink.first, command_tag, MPI_COMM_WORLD);
		mpicxx::single_send(&localDispatcher, LinkMsgStruct(currentVertex()->thisLink), suite.linkMsgType,
				currentVertex()->thisLink.first, argument_tag, MPI_COMM_WORLD);
		mpicxx::single_send(&localDispatcher, thisId, suite.workerIdType,
				currentVertex()->thisLink.first, argument_tag, MPI_COMM_WORLD);
	}else if(state == SolveState::kStateSatisfied) {
		std::vector<uint32_t> model_data;

		std::vector<LiteralIdType> premodel;
		for(auto var : solver.varSpace) {
			if(solver.assignment.isTrue(var.positive()))
				premodel.push_back(var.positive().id());
			if(solver.assignment.isTrue(var.negative()))
				premodel.push_back(var.negative().id());
		}

		typename SolverType::EliminationStackType::ModelExtender me{&solver.eliminationStack};
		auto model = me.extend(premodel);
		for(auto literal : model)
			model_data.push_back(literal.getIndex());

		int command_tag = encodeTag({ 0, MsgTags::kTagCommand });
		int argument_tag = encodeTag({ workerPeer, kTagCmdArgument });

		msg::Command res_command;
		res_command.opcode = Commands::kCmdSatisfied;
		res_command.peer = workerPeer;
		mpicxx::single_send(&localDispatcher, res_command, suite.commandType,
				0, command_tag, MPI_COMM_WORLD);
		mpicxx::vector_send(&localDispatcher, model_data, MPIx_primitive<uint32_t>,
				0, argument_tag, MPI_COMM_WORLD);

		msg::Command term_command;
		term_command.opcode = Commands::kCmdTerminateSolve;
		term_command.peer = workerPeer;
		mpicxx::single_send(&localDispatcher, term_command, suite.commandType,
				currentVertex()->thisLink.first, command_tag, MPI_COMM_WORLD);
		mpicxx::single_send(&localDispatcher, LinkMsgStruct(currentVertex()->thisLink), suite.linkMsgType,
				currentVertex()->thisLink.first, argument_tag, MPI_COMM_WORLD);
		mpicxx::single_send(&localDispatcher, thisId, suite.workerIdType,
				currentVertex()->thisLink.first, argument_tag, MPI_COMM_WORLD);
	}else if(state == SolveState::kStateUnsatisfiable) {
		int command_tag = encodeTag({ 0, MsgTags::kTagCommand });
		int argument_tag = encodeTag({ workerPeer, kTagCmdArgument });

		msg::Command res_command;
		res_command.opcode = Commands::kCmdUnsatisfiable;
		res_command.peer = workerPeer;
		mpicxx::single_send(&localDispatcher, res_command, suite.commandType,
				0, command_tag, MPI_COMM_WORLD);

		msg::Command term_command;
		term_command.opcode = Commands::kCmdTerminateSolve;
		term_command.peer = workerPeer;
		mpicxx::single_send(&localDispatcher, term_command, suite.commandType,
				currentVertex()->thisLink.first, command_tag, MPI_COMM_WORLD);
		mpicxx::single_send(&localDispatcher, LinkMsgStruct(currentVertex()->thisLink), suite.linkMsgType,
				currentVertex()->thisLink.first, argument_tag, MPI_COMM_WORLD);
		mpicxx::single_send(&localDispatcher, thisId, suite.workerIdType,
				currentVertex()->thisLink.first, argument_tag, MPI_COMM_WORLD);
	}else throw std::logic_error("Illegal solve state");
	
	solver.trail.reset();

	workState = WorkState::kWorkNone;
}

template<typename... PT>
void WorkerStruct<PT...>::collectClauses() {
	//FIXME p_simplifyConfig.collectClauses(solver);
}

template<typename... PT>
void WorkerStruct<PT...>::initialize(std::string instance) {
	if(thisId.index < suite.actualWorkersPerNode / 2) {
		solver.emulation = cdcl::Emulation::miniSat;
	}else{
		solver.emulation = cdcl::Emulation::glucose;
	}
	solver.resetBaseHeuristics();

	// Read the instance file.
	int instance_fd = open(instance.c_str(), O_RDONLY);
	if(instance_fd == -1)
		throw std::runtime_error("Could not read input file");

	cdcl::CnfParser<cdcl::UseHooks<WorkerHooks<PT...>>> parser(solver.varSpace, solver.clauseSpace, instance_fd);
	parser.parse();

	if(close(instance_fd) != 0)
		throw std::runtime_error("Could not close instance file");
	
	// NOTE: we need occlists for the lookahead
	solver.resetInputHeuristics();
	solver.occlists.construct();

	cdcl::Preprocessor<
		cdcl::UseHooks<WorkerHooks<PT...>>
	> preprocessor{&solver};
	if(!suite.worldRank)
		preprocessor.verbose = true;

	preprocessor.run();
	assert(solver.trail.isReset());
}

template<typename... PT>
void WorkerStruct<PT...>::initialize(SolverType *src_solver) {
	if(thisId.index < suite.actualWorkersPerNode / 2) {
		solver.emulation = cdcl::Emulation::miniSat;
	}else{
		solver.emulation = cdcl::Emulation::glucose;
	}
	solver.resetBaseHeuristics();

	// Clone the instance.
	solver.varSpace.reserveVars(src_solver->varSpace.count());
	for(auto it = src_solver->varSpace.begin(); it != src_solver->varSpace.end(); ++it) {
		VariableRefType variable{solver.varSpace, solver.varSpace.allocVar()};
		if(!it->isPresent())
			variable.erase();
	}

	std::vector<LiteralIdType> literals;
	src_solver->clauseSpace.forEach([&] (ClauseRefType src_clause) {
		if(!src_clause.isPresent())
			return;
		assert(src_clause.isEssential());

		for(auto it = src_clause.beginLits(); it != src_clause.endLits(); ++it)
			literals.push_back(it->id());

		// TODO: We would like to keep the original name here.
		auto name = !src_clause.name().origin() ? src_clause.name() : solver.uniqueClauseName();
		auto clause = solver.clauseSpace.allocate(name, src_clause.length(),
				literals.begin(), literals.end(), ClauseAllocation::permanent);
		clause.markAsEssential();

		literals.clear();
	});

	solver.eliminationStack = src_solver->eliminationStack;

	solver.resetInputHeuristics();
	solver.occlists.construct();
}

template<typename... PT>
void WorkerStruct<PT...>::run() {
	_fiber = boost::fibers::fiber([this] () {
		constexpr bool enableDistillation = false;
		if(enableDistillation) {
			auto orig_clauses = solver.clauseSpace.numPresent();

			cdcl::DistributedDistillation<cdcl::UseHooks<WorkerHooks<PT...>>> distillation(suite.seqComm, solver, &localDispatcher,
					thisId.index, suite.actualWorkersPerNode);
			auto start = sys::hptCurrent();
			distillation.perform();
			auto elapsed = sys::hptElapsed(start);

			if(!minimalOutput || !suite.worldRank) {
				std::lock_guard<std::mutex> stdout_lock{globalStdoutMutex};
				std::cout << "c [" << thisId.rank << ", " << thisId.index << "] Simplify time: "
						<< (elapsed / 1000000000) << "s, "
						<< "# original clauses: " << orig_clauses << ", # clauses remaining: "
						<< solver.clauseSpace.numPresent() << std::endl;
			}
		}

		// Clause send/receive futures.
		boost::fibers::future<void> cs_future;
		boost::fibers::future<void> cr_future;

		MPI_Status status;
		cr_future = mpicxx::vector_recv(mpicxx::async, &localDispatcher, exchangeRecvBuffer,
				MPIx_primitive<uint32_t>, MPI_ANY_SOURCE, thisId.index,
				suite.exchangeComm, &status);

		while(true) {
//			std::cout << "[" << thisId.rank << ", " << thisId.index << "] Yield." << std::endl;
			boost::this_fiber::yield();

			// Receive shared clauses from other nodes.
			if(cr_future.wait_for(std::chrono::seconds(0)) == boost::fibers::future_status::ready) {
				cr_future.get();

				int count;
				MPI_Get_count(&status, MPIx_primitive<uint32_t>, &count);

				auto limit = exchangeRecvBuffer.begin() + count;
				for(auto it = exchangeRecvBuffer.begin(); it != limit; /* no increment */) {
					uint64_t name_low = *it++;
					assert(it != limit);
					uint64_t name_high = *it++;
					assert(it != limit);

					auto lbd = *it++;
					assert(it != limit);

					std::vector<LiteralIdType> lits;
					while(*it != 0) {
						lits.push_back(LiteralIdType::fromIndex(*it++ - 1));
						assert(it != limit);
					}
					it++;

					// Do not import clauses that originate from this solver.
					auto name = ClauseNameType{(name_high << 32) | name_low};
					if(name.origin() == solver.getConfigId())
						continue;

					auto clause = solver.clauseSpace.allocate(name, lits.size(),
							lits.begin(), lits.end(), ClauseAllocation::frozen);
					clause.updateLbd(lbd);
					numImports++;

					exportQueue.push_back(CubeClause{name, lits, lbd});
					cycleQueue.push_back(CubeClause{name, std::move(lits), lbd});
				}

				cr_future = mpicxx::vector_recv(mpicxx::async, &localDispatcher, exchangeRecvBuffer,
						MPIx_primitive<uint32_t>, MPI_ANY_SOURCE, thisId.index,
						suite.exchangeComm, &status);
			}

			// Receive shared clauses from other workers on this node.
			if(intraReady.load(std::memory_order_relaxed)) {
				std::vector<CubeClause> queue;
				{
					std::lock_guard<std::mutex> lock{intraMutex};
					queue = std::move(intraQueue);
					intraQueue.clear();
					intraReady.store(false, std::memory_order_relaxed);
				}

				for(auto it = queue.begin(); it != queue.end(); ++it) {
					// Do not import clauses that originate from this index.
					auto origin_index = (it->name.origin() - 1) % suite.configuredWorkersPerNode;
					if(origin_index == thisId.index)
						continue;

					auto clause = solver.clauseSpace.allocate(it->name, it->literals.size(),
							it->literals.begin(), it->literals.end(), ClauseAllocation::frozen);
					clause.updateLbd(it->lbd);
					numImports++;

					cycleQueue.push_back(std::move(*it));
				}
			}

			// Send shared clauses to other nodes.
			if(cs_future.valid() && cs_future.wait_for(std::chrono::seconds(0)) == boost::fibers::future_status::ready)
				cs_future.get();

			if(!cs_future.valid() && !exportQueue.empty()) {
				// Construct a send buffer for workers on other nodes.
				exchangeSendBuffer.clear();

				auto cp = exportQueue.begin();
				for(; cp != exportQueue.end(); ++cp) {
					auto num_slots = 4 + cp->literals.size();
					if(exchangeSendBuffer.size() + num_slots > maxExchangeBuffer)
						break;

					// Note that we assume that the clause name fits into 64 bits.
					auto bits = cp->name.bits();
					exchangeSendBuffer.push_back(bits & 0xFFFFFFFF);
					exchangeSendBuffer.push_back(bits >> 32);

					exchangeSendBuffer.push_back(cp->lbd);
				
					for(auto it = cp->literals.begin(); it != cp->literals.end(); ++it)
						exchangeSendBuffer.push_back(it->getIndex() + 1);
					exchangeSendBuffer.push_back(0);
				}
				assert(exchangeSendBuffer.size() <= maxExchangeBuffer);
				exportQueue.erase(exportQueue.begin(), cp);

				auto target = (suite.worldRank + 1) % suite.worldSize;
				cs_future = mpicxx::vector_send(mpicxx::async, &localDispatcher,
						exchangeSendBuffer, MPIx_primitive<uint32_t>,
						target, thisId.index, suite.exchangeComm);
			}

			// Send shared clauses to other workers on this node.
			if(!cycleQueue.empty()) {
				auto next = (thisId.index + 1) % suite.actualWorkersPerNode;
				{
					std::lock_guard<std::mutex> lock(suite.workers[next]->intraMutex);
					for(auto it = cycleQueue.begin(); it != cycleQueue.end(); ++it)
						suite.workers[next]->intraQueue.push_back(std::move(*it));
					suite.workers[next]->intraReady.store(true, std::memory_order_relaxed);
				}
				cycleQueue.clear();
			}

			if(workState == kWorkSolve) {
				doSolve();
			}else{
				// TODO: Check the action queue first.
				assert(workState == kWorkNone);
				inprocessor.step();
			}

			std::unique_lock<std::mutex> guard(queueMutex);
			if(taskQueue.empty()) {
				// TODO: Wait for a condition variable instead of yielding.
				continue;
			}
			WorkTask task = std::move(taskQueue.front());
			taskQueue.pop();
			guard.unlock();

			if(task.state == kWorkSolve) {
				startSolve(task.node->thisLink);
			}else if(task.state == kWorkSplit) {
				currentTeam = std::move(task.team);
				doSplit(task.node->thisLink);
			}else if(task.state == kActionInterrupt) {
				if(workState == kWorkSolve) {
//					std::cout << "[" << thisId.rank << ", " << thisId.index << "] Honoring interrupt request." << std::endl;
					interruptState = true;
				}else{
					assert(workState == kWorkNone);
					if(logProgress) {
						std::lock_guard<std::mutex> stdout_lock{globalStdoutMutex};
						std::cout << "c [" << thisId.rank << ", " << thisId.index << "]"
								" Ignoring interrupt request" << std::endl;
					}
				}
			}else if(task.state == kActionShutdown) {
				break;
			}else throw std::logic_error("Illegal work state");
		}

		// Report some statistics.
		if(!minimalOutput || !suite.worldRank) {
			std::lock_guard<std::mutex> stdout_lock{globalStdoutMutex};
			std::cout << "c [" << thisId.rank << ", " << thisId.index << "] # divide-steps: "
				<< numDivide << ", # generated vertices: "
				<< numVertices << std::endl;
			std::cout << "c [" << thisId.rank << ", " << thisId.index << "] # successful conquer-steps: "
					<< numDirect << ", # interrupted conquer-steps: "
					<< numInterruptions << std::endl;
			std::cout << "c [" << thisId.rank << ", " << thisId.index << "] Divide time: "
					<< (splitTime / 1000000000) << " s, conquer time: "
					<< (solveTime / 1000000000) << " s, idle/inprocessing time: "
					<< std::chrono::duration_cast<std::chrono::seconds>(inprocessor.stats().time).count()
					<< " s" << std::endl;
			std::cout << "c [" << thisId.rank << ", " << thisId.index << "] Clause imports: "
					<< numImports << ", exports: " << numExports << std::endl;
		}
	});
}

template<typename... PT>
void WorkerStruct<PT...>::join() {
	_fiber.join();
}

template<typename... PT>
void WorkerStruct<PT...>::enqueue(std::unique_lock<std::mutex> &guard, WorkTask task) {
	assert(guard && guard.mutex() == &queueMutex);
	taskQueue.push(std::move(task));
}

// --------------------------------------------------------
// ServerStruct
// --------------------------------------------------------

template<typename... PT>
ServerStruct<PT...>::ServerStruct(SuiteType &suite)
: suite(suite), _cancel(false) { }

template<typename... PT>
auto ServerStruct<PT...>::sharedData() -> SharedDataType & {
	return suite.sharedData;
}

template<typename... PT>
void ServerStruct<PT...>::run() {
	_fiber = boost::fibers::fiber([this] () {
		MPI_Status status;
		const int command_tag = encodeTag({ 0, kTagCommand });
		msg::Command command;
		auto future = mpicxx::async_recv(&localDispatcher, &command, 1, suite.commandType,
				MPI_ANY_SOURCE, command_tag, MPI_COMM_WORLD, &status);

		while(!_cancel) {
			future.wait();
			future.get();
			receiveCommand(status.MPI_SOURCE, command.opcode, command.peer);

			future = mpicxx::async_recv(&localDispatcher, &command, 1, suite.commandType,
					MPI_ANY_SOURCE, command_tag, MPI_COMM_WORLD, &status);
		}
	});
}

template<typename... PT>
void ServerStruct<PT...>::join() {
	_fiber.join();
}

template<typename... PT>
void ServerStruct<PT...>::receiveCommand(int source, int opcode, int peer) {
//	std::cout << "[" << suite.worldRank << "] Received command " << command
//			<< " from " << source << std::endl;
	
	int argument_tag = encodeTag({ peer, kTagCmdArgument });
	int result_tag = encodeTag({ peer, kTagCmdResult });

	if(opcode == Commands::kCmdCancelServer) {
		_cancel = true;
	}else if(opcode == Commands::kCmdEnterNode) {
		LinkMsgStruct link_msg;
		std::vector<WorkerId> workers;
		mpicxx::single_recv(&localDispatcher, link_msg, suite.linkMsgType, source, argument_tag,
				MPI_COMM_WORLD, MPI_STATUS_IGNORE);
		workers.resize(mpicxx::size_probe(&localDispatcher, suite.workerIdType, source, argument_tag,
				MPI_COMM_WORLD));
		mpicxx::vector_recv(&localDispatcher, workers, suite.workerIdType, source, argument_tag,
				MPI_COMM_WORLD, MPI_STATUS_IGNORE);
		
		std::unique_lock<std::mutex> tree_guard(sharedData().treeMutex);
		typename SharedDataType::CubeNode *node = sharedData().atNode(tree_guard, link_msg.link);
		tree_guard.unlock();
		
		localOffloader->enqueue([node, workers] () { // TODO: capture by move
			std::unique_lock<std::mutex> route_guard(node->mutex);
			node->routeDown(route_guard, std::move(workers));
		});
	}else if(opcode == Commands::kCmdLeaveChild) {
		LinkMsgStruct vertex_link_msg, child_link_msg;
		std::vector<WorkerId> workers;
		mpicxx::single_recv(&localDispatcher, vertex_link_msg, suite.linkMsgType, source, argument_tag,
				MPI_COMM_WORLD, MPI_STATUS_IGNORE);
		mpicxx::single_recv(&localDispatcher, child_link_msg, suite.linkMsgType, source, argument_tag,
				MPI_COMM_WORLD, MPI_STATUS_IGNORE);
		workers.resize(mpicxx::size_probe(&localDispatcher, suite.workerIdType, source, argument_tag,
				MPI_COMM_WORLD));
		mpicxx::vector_recv(&localDispatcher, workers, suite.workerIdType, source, argument_tag,
				MPI_COMM_WORLD, MPI_STATUS_IGNORE);
		
		std::unique_lock<std::mutex> tree_guard(sharedData().treeMutex);
		typename SharedDataType::CubeNode *vertex = sharedData().atNode(tree_guard, vertex_link_msg.link);
		tree_guard.unlock();
		
		localOffloader->enqueue([=] () { // TODO: capture by move
			std::unique_lock<std::mutex> route_guard(vertex->mutex);
			vertex->routeUp(route_guard, child_link_msg.link, std::move(workers));
		});
	}else if(opcode == Commands::kCmdSplit) {
		WorkerId worker;
		std::vector<WorkerId> team;
		std::vector<LinkMsgStruct> path;
		mpicxx::single_recv(&localDispatcher, worker, suite.workerIdType, source, argument_tag,
				MPI_COMM_WORLD, MPI_STATUS_IGNORE);
		team.resize(mpicxx::size_probe(&localDispatcher, suite.workerIdType, source, argument_tag,
				MPI_COMM_WORLD));
		mpicxx::vector_recv(&localDispatcher, team, suite.workerIdType, source, argument_tag,
				MPI_COMM_WORLD, MPI_STATUS_IGNORE);
		path.resize(mpicxx::size_probe(&localDispatcher, suite.linkMsgType, source, argument_tag,
				MPI_COMM_WORLD));
		mpicxx::vector_recv(&localDispatcher, path, suite.linkMsgType, source, argument_tag,
				MPI_COMM_WORLD, MPI_STATUS_IGNORE);
	
		localOffloader->enqueue([this, worker, team, path] () { // TODO: capture by move
			// merge the path into our local tree
			CubeLink parent_link = std::make_pair(kNoRank, kIllegalId);
			for(auto path_it = path.rbegin(); path_it != path.rend(); ++path_it) {
				suite.mergeNode(parent_link, path_it->link);
				parent_link = path_it->link;
			}

			std::unique_lock<std::mutex> guard(sharedData().treeMutex);
			typename SharedDataType::CubeNode *node = sharedData().atNode(guard, path.front().link);
			guard.unlock();

			typename WorkerType::WorkTask task(kWorkSplit);
			task.node = node;
			task.team = std::move(team);

			assert(worker.rank == suite.worldRank);
			std::unique_lock<std::mutex> queue_guard(suite.workers[worker.index]->queueMutex);
			suite.workers[worker.index]->enqueue(queue_guard, std::move(task));
			queue_guard.unlock();
		});
	}else if(opcode == Commands::kCmdSolve) {
		WorkerId worker;
		std::vector<LinkMsgStruct> path;
		mpicxx::single_recv(&localDispatcher, worker, suite.workerIdType, source, argument_tag,
				MPI_COMM_WORLD, MPI_STATUS_IGNORE);
		path.resize(mpicxx::size_probe(&localDispatcher, suite.linkMsgType, source, argument_tag,
				MPI_COMM_WORLD));
		mpicxx::vector_recv(&localDispatcher, path, suite.linkMsgType, source, argument_tag,
				MPI_COMM_WORLD, MPI_STATUS_IGNORE);
	
		localOffloader->enqueue([this, worker, path] () { // TODO: capture by move
			// merge the path into our local tree
			CubeLink parent_link = std::make_pair(kNoRank, kIllegalId);
			for(auto path_it = path.rbegin(); path_it != path.rend(); ++path_it) {
				suite.mergeNode(parent_link, path_it->link);
				parent_link = path_it->link;
			}

			std::unique_lock<std::mutex> guard(sharedData().treeMutex);
			typename SharedDataType::CubeNode *node = sharedData().atNode(guard, path.front().link);
			guard.unlock();

			typename WorkerType::WorkTask task(kWorkSolve);
			task.node = node;

			assert(worker.rank == suite.worldRank);
			std::unique_lock<std::mutex> queue_guard(suite.workers[worker.index]->queueMutex);
			suite.workers[worker.index]->enqueue(queue_guard, std::move(task));
			queue_guard.unlock();
		});
	}else if(opcode == Commands::kCmdRequestInterrupt) {
		WorkerId worker;
		mpicxx::single_recv(&localDispatcher, worker, suite.workerIdType, source, argument_tag,
				MPI_COMM_WORLD, MPI_STATUS_IGNORE);

		// We need to do this in the offloader to order it w.r.t. kCmdSolve.
		localOffloader->enqueue([this, worker] () {
			typename WorkerType::WorkTask task(kActionInterrupt);

			assert(worker.rank == suite.worldRank);
			std::unique_lock<std::mutex> queue_guard(suite.workers[worker.index]->queueMutex);
			suite.workers[worker.index]->enqueue(queue_guard, std::move(task));
			queue_guard.unlock();
		});
	}else if(opcode == Commands::kCmdShutdownWorker) {
		WorkerId worker;
		mpicxx::single_recv(&localDispatcher, worker, suite.workerIdType, source, argument_tag,
				MPI_COMM_WORLD, MPI_STATUS_IGNORE);

		// We need to do this in the offloader to order it w.r.t. other commands.
		localOffloader->enqueue([this, worker] () {
			typename WorkerType::WorkTask task(kActionShutdown);

			assert(worker.rank == suite.worldRank);
			std::unique_lock<std::mutex> queue_guard(suite.workers[worker.index]->queueMutex);
			suite.workers[worker.index]->enqueue(queue_guard, std::move(task));
			queue_guard.unlock();
		});
	}else if(opcode == Commands::kCmdProgress) {
		LinkMsgStruct link_msg;
		uint64_t progress;
		mpicxx::single_recv(&localDispatcher, link_msg, suite.linkMsgType, source, argument_tag,
				MPI_COMM_WORLD, MPI_STATUS_IGNORE);
		mpicxx::single_recv(&localDispatcher, progress, MPIx_primitive<uint64_t>, source, argument_tag,
				MPI_COMM_WORLD, MPI_STATUS_IGNORE);

		std::unique_lock<std::mutex> tree_guard(sharedData().treeMutex);
		typename SharedDataType::CubeNode *node = sharedData().atNode(tree_guard, link_msg.link);
		tree_guard.unlock();
		
		localOffloader->enqueue([node, progress] () {
			std::unique_lock<std::mutex> node_guard(node->mutex);
			node->onProgress(node_guard, progress);
		});
	}else if(opcode == Commands::kCmdInterruptSolve) {
		LinkMsgStruct link_msg;
		WorkerId worker;
		mpicxx::single_recv(&localDispatcher, link_msg, suite.linkMsgType, source, argument_tag,
				MPI_COMM_WORLD, MPI_STATUS_IGNORE);
		mpicxx::single_recv(&localDispatcher, worker, suite.workerIdType, source, argument_tag,
				MPI_COMM_WORLD, MPI_STATUS_IGNORE);

		std::unique_lock<std::mutex> tree_guard(sharedData().treeMutex);
		typename SharedDataType::CubeNode *node = sharedData().atNode(tree_guard, link_msg.link);
		tree_guard.unlock();
		
		localOffloader->enqueue([node, worker] () {
			std::unique_lock<std::mutex> node_guard(node->mutex);
			node->interruptSolve(node_guard, worker);
		});
	}else if(opcode == Commands::kCmdCompleteSplit) {
		LinkMsgStruct link_msg;
		std::vector<LinkMsgStruct> children_msgs;
		mpicxx::single_recv(&localDispatcher, link_msg, suite.linkMsgType, source, argument_tag,
				MPI_COMM_WORLD, MPI_STATUS_IGNORE);
		children_msgs.resize(mpicxx::size_probe(&localDispatcher, suite.linkMsgType, source, argument_tag,
				MPI_COMM_WORLD));
		mpicxx::vector_recv(&localDispatcher, children_msgs, suite.linkMsgType, source, argument_tag,
				MPI_COMM_WORLD, MPI_STATUS_IGNORE);

		std::unique_lock<std::mutex> tree_guard(sharedData().treeMutex);
		typename SharedDataType::CubeNode *node = sharedData().atNode(tree_guard, link_msg.link);
		tree_guard.unlock();
		
		std::vector<CubeLink> child_links;
		for(auto it = children_msgs.begin(); it != children_msgs.end(); ++it)
			child_links.push_back(it->link);

		localOffloader->enqueue([node, child_links] () { // TODO: capture by move
			std::unique_lock<std::mutex> node_guard(node->mutex);
			node->completeSplit(node_guard, std::move(child_links));
		});
	}else if(opcode == Commands::kCmdTerminateSplit) {
		LinkMsgStruct link_msg;
		mpicxx::single_recv(&localDispatcher, link_msg, suite.linkMsgType, source, argument_tag,
				MPI_COMM_WORLD, MPI_STATUS_IGNORE);

		std::unique_lock<std::mutex> tree_guard(sharedData().treeMutex);
		typename SharedDataType::CubeNode *node = sharedData().atNode(tree_guard, link_msg.link);
		tree_guard.unlock();

		localOffloader->enqueue([node] () { // TODO: capture by move
			std::unique_lock<std::mutex> node_guard(node->mutex);
			node->terminateSplit(node_guard);
		});
	}else if(opcode == Commands::kCmdCompleteSolve) {
		LinkMsgStruct link_msg;
		WorkerId worker;
		mpicxx::single_recv(&localDispatcher, link_msg, suite.linkMsgType, source, argument_tag,
				MPI_COMM_WORLD, MPI_STATUS_IGNORE);
		mpicxx::single_recv(&localDispatcher, worker, suite.workerIdType, source, argument_tag,
				MPI_COMM_WORLD, MPI_STATUS_IGNORE);

		std::unique_lock<std::mutex> tree_guard(sharedData().treeMutex);
		typename SharedDataType::CubeNode *node = sharedData().atNode(tree_guard, link_msg.link);
		tree_guard.unlock();
		
		localOffloader->enqueue([node, worker] () {
			std::unique_lock<std::mutex> node_guard(node->mutex);
			node->completeSolve(node_guard, worker);
		});
	}else if(opcode == Commands::kCmdTerminateSolve) {
		LinkMsgStruct link_msg;
		WorkerId worker;
		mpicxx::single_recv(&localDispatcher, link_msg, suite.linkMsgType, source, argument_tag,
				MPI_COMM_WORLD, MPI_STATUS_IGNORE);
		mpicxx::single_recv(&localDispatcher, worker, suite.workerIdType, source, argument_tag,
				MPI_COMM_WORLD, MPI_STATUS_IGNORE);

		std::unique_lock<std::mutex> tree_guard(sharedData().treeMutex);
		typename SharedDataType::CubeNode *node = sharedData().atNode(tree_guard, link_msg.link);
		tree_guard.unlock();
		
		localOffloader->enqueue([node, worker] () {
			std::unique_lock<std::mutex> node_guard(node->mutex);
			node->terminateSolve(node_guard, worker);
		});
	}else if(opcode == Commands::kCmdSatisfied) {
		std::vector<uint32_t> model_data;
		model_data.resize(mpicxx::size_probe(&localDispatcher, MPIx_primitive<uint32_t>,
				source, argument_tag, MPI_COMM_WORLD));
		mpicxx::vector_recv(&localDispatcher, model_data, MPIx_primitive<uint32_t>,
				source, argument_tag, MPI_COMM_WORLD, MPI_STATUS_IGNORE);

		assert(suite.worldRank == 0);

		std::lock_guard<boost::fibers::mutex> global_lock{sharedData().globalMutex};
		if(sharedData().globalSolveState == SolveState::kStateUnknown) {
			sharedData().globalSolveState = SolveState::kStateSatisfied;

			std::vector<LiteralIdType> model;
			for(auto index : model_data)
				model.push_back(LiteralIdType::fromIndex(index));
			sharedData().model = std::move(model);

			localOffloader->enqueue([this] () {
				for(int wp = 0; wp < suite.worldSize; wp++) {
					assert(commandsAllowed);
					msg::Command command;
					command.opcode = Commands::kCmdTerminateSuite;
					command.peer = 0;
					int command_tag = encodeTag({ 0, kTagCommand });
					mpicxx::single_send(&localDispatcher, command, suite.commandType,
							wp, command_tag, MPI_COMM_WORLD);
				}
			});
		}else{
			assert(sharedData().globalSolveState == SolveState::kStateSatisfied);
		}
	}else if(opcode == Commands::kCmdUnsatisfiable) {
		assert(suite.worldRank == 0);

		std::lock_guard<boost::fibers::mutex> global_lock{sharedData().globalMutex};
		if(sharedData().globalSolveState == SolveState::kStateUnknown) {
			sharedData().globalSolveState = SolveState::kStateUnsatisfiable;

			localOffloader->enqueue([this] () {
				for(int wp = 0; wp < suite.worldSize; wp++) {
					assert(commandsAllowed);
					msg::Command command;
					command.opcode = Commands::kCmdTerminateSuite;
					command.peer = 0;
					int command_tag = encodeTag({ 0, kTagCommand });
					mpicxx::single_send(&localDispatcher, command, suite.commandType,
							wp, command_tag, MPI_COMM_WORLD);
				}
			});
		}else{
			assert(sharedData().globalSolveState == SolveState::kStateUnsatisfiable);
		}
	}else if(opcode == Commands::kCmdTerminateSuite) {
		sharedData().terminateFlag.store(true);

		localOffloader->enqueue([this] {
			auto vertices = sharedData().gatherOwnVertices();
			for(auto vertex : vertices) {
				std::unique_lock<std::mutex> node_guard(vertex->mutex);
				vertex->shutdownWaiters(node_guard);
			}
		});
	}else if(opcode == Commands::kReqQueryBranch) {
		LinkMsgStruct link_msg;
		mpicxx::single_recv(&localDispatcher, link_msg, suite.linkMsgType, source, argument_tag,
				MPI_COMM_WORLD, MPI_STATUS_IGNORE);

		std::unique_lock<std::mutex> guard(sharedData().treeMutex);
		typename SharedDataType::CubeNode *node = sharedData().atNode(guard, link_msg.link);
		guard.unlock();

		// Send the branch information.
		BranchMsgStruct branch;
		branch.numClauses = node->cubeClauses.size();
		mpicxx::single_send(&localDispatcher, branch, suite.branchMsgType,
				source, result_tag, MPI_COMM_WORLD);
		
		std::vector<uint32_t> literal_data;
		for(auto it = node->cubeLiterals.begin(); it != node->cubeLiterals.end(); ++it)
			literal_data.push_back(it->getIndex());

		std::vector<uint32_t> clause_data;
		for(auto cp = node->cubeClauses.begin(); cp != node->cubeClauses.end(); ++cp) {
			// Note that we assume that the clause name fits into 64 bits.
			auto bits = cp->name.bits();
			clause_data.push_back(bits & 0xFFFFFFFF);
			clause_data.push_back(bits >> 32);

			clause_data.push_back(cp->lbd);
		
			for(auto it = cp->literals.begin(); it != cp->literals.end(); ++it)
				clause_data.push_back(it->getIndex() + 1);
			clause_data.push_back(0);
		}

		mpicxx::vector_send(&localDispatcher, literal_data, MPIx_primitive<uint32_t>,
				source, result_tag, MPI_COMM_WORLD);
		mpicxx::vector_send(&localDispatcher, clause_data, MPIx_primitive<uint32_t>,
				source, result_tag, MPI_COMM_WORLD);
	}else throw std::logic_error("Illegal command");
}

// --------------------------------------------------------
// SuiteStruct
// --------------------------------------------------------

static int getWorldRank() {
	int result;
	MPI_Comm_rank(MPI_COMM_WORLD, &result);
	return result;
}
static int getWorldSize() {
	int result;
	MPI_Comm_size(MPI_COMM_WORLD, &result);
	return result;
}

static MPI_Datatype commitWorkerIdType() {
	MPI_Datatype datatype;
	MPI_Type_contiguous(2, MPI_INT, &datatype);
	MPI_Type_commit(&datatype);
	return datatype;
}

template<typename... PT>
SuiteStruct<PT...>::SuiteStruct(int workers_per_node)
: configuredWorkersPerNode(workers_per_node), worldRank(getWorldRank()), worldSize(getWorldSize()),
		workerIdType(commitWorkerIdType()), linkMsgType(LinkMsgStruct::commit()),
		branchMsgType(BranchMsgStruct::commit()), splitValueMsgType(SplitValueMsgStruct::commit()),
		memoryBudget(0), actualWorkersPerNode(0), nextGeneratedId(1), sharedData(this) {
	commandType = msg::Command::commit();

	MPI_Comm_dup(MPI_COMM_WORLD, &seqComm);
	MPI_Comm_dup(MPI_COMM_WORLD, &balanceComm);
	MPI_Comm_dup(MPI_COMM_WORLD, &exchangeComm);
}

template<typename... PT>
void SuiteStruct<PT...>::mergeNode(CubeLink parent_link, CubeLink node_link) {
	typename SharedDataType::CubeNode *node;
	{
		std::unique_lock<std::mutex> guard(sharedData.treeMutex);
		node = sharedData.findNode(guard, node_link);
	}

	if(!node) {
//			std::cout << "c @" << worldRank << " merge (" << node_link.first
//					<< ", " << node_link.second << ")" << std::endl;
		
		// Query branch information from the constructor node.
		assert(commandsAllowed);
		msg::Command command;
		command.opcode = Commands::kReqQueryBranch;
		command.peer = 0;
		int command_tag = encodeTag({ 0, kTagCommand });
		int argument_tag = encodeTag({ 0, kTagCmdArgument });
		int result_tag = encodeTag({ 0, kTagCmdResult });
		mpicxx::single_send(&localDispatcher, command, commandType,
				node_link.first, command_tag, MPI_COMM_WORLD);
		mpicxx::single_send(&localDispatcher, LinkMsgStruct(node_link), linkMsgType,
				node_link.first, argument_tag, MPI_COMM_WORLD);

		// Receive the branch information.
		BranchMsgStruct branch_msg;
		mpicxx::single_recv(&localDispatcher, branch_msg, branchMsgType,
				node_link.first, result_tag, MPI_COMM_WORLD, MPI_STATUS_IGNORE);
		
		// Receive the cube literals and clauses.
		std::vector<LiteralIdType> cube_literals;
		std::vector<typename SharedDataType::CubeClause> cube_clauses;

		std::vector<uint32_t> literal_data;
		std::vector<uint32_t> clause_data;
		literal_data.resize(mpicxx::size_probe(&localDispatcher, MPIx_primitive<uint32_t>,
				node_link.first, result_tag, MPI_COMM_WORLD));
		mpicxx::vector_recv(&localDispatcher, literal_data, MPIx_primitive<uint32_t>,
				node_link.first, result_tag, MPI_COMM_WORLD, MPI_STATUS_IGNORE);
		clause_data.resize(mpicxx::size_probe(&localDispatcher, MPIx_primitive<uint32_t>,
				node_link.first, result_tag, MPI_COMM_WORLD));
		mpicxx::vector_recv(&localDispatcher, clause_data, MPIx_primitive<uint32_t>,
				node_link.first, result_tag, MPI_COMM_WORLD, MPI_STATUS_IGNORE);
		
		for(auto it = literal_data.begin(); it != literal_data.end(); ++it)
			cube_literals.push_back(LiteralIdType::fromIndex(*it));

		for(auto it = clause_data.begin(); it != clause_data.end(); /* no increment */) {
			uint64_t name_low = *it++;
			assert(it != clause_data.end());
			uint64_t name_high = *it++;
			assert(it != clause_data.end());

			auto lbd = *it++;
			assert(it != clause_data.end());

			std::vector<LiteralIdType> lits;
			while(*it != 0) {
				lits.push_back(LiteralIdType::fromIndex(*it++ - 1));
				assert(it != clause_data.end());
			}
			it++;
		
			auto name = ClauseNameType{(name_high << 32) | name_low};
			cube_clauses.push_back(CubeClause{name, std::move(lits), lbd});
		}

		{
			std::unique_lock<std::mutex> guard(sharedData.treeMutex);
			node = new typename SharedDataType::CubeNode(*this, node_link, parent_link,
					std::move(cube_literals), std::move(cube_clauses));
			sharedData.insertNode(guard, node_link, std::unique_ptr<typename SharedDataType::CubeNode>(node));
		}
	}else{
		// verify the information we merged earlier
		assert(node->parentLink == parent_link);
	}
}

template<typename... PT>
SolveState SuiteStruct<PT...>::run(std::string instance) {
	// TODO: Replace this by std::barrier once that is available.
	struct our_barrier {
		our_barrier(int num_threads)
		: _num_threads{num_threads}, _counter{0}, _seq{0} { }

		void wait() {
			std::unique_lock<std::mutex> lock{_mutex};
			assert(_counter < _num_threads);
			auto current = _seq;

			if(++_counter == _num_threads) {
				_counter = 0;
				_seq++;

				_cv.notify_all();
				lock.unlock();
			}else{
				while(_seq == current)
					_cv.wait(lock);
			}
		}

	private:
		const int _num_threads;

		std::mutex _mutex;
		std::condition_variable _cv;
		int _counter;
		int _seq;
	};

	if(minimalOutput && !worldRank)
		std::cout << "c Displaying rank zero output only." << std::endl;

	auto offloader = new OffloaderStruct{};

	std::mutex main_mutex;
	std::condition_variable main_cv;

	our_barrier main_barrier{2};
	std::unique_ptr<boost::fibers::barrier> thread_barrier;
	auto threadMain = [&] (int index) {
		boost::fibers::use_scheduling_algorithm<mpicxx::scheduler>();
		commandsAllowed = false;
		workerPeer = index + 2;
		localDispatcher.run();
		localOffloader = offloader;

		if(setAffinity) {
			cpu_set_t all_cpus;
			if(sched_getaffinity(0, sizeof(cpu_set_t), &all_cpus))
				throw std::runtime_error("sched_getaffinity() failed");

			auto num_cpus = CPU_COUNT(&all_cpus);
			if(num_cpus == configuredWorkersPerNode) {
				cpu_set_t worker_cpus;
				CPU_ZERO(&worker_cpus);
				for(int k = 0, m = 0; k < CPU_SETSIZE; k++) {
					if(!CPU_ISSET(k, &all_cpus))
						continue;
					if(m == index) {
						CPU_SET(k, &worker_cpus);
						break;
					}else{
						m++;
					}
				}
				assert(CPU_COUNT(&worker_cpus) == 1);

				if(sched_setaffinity(0, sizeof(cpu_set_t), &worker_cpus))
					throw std::runtime_error("sched_setaffinity() failed");
			}else{
				std::cout << "c Warning: " << num_cpus << " CPUs are available,"
						" but " << configuredWorkersPerNode << " workers/process were requested!" << std::endl;
			}
		}

		// The worker depends on the thread-local dispatcher so
		// we have to allocate it inside this thread.
		workers[index] = std::make_unique<WorkerType>(*this, index);

		if(!index) {
			// The first worker parses the input instance.
			workers[0]->initialize(instance);

			// The first barrier informs the main thread that parsing completed.
			// The second barrier informs us that we can continue.
			main_barrier.wait();
			main_barrier.wait();
		}else{
			// All other workers clone the preprocessed state from worker zero.
			auto start = sys::ThreadClock::now();
			workers[index]->initialize(&workers[0]->solver);
			auto elapsed = sys::ThreadClock::now() - start;

			if(minimalOutput && !worldRank) {
				std::lock_guard<std::mutex> stdout_lock{globalStdoutMutex};
				std::cout << "c [" << worldRank << ", " << index << "] Cloning took "
						<< std::chrono::duration_cast<std::chrono::milliseconds>(elapsed).count()
						<< " ms" << std::endl;
			}
		}
		thread_barrier->wait();

		ServerType server{*this};
		if(!index)
			server.run();
		if(!index)
			localOffloader->run();

		workers[index]->run();

		// Setup the root node.
		if(!worldRank && !index) {
			auto root_node = new typename SharedDataType::CubeNode(*this,
					std::make_pair(worldRank, nextGeneratedId.fetch_add(1)),
					std::make_pair(kNoRank, kIllegalId), {}, {});
			std::unique_lock<std::mutex> tree_guard(sharedData.treeMutex);
			sharedData.insertNode(tree_guard, root_node->thisLink,
					std::unique_ptr<typename SharedDataType::CubeNode>(root_node));
			tree_guard.unlock();
			
			localOffloader->enqueue([this, root_node] () {
				std::vector<WorkerId> all_workers;
				for(int i = 0; i < worldSize; i++)
					for(int j = 0; j < actualWorkersPerNode; j++)
							all_workers.push_back(WorkerId(i, j));
				
				std::unique_lock<std::mutex> root_guard(root_node->mutex);
				root_node->routeDown(root_guard, std::move(all_workers));
			});
		}

		// Wait until computation terminates, then shutdown everything.
		workers[index]->join();

		// Note that we need to do an awkward tripple-barrier to get true global cross-node barrier.
		// The first barrier synchronizes all local threads, the second synchronizes a single
		// local thread with a single thread on every other node and the third one finally
		// synchronizes all threads on all nodes.

		// Perform a global barrier before shutting down the tasklet fiber.
		// This is required to ensure that all workers receive their termination commands.
		thread_barrier->wait();
		if(!index) {
			MPI_Request req;
			MPI_Ibarrier(MPI_COMM_WORLD, &req);
			auto f = localDispatcher.submit(req, MPI_STATUS_IGNORE);
			f.get();
		}
		thread_barrier->wait();

		// Shut down the tasklet fiber.
		if(!index)
			localOffloader->shutdown();

		// Perform a global barrier before shutting down the server.
		// This is required to ensure that the tasklet fiber does not get stuck.
		thread_barrier->wait();
		if(!index) {
			MPI_Request req;
			MPI_Ibarrier(MPI_COMM_WORLD, &req);
			auto f = localDispatcher.submit(req, MPI_STATUS_IGNORE);
			f.get();
		}
		thread_barrier->wait();

		if(!index) {
			// Send a cancel command to ourselfs.
			msg::Command command;
			command.opcode = Commands::kCmdCancelServer;
			command.peer = 1;
			int command_tag = encodeTag({ 0, kTagCommand });
			mpicxx::single_send(&localDispatcher, command, commandType,
					worldRank, command_tag, MPI_COMM_WORLD);

			server.join();
		}

		localDispatcher.shutdown();
	};

	workers.resize(configuredWorkersPerNode);

	// Start worker zero and wait until it parses the input.
	std::vector<std::thread> threads;
	threads.push_back(std::thread{threadMain, 0});
	main_barrier.wait();

	// TODO: Use std::clamp() in C++17.
	// Use only 1/4 of memory for clauses. 
	assert(memoryBudget);
	size_t clause_memory = workers[0]->solver.clauseSpace.usedSpace();
	actualWorkersPerNode = std::min(std::max(size_t(1), memoryBudget / (clause_memory * 4)),
			size_t(configuredWorkersPerNode));
	if(!worldRank) {
		std::lock_guard<std::mutex> stdout_lock{globalStdoutMutex};
		std::cout << "c Clauses (after preprocessing) consume "
				<< std::fixed << (clause_memory * 100.0 / memoryBudget) << std::defaultfloat
				<< "% of the memory budget per worker; starting " << actualWorkersPerNode << " workers." << std::endl;
	}

	// Finalize the configuration before we allow worker zero to continue.
	thread_barrier = std::make_unique<boost::fibers::barrier>(actualWorkersPerNode);

	// Start threads for the remaining fibers.
	main_barrier.wait();
	for(int i = 1; i < actualWorkersPerNode; i++)
		threads.push_back(std::thread{threadMain, i});

	// Wait for every worker to complete.
	for(auto it = threads.begin(); it != threads.end(); ++it)
		it->join();

	return sharedData.globalSolveState;
}

} } // namespace satuzk::ddc

