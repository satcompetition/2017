
#include <algorithm>
#include <random>
#include <iostream>
#include <iomanip>

namespace satuzk {

enum SolveState {
	kStateUnknown,
	kStateBreak,
	kStateSatisfied,
	kStateUnsatisfiable,
	kStateAssumptionFail
};

} // namespace satuzk

namespace satuzk {
namespace cdcl {

enum class Emulation {
	null,
	native,
	miniSat,
	glucose
};

// Flags that disable expensive debugging checks.
constexpr bool kDbgCheckDeletedVars = false;

template<typename... PT>
struct ClauseNameAllocatorStruct {
	typedef ClauseName<PT...> ClauseNameType;
	typedef Solver<PT...> SolverType;

	ClauseNameAllocatorStruct(SolverType &solver)
	: _solver(&solver) { }

	ClauseNameType allocate() {
		return _solver->uniqueClauseName();
	}

private:
	SolverType *_solver;
};

template<typename... PT>
struct VariableHooksStruct {
	typedef VariableRef<PT...> VariableRefType;
	typedef LiteralRef<PT...> LiteralRefType;
	typedef ClauseRef<PT...> ClauseRefType;
	typedef Solver<PT...> SolverType;

	VariableHooksStruct(SolverType &solver)
	: _solver(&solver) { }
	
	void onResize(size_t num_variables) {
		_solver->assignment.resizeVariables(num_variables);
		_solver->trail.resizeAtoms(num_variables);
		_solver->p_vsidsConfig.resizeVariables(num_variables);
		_solver->occlists.resizeAtoms(2 * num_variables);

		_solver->learnState.onAllocVariable();
	}

	void onAllocate(VariableRefType variable) {
		_solver->p_vsidsConfig.onAllocVariable(variable.id());
	}

	void onErase(VariableRefType variable) {
		// Disable this check by default! Very high performance overhead!
		if(kDbgCheckDeletedVars)
			_solver->clauseSpace.forEach([&] (ClauseRefType clause) {
				if(!clause.isPresent())
					return;
				auto vit = std::find_if(clause.beginLits(), clause.endLits(), [&] (LiteralRefType literal) {
					return literal.variable() == variable;
				});	
				assert(vit == clause.endLits());
			});

		if(_solver->p_vsidsConfig.isInserted(variable.id()))
			_solver->p_vsidsConfig.removeVariable(variable.id());
	}

private:
	SolverType *_solver;
};

template<typename... PT>
struct ClauseHooksStruct {
	typedef ClauseRef<PT...> ClauseRefType;
	typedef Antecedent<PT...> AntecedentType;
	typedef Solver<PT...> SolverType;

	ClauseHooksStruct(SolverType &solver)
	: _solver(&solver) { }

	void onAllocate(ClauseRefType clause) {
		_solver->occlists.addConstraint(clause);
	}

	void onErase(ClauseRefType clause, bool urgent) {
		_solver->occlists.removeConstraint(clause, urgent);

		_solver->stat.general.deletedClauses++;
	}

	void installClause(ClauseRefType clause) {
		if(clause.length() == 0) {
			_solver->_emptyClauses.push_back(clause.id());
		}else if(clause.length() == 1) {
			_solver->_unitClauses.push_back(clause.id());
		}else if(clause.length() == 2) {
			auto lit1 = clause.assertedWatch();
			auto lit2 = clause.triggerWatch();
			_solver->watchInsertBinary(lit1.inverse(), lit2, clause.id());
			_solver->watchInsertBinary(lit2.inverse(), lit1, clause.id());
		}else{
			auto lit1 = clause.assertedWatch();
			auto lit2 = clause.triggerWatch();
			_solver->watchInsertClause(lit1.inverse(), lit2, clause.id());
			_solver->watchInsertClause(lit2.inverse(), lit1, clause.id());
		}
		
		_solver->currentActiveClauses++;
	}

	void uninstallClause(ClauseRefType clause, bool urgent) {
		assert(!_solver->clauseIsAntecedent(clause.id()));
		if(clause.length() == 1) {
			auto it = std::find(_solver->_unitClauses.begin(), _solver->_unitClauses.end(), clause.id());
			assert(it != _solver->_unitClauses.end());
			_solver->_unitClauses.erase(it);
		}else{
			if(urgent) {
				if(clause.length() == 2) {
					auto lit1 = clause.assertedWatch();
					auto lit2 = clause.triggerWatch();
					_solver->watchRemoveBinary(lit1.inverse(), clause.id());
					_solver->watchRemoveBinary(lit2.inverse(), clause.id());
				}else{
					auto lit1 = clause.assertedWatch();
					auto lit2 = clause.triggerWatch();
					_solver->watchRemoveClause(lit1.inverse(), clause.id());
					_solver->watchRemoveClause(lit2.inverse(), clause.id());
				}
			}else{
				_solver->varSpace.markWatchesDirty();
			}
		}

		_solver->currentActiveClauses--;
	}

	template<typename C>
	void onCompact(C *compactor) {
		// Update all watch lists.
		for(auto variable : _solver->varSpace) {
			for(auto it = _solver->varSpace.watchBegin(variable.positive().id());
					it != _solver->varSpace.watchEnd(variable.positive().id()); ++it) {
				ClauseRefType clause{_solver->clauseSpace, it->getClause()};
				assert(clause.isPresent());
				compactor->compact(clause);
				it->setClause(clause.prospectiveId());
			}

			for(auto it = _solver->varSpace.watchBegin(variable.negative().id());
					it != _solver->varSpace.watchEnd(variable.negative().id()); ++it) {
				ClauseRefType clause{_solver->clauseSpace, it->getClause()};
				assert(clause.isPresent());
				compactor->compact(clause);
				it->setClause(clause.prospectiveId());
			}
		}

		// Update all antecedents.
		for(size_t i = 0; i < _solver->trail.trailLength(); i++) {
			auto literal = _solver->trail.atomAt(i);
			auto antecedent = _solver->assignment.antecedent(literal.variable());
			if(antecedent.isInitial())
				continue;

			auto clause = ClauseRefType{_solver->clauseSpace, antecedent.getClause()};
			assert(clause.isPresent());
			compactor->compact(clause);

			if(antecedent.isUnit()) {
				_solver->assignment.updateAntecedent(literal.variable().id(),
						AntecedentType::makeUnit(clause.prospectiveId()));
			}else if(antecedent.isImplication()) {
				_solver->assignment.updateAntecedent(literal.variable().id(),
						AntecedentType::makeImplication(clause.prospectiveId(), antecedent.getImplication()));
			}else{
				assert(antecedent.isClause());
				_solver->assignment.updateAntecedent(literal.variable().id(),
						AntecedentType::makeClause(clause.prospectiveId()));
			}
		}

		// Update all short clauses.
		for(auto it = _solver->_emptyClauses.begin();
				it != _solver->_emptyClauses.end(); ++it) {
			ClauseRefType clause(_solver->clauseSpace, *it);
			assert(clause.isPresent());
			compactor->compact(clause);
			*it = clause.prospectiveId();
		}

		for(auto it = _solver->_unitClauses.begin();
				it != _solver->_unitClauses.end(); ++it) {
			ClauseRefType clause(_solver->clauseSpace, *it);
			assert(clause.isPresent());
			compactor->compact(clause);
			*it = clause.prospectiveId();
		}
		
		_solver->_hooks.onClauseCompaction(compactor);
	}

	void afterCompact() {
		_solver->occlists.rebuild();
		
		_solver->stat.general.clauseCollects++;
	}

private:
	SolverType *_solver;
};

template<typename... PT>
struct TrailHooksStruct {
	typedef LiteralId<PT...> LiteralIdType;
	typedef LiteralRef<PT...> LiteralRefType;
	typedef VariableRef<PT...> VariableRefType;
	typedef ClauseRef<PT...> ClauseRefType;
	typedef Antecedent<PT...> AntecedentType;
	typedef Conflict<PT...> ConflictType;
	typedef DecisionLevel<PT...> DecisionLevelType;
	typedef Solver<PT...> SolverType;

	TrailHooksStruct(SolverType &solver)
	: _solver(&solver) { }

	void onAssign(LiteralRefType literal, AntecedentType antecedent, DecisionLevelType level) {
		VariableRefType var = literal.variable();

		if(kDbgCheckDeletedVars && !var.isPresent()) {
			if(antecedent.isInitial()) {
				assert(!"Deleted variable is assigned by decision");
			}else if(antecedent.isUnit()) {
				assert(!"Deleted variable is assigned by unit");
			}else{
				assert(!"Deleted variable is assigned by non-unit clause");
			}
		}else assert(var.isPresent());

		// this is a costly sanity check
//		if(!antecedent.isInitial())
//			for(auto it = antecedent.begin(*_solver); it != antecedent.end(*_solver); ++it)
//				assert(_solver->assignment.isTrue(*it));

		// setup the antecedent and decision level of the variable
		bool is_one = literal == var.positive();
		_solver->assignment.assign(var.id(), is_one, antecedent, level);
		_solver->currentAssignedVars++;

		// phase saving
		if(is_one) {
			_solver->varSpace.setVarFlagSaved(var.id());
		}else _solver->varSpace.clearVarFlagSaved(var.id());

		/*if(kReportAssign) {
			report<ReportTag>(ReportTag::kAssign);
			report<uint32_t>(literal.getIndex());
		}*/
	}
	void onUnassign(LiteralRefType literal) {
		VariableRefType var = literal.variable();
		_solver->assignment.unassign(var.id());
		_solver->currentAssignedVars--;

		// reinsert the variable into the heap
		if(!_solver->p_vsidsConfig.isInserted(var.id()) && var.isPresent())
			_solver->p_vsidsConfig.insertVariable(var.id());
	}

	DecisionLevelType numInitialLevels() {
		return 1 + _solver->_assumptionList.size();
	}

	ConflictType initializeLevel(DecisionLevelType level) {
		// We assign all unit literals on level zero.
		if(!level) {
			if(!_solver->_emptyClauses.empty())
				return ConflictType::makeClause(_solver->_emptyClauses.front());

			for(auto it = _solver->_unitClauses.begin(); it != _solver->_unitClauses.end(); ++it) {
				LiteralRefType unit = *ClauseRefType(_solver->clauseSpace, *it).beginLits();
				if(_solver->assignment.isTrue(unit.id()))
					continue;
				if(_solver->assignment.isFalse(unit.id()))
					return ConflictType::makeUnit(unit.id());
				_solver->trail.enqueue(unit, AntecedentType::makeUnit(*it));
			}
		}else{
			// We assign all assumptions on the following decision level.
			// We assign each assumption on a different level. While this implies
			// greater overhead it also improves antecedent and LBD accuracy.
			assert(level <= _solver->_assumptionList.size());

			auto assumption = _solver->_assumptionList[level - 1];
			if(_solver->assignment.isFalse(assumption))
				return ConflictType::makeUnit(assumption);
			if(!_solver->assignment.isAssigned(assumption.variable()))
				_solver->trail.enqueue(assumption, AntecedentType::makeInitial());
		}
		
		return ConflictType{};
	}

	template<typename PropagationFilter>
	ConflictType propagate(LiteralIdType literal, PropagationFilter f) {
		return PropagationStruct<PT...>::propagateWatch(*_solver, literal, f);
	}

private:
	SolverType *_solver;
};

template<typename... PT>
class SolverStruct {
public:
	typedef LiteralId<PT...> LiteralIdType;
	typedef VariableId<PT...> VariableIdType;
	typedef ClauseId<PT...> ClauseIdType;
	
	typedef LiteralRef<PT...> LiteralRefType;
	typedef ClauseRef<PT...> ClauseRefType;

	typedef VariableRef<PT...> VariableRefType;
	typedef ClauseName<PT...> ClauseNameType;

	typedef ClauseSize<PT...> ClauseSizeType;
	typedef TrailIndex<PT...> TrailIndexType;
	typedef Activity<PT...> ActivityType;
	typedef DecisionLevel<PT...> DecisionLevelType;

	static const int kClauseAlignment = 8;

	typedef Antecedent<PT...> AntecedentType;
	typedef Conflict<PT...> ConflictType;

public:
	typedef VariableSpace<PT...> VariableSpaceType;
	typedef ClauseSpace<PT...> ClauseSpaceType;
	
	typedef satutils::Occlists<
		satutils::UseAtom<LiteralIdType>,
		satutils::UseConstraintId<ClauseIdType>,
		satutils::UseConstraintRef<ClauseRefType>,
		satutils::UseConstraintSpace<ClauseSpaceType>
	> OcclistsType;

	typedef uint64_t ClauseSignature;

	typedef Hooks_<PT...> HooksType;
	typedef Assignment<PT...> AssignmentType;
	typedef Trail<PT...> TrailType;
	typedef LearnState<PT...> LearnStateType;
	typedef VsidsState<PT...> VsidsStateType;
	typedef EliminationStack<PT...> EliminationStackType;

public:
	typedef typename VariableSpaceType::WatchIterator WatchIterator;
	typedef typename VariableSpaceType::WatchlistEntry WatchlistEntry;

public:
	SolverStruct(HooksType hooks, int config_id);

	int getConfigId() { return p_configId; }

	auto uniqueClauseName() {
		return typename ClauseSpaceType::ClauseNameType(uint16_t(p_configId), _localClauseName++);
	}

	void seedRandomEngine(unsigned long seed) {
		std::cout << "c random seed: 0x" << std::hex << seed << std::dec << std::endl;
		p_rndEngine.seed(seed);
	}
	
	/* ---------------- VARIABLE MANAGEMENT FUNCTIONS ---------------------- */
	// reserves space for variables; does not allocate them!
	void varReserve(LiteralIndex<PT...> count);

	// allocates a single variable
	void undeleteVar(VariableIdType var);

	unsigned int numVariables() {
		return varSpace.count();
	}
	
	// initializes the VSIDS heuristic
	void randomizeVsids();

	bool varIsPresent(VariableIdType var);

	// locked variables must not be removed from clauses
	// and must not be eliminated
	void lockVariable(VariableIdType var);
	void unlockVariable(VariableIdType var);
	bool varIsLocked(VariableIdType var);
	
	Bool3 varState(VariableIdType var) {
		if(!varAssigned(var))
			return undefined3();
		return (varOne(var) ? true3() : false3());
	}
	bool varAssigned(VariableIdType var) {
		return assignment.isAssigned(var);
	}
	
	Bool3 litState(LiteralIdType lit) {
		return varState(lit.variable()) ^ !lit.isOneLiteral();
	}

	AntecedentType varAntecedent(VariableIdType var) {
		return assignment.antecedent(var);
	}
	DecisionLevelType varDeclevel(VariableIdType var) {
		return assignment.level(var);
	}
	// returns true if this variable is fixed by a unit clause
	//FIXME: why do we need this?
	bool varIsFixed(VariableIdType var);

	ActivityType varGetActivity(VariableIdType var) {
		return p_vsidsConfig.getActivity(var);
	}

	/* ----------------- CLAUSE MANAGEMENT FUNCTIONS ----------------------- */

	unsigned int usedClauseSpace() {
		return clauseSpace.usedSpace();
	}

	ClauseSizeType clauseLength(ClauseIdType clause);
	
	std::string printClause(ClauseIdType clause) {
		std::string string = "{";
		for(auto i = clauseBegin(clause); i != clauseEnd(clause); ++i) {
			if(i != clauseBegin(clause))
				string += ", ";
			string += std::to_string((*i).toNumber());
		}
		string += "}";
		return string;
	}

	void markClause(ClauseIdType clause);
	void unmarkClause(ClauseIdType clause);
	bool clauseIsMarked(ClauseIdType clause);
	
	/* returns true if the clause is currently unit or unsatisfied.
	 * only returns a valid result after propagation is done */
	// FIXME: do we need this?
	bool clauseAssigned(ClauseIdType clause);
	// returns true if the clause is currently the antecedent of a variable
	bool clauseIsAntecedent(ClauseIdType clause);
	
	unsigned int clauseGetLbd(ClauseIdType clause) {
		return clauseSpace.clauseGetLbd(clause);
	}
	
	ClauseSignature clauseGetSignature(ClauseIdType clause) {
		return clauseSpace.clauseGetSignature(clause);
	}
	void clauseSetSignature(ClauseIdType clause, ClauseSignature signature) {
		clauseSpace.clauseSetSignature(clause, signature);
	}

	bool clauseWasErased(ClauseIdType clause) {
		return clauseSpace.wasErased(clause);
	}
	bool clauseWasMoved(ClauseIdType clause) {
		return clauseSpace.wasMoved(clause);
	}
	ClauseIdType clauseMoveDestination(ClauseIdType clause) {
		return clauseSpace.getMoveDestination(clause);
	}

	// removes all learned (i.e. not essential) clauses
	void expellLearned();
	// removes all clauses containing the specified literal
	void expellContaining(LiteralRefType lit);

	/* -------------- WATCH LIST / OCCLIST FUNCTIONS ----------------------- */

	WatchIterator watchBegin(LiteralIdType literal) {
		return varSpace.watchBegin(literal);
	}
	WatchIterator watchEnd(LiteralIdType literal) {
		return varSpace.watchEnd(literal);
	}
	void watchCut(LiteralIdType literal, WatchIterator iterator) {
		return varSpace.watchCut(literal, iterator);
	}
	
	// helper functions to manipulate watch lists
	void watchInsertClause(LiteralIdType literal, LiteralIdType blocking, ClauseIdType clause);
	void watchInsertBinary(LiteralIdType literal, LiteralIdType implied, ClauseIdType clause);
	
	// helper functions to manipulate watch lists
	void watchRemoveClause(LiteralIdType literal, ClauseIdType clause);
	void watchRemoveBinary(LiteralIdType literal, ClauseIdType clause);
	
	void watchReplaceClause(LiteralIdType literal, ClauseIdType clause, ClauseIdType replacement);
	void watchReplaceBinary(LiteralIdType literal, ClauseIdType clause, ClauseIdType replacement);
	//TODO: do we need this?
	bool watchContainsBinary(LiteralIdType literal, LiteralIdType implied);

	/* ------------------- ASSIGN / UNASSIGN FUNCTIONS --------------------- */
	
	// restarts the search from scratch
	void restart();
	
	void checkRestart();
	
	/* ------------------------ HEURISTIC FUNCTIONS ---------------------------- */
	void resetBaseHeuristics();
	void resetInputHeuristics();

	/* --------------- CLAUSE REDUCTIONS FUNCTIONS ------------------------- */

	int calculatePsm(ClauseRefType clause);

	// deletes clauses in order to decrease the number of learned clauses
	void reduceClauses();

	// checks if clause reduction should be done
	void checkClauseReduction();

	/* ------------------ DECISION FUNCTIONS ------------------------------- */
	
	// decides which variable should be assigned next and assigns the variable.
	// returns false if all no decision could be taken (i.e. the solver is in a satisfied state)
	bool decide();

	// helper functions to rescale activity in order to prevent overflows
	void scaleVarActivity(ActivityType divisor);
	void scaleClauseActivity(ActivityType divisor);
	
	// update activity heuristics
	void onVarActivity(VariableIdType var);
	void onAntecedentActivity(AntecedentType antecedent);

	void recomputeLbd(ClauseIdType id);

	void increaseActivity();

	/* ------------------ CONFLICT MANAGEMENT ------------------------------ */

	bool isResolveable() {
		assert(trail.conflict());
		return trail.currentLevel() >= 1 + _assumptionList.size();
	}
	bool isFailedAssumption() {
		assert(trail.conflict());
		return trail.currentLevel() && trail.currentLevel() < 1 + _assumptionList.size();
	}
	bool isUnsatisfiable() {
		assert(trail.conflict());
		return !trail.currentLevel();
	}
	
	// Resolves the conflict.
	void resolveConflict();

	// Resolves a conflict by backjump via a learned clause.
	// Assumes that the second literal determines the backjump level.
	template<typename Iterator>
	void resolveToLearn(ClauseSizeType size, Iterator begin, Iterator end);

	// Enqueues the literal that is asserted by a learned clause.
	// Assumes that the first literal is asserted by the clause.
	void enqueueAfterLearning(ClauseRefType learned);

	/* --------------------- ASSUMPTION FUNCTIONS -------------------------- */
	void assumptionEnable(LiteralIdType literal);
	void assumptionDisable(LiteralIdType literal);
	bool isAssumed(LiteralIdType literal);
	
	/* -------- HELPER FUNCTIONS: LBD CALCULATION -------------------------- */
	std::vector<bool> lbd_buffer;
	int lbd_counter;
	
	void lbdInit() {
		if(lbd_buffer.size() < trail.currentLevel() + 1)
			lbd_buffer.resize(trail.currentLevel() + 1, false);
		lbd_counter = 0;
	}
	void lbdInsert(DecisionLevelType declevel) {
		assert(declevel < lbd_buffer.size());
		if(lbd_buffer[declevel])
			return;
		lbd_buffer[declevel] = true;
		lbd_counter++;
	}
	void lbdCleanup(DecisionLevelType declevel) {
		lbd_buffer[declevel] = false;
	}
	int lbdResult() {
		if(lbd_counter > UINT16_MAX)
			return UINT16_MAX;
		return lbd_counter;
	}

public:
	HooksType _hooks;

	int p_configId;	

	VariableSpaceType varSpace;
	ClauseSpaceType clauseSpace;

	uint64_t _localClauseName;

	satutils::Occlists<
		satutils::UseAtom<LiteralIdType>,
		satutils::UseConstraintId<ClauseIdType>,
		satutils::UseConstraintRef<ClauseRefType>,
		satutils::UseConstraintSpace<ClauseSpaceType>
	> occlists;
	
	// stores all empty clauses
	std::vector<ClauseIdType> _emptyClauses;
	// stores all unit clauses
	std::vector<ClauseIdType> _unitClauses;
	// stores all active assumptions
	std::vector<LiteralIdType> _assumptionList;

	AssignmentType assignment;
	TrailType trail;
	LearnStateType learnState;
	VsidsStateType p_vsidsConfig;
	EliminationStackType eliminationStack;

	std::mt19937 p_rndEngine;
	
	// number of variables currently assigned. used to determine if the instance is sat
	LiteralIndex<PT...> currentAssignedVars;
	// number of currently active clauses. used for clause reduction heuristics
	uint32_t currentActiveClauses;

	sys::Reporter p_reporter;

	const bool kReportEnable = false;
	const bool kReportAssign = false, kReportSample = false, kReportReducerSample = false;

	enum class ReportTag : uint16_t {
		kNone, kAssign, kConflict, kSample, kReducerSample
	};

	template<typename T>
	void report(const T &data) {
		if(kReportEnable)
			p_reporter.write(data);
	}

	enum ClauseRedModel {
		kClauseRedNull,
		kClauseRedAgile,
		kClauseRedGeometric
	};
	
	enum RestartStrategy {
		kRestartLuby,
		kRestartGlucose
	};

	Emulation emulation;

	struct {
		struct StatGeneral {
			uint32_t clauseCollects;
			uint64_t deletedClauses;
			
			StatGeneral() :
				clauseCollects(0),
				deletedClauses(0) { }
		} general;

		struct StatSearch {
			uint32_t factElimRuns;
			uint64_t factElimClauses;
			uint64_t factElimLiterals;
			
			uint64_t learnedLits, learnedUnits, learnedBinary;
			uint64_t minimizedLits;
			uint32_t restarts;
			sys::HptCounter prop_time;
			
			StatSearch() :
				factElimRuns(0),
				factElimClauses(0),
				factElimLiterals(0),
					
				learnedLits(0), learnedUnits(0), learnedBinary(0),
				minimizedLits(0),
				restarts(0),
				prop_time(0) { }
		} search;

		struct StatClauseRed {
			uint64_t clausesActive, clausesNotActive, clausesConsidered;
			uint64_t clauseDeletions, clauseFreezes, clauseUnfreezes;
			uint32_t reductionRuns;
			
			StatClauseRed() : clausesActive(0), clausesNotActive(0), clausesConsidered(0),
				clauseDeletions(0), clauseFreezes(0), clauseUnfreezes(0),
				reductionRuns(0) { }
		} clauseRed;

		struct StatSimp {
			simplify::BveStats bve;
			//FIXME BceStats bce;
			uint64_t bvaNewVars, bvaRemovedClauses;
			uint64_t sccVariables;
			//FIXME SubsumeStats subsume, inprocSubsume;
			uint64_t distChecks;
			uint64_t distConflicts;
			uint64_t distConflictsRemoved;
			uint64_t distAsserts;
			uint64_t distAssertsRemoved;
			uint64_t distSelfSubs;
			uint64_t distSelfSubsRemoved;
			uint64_t hbNewClauses;
			//FIXME UnhideStats unhide;

			StatSimp() :
				bvaNewVars(0), bvaRemovedClauses(0),
				sccVariables(0),
				distChecks(0),
				distConflicts(0), distConflictsRemoved(0), distAsserts(0), distAssertsRemoved(0),
					distSelfSubs(0), distSelfSubsRemoved(0),
				hbNewClauses(0) { }
		} simp;
	} stat;

	struct StatPerf {
		sys::HptCounter preprocTime;
		sys::HptCounter inprocTime;
		uint64_t searchWatchVisitOps, searchClauseVisitOps;
		sys::HptCounter searchTime;
		uint64_t bvaOps; sys::HptCounter bvaTime;
		
		StatPerf() : preprocTime(0), inprocTime(0),
				searchWatchVisitOps(0), searchClauseVisitOps(0), searchTime(0),
				bvaOps(0), bvaTime(0) { }
	} perf;

	struct Opts {
		struct OptsGeneral {
			int verbose;

			sys::HptCounter budget;
			sys::HptCounter timeout;
			
			OptsGeneral()
			: verbose(0), budget(0), timeout(0) { }
		} general;

		struct OptsLearn {
			bool updateLbd;

			bool bumpGlueTwice;
			bool minimizeGlucose;
			
			OptsLearn()
			: updateLbd(false),
					bumpGlueTwice(false),
					minimizeGlucose(false) { }
		} learn;

		struct OptsClauseRed {
			ClauseRedModel model;

			// initial learned clauses limit
			uint32_t agileBaseInterval;
			// linear slowdown of the clause limit
			uint32_t agileSlowdown;

			// Increase the interval between clause reductions if there are many clauses with low LBD.
			bool agileRaiseOnGoodClauses;
			uint64_t agileRaiseCount;

			// growth factor for geomSizeLimit
			double geomSizeFactor;
			// growth factor for geomIncLimit
			double geomIncFactor;

			// Never delete clauses with LBD <= this value.
			unsigned int permanentLbd;

			// Freeze even clauses that are not important.
			// MiniSAT and Glucose do not use this.
			bool freezeUnimportant;
			
			OptsClauseRed() : model(kClauseRedAgile),
					agileBaseInterval(500), agileSlowdown(100),
					agileRaiseOnGoodClauses(false),
					geomSizeFactor(1.1f), geomIncFactor(1.1f),
					permanentLbd(0), freezeUnimportant(true) { }
		} clauseRed;

		struct OptsRestart {
			RestartStrategy strategy;
			uint32_t lubyScale;
			static const unsigned int glucoseShortInterval = 100;

			OptsRestart() : strategy(kRestartLuby), lubyScale(100) { }
		} restart;
	} opts;

	struct {
		struct {
			sys::HptCounter startTime;
			volatile bool stopSolve;
		} general;

		struct StateSearch {
			// increment that is added to the score on each activity
			ActivityType varActInc;
			// the increment is multiplies by this factor each conflict 
			ActivityType varActFactor;

			// see the corresponding varAct... variables
			ActivityType clauseActInc;
			ActivityType clauseActFactor;
			
			StateSearch() : varActInc(1.0f), varActFactor(1.05f),
					clauseActInc(1.0f), clauseActFactor(1.05f) { }
		} search;

		struct StateClauseRed {	
			// Next conflict at which we will reduce clauses.
			uint64_t nextReductionConflict;

			// number of conflicts between two reduce runs
			uint64_t agileInterval;
			
			// current learned clauses limit
			uint64_t geomSizeLimit;
			// number of conflicts since last increment
			uint64_t geomIncCounter;
			// number of conflicts before next increment
			uint64_t geomIncLimit;

			// number of clause reductions so far
			uint32_t numClauseReds;

			StateClauseRed() : numClauseReds(0) { }
		} clauseRed;

		struct RestartState {
			struct ma_queue {
				ma_queue()
				: _p{0}, _fill{0}, _sum{0} { }

				void set_window(size_t window) {
					_data.resize(window, 0);
				}

				bool valid() {
					return _fill == _data.size();
				}

				void push_back(int v) {
					assert(!_data.empty());

					if(_fill == _data.size()) {
						_sum -= _data[_p];
					}else{
						assert(_fill < _data.size());
						_fill++;
					}

					_data[_p] = v;
					_sum += v;

					if(++_p == _data.size())
						_p = 0;
				}

				void clear() {
					_fill = 0;
					_sum = 0;
				}


				double avg() {
					assert(_fill);
					return static_cast<double>(_sum) / _fill;
				}

			private:
				std::vector<int> _data;
				size_t _p;
				size_t _fill;
				int _sum;
			};

			RestartState()
			: historicLbdSum{0}, historicCounter{0} { }

			uint32_t lubyCounter;
			uint32_t lubyPeriod;

			ma_queue recentLbds;
			uint64_t historicLbdSum;
			uint64_t historicCounter;
		} restart;

		struct {
			DecisionLevelType lastConflictDeclevel;
		} conflict;
	} state;
};

} } // namespace satuzk::cdcl

