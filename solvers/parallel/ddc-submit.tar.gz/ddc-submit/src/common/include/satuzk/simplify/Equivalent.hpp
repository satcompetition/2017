
namespace satuzk {

template<typename Defs>
class EquivConfigStruct {
public:
	typedef LiteralType<Defs> Literal;
	typedef VariableType<Defs> Variable;
	typedef LiteralIndexType<Defs> LiteralIndex;

	void initialize(Solver<Defs> &solver) {
		p_oneEquivPointer.clear();
		for(auto it = solver.varsBegin(); it != solver.varsEnd(); ++it)
			p_oneEquivPointer.push_back((*it).oneLiteral());
	}
	
	Literal getPointer(Literal literal) {
		if(literal.isOneLiteral()) {
			return p_oneEquivPointer[literal.variable().getIndex()];
		}else{
			return p_oneEquivPointer[literal.variable().getIndex()].inverse();
		}
	}
	void setPointer(Literal literal, Literal pointed) {
		if(literal.isOneLiteral()) {
			p_oneEquivPointer[literal.variable().getIndex()] = pointed;
		}else{
			p_oneEquivPointer[literal.variable().getIndex()] = pointed.inverse();
		}
	}

	Literal getRoot(Literal literal) {
		Literal root = literal;
		while(getPointer(root) != root)
			root = getPointer(root);

		// path compression
		Literal current = literal;
		while(getPointer(current) != root) {
			Literal parent = getPointer(current);
			setPointer(current, root);
			current = parent;
		}

		return root;
	}
	
	void joinRoots(Literal root1, Literal root2) {
		assert(getRoot(root1) == root1);
		assert(getRoot(root2) == root2);
		assert(root1 != root2);
		assert(root1 != root2.inverse());
		
		// NOTE: no union-by-size for now: the literal with smaller index becomes root
		// this makes sure the root of any literal and its inverse always match
		if(root1.getIndex() < root2.getIndex()) {
			setPointer(root2, root1);
		}else setPointer(root1, root2);
	}

	void resetEquivalent(Variable variable) {
		p_oneEquivPointer[variable.getIndex()] = variable.oneLiteral();
	}

	void replaceClause(Solver<Defs> &hooks, ClauseType<Defs> clause);
	void replaceAll(Solver<Defs> &hooks);

private:
	std::vector<Literal> p_oneEquivPointer;
};

} // namespace satuzk

