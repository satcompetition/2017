
namespace satuzk {
namespace cdcl {

template<typename... PT>
struct ProofHandler {
	using ClauseRefType = ClauseRef<PT...>;
	using SolverType = Solver<PT...>;

	ProofHandler(SolverType *solver)
	: _solver{solver} { }

	void emit(ClauseRefType clause) {
		_solver->_hooks.emitProof(clause);
	}
	void reduce(ClauseRefType clause) {
		_solver->_hooks.reduceProof(clause);
	}

private:
	SolverType *_solver;
};

template<typename... PT>
struct Preprocessor {
	using SolverType = Solver<PT...>;
	
	using SimplificationTrackerType = SimplificationTracker<PT...>;

	using UnitEliminationType = UnitElimination<PT...>;
	using UnhidingType = Unhiding<PT...>;
	
	using SubsumptionType = simplify::Subsumption<
		simplify::UseClauseNameAllocator<ClauseNameAllocator<PT...>>,
		simplify::UseVariableSpace<VariableSpace<PT...>>,
		simplify::UseClauseSpace<ClauseSpace<PT...>>,
		simplify::UseOcclists<typename SolverType::OcclistsType>,
		simplify::UseProofHandler<ProofHandler<PT...>>,
		simplify::UseSimplificationTracker<SimplificationTracker<PT...>>
	>;

	using VarElimType = simplify::VarElim<
		simplify::UseClauseNameAllocator<ClauseNameAllocator<PT...>>,
		simplify::UseVariableSpace<VariableSpace<PT...>>,
		simplify::UseClauseSpace<ClauseSpace<PT...>>,
		simplify::UseOcclists<typename SolverType::OcclistsType>,
		simplify::UseEliminationStack<EliminationStack<PT...>>,
		simplify::UseProofHandler<ProofHandler<PT...>>
	>;

	Preprocessor(SolverType *solver)
	: _solver{solver}, _nameAllocator{*_solver}, _tracker{&_solver->clauseSpace},
			_unhiding{_solver, &_solver->varSpace, &_solver->clauseSpace},
			_subsumption{&_solver->clauseSpace, &_solver->occlists,
					&_nameAllocator, ProofHandler<PT...>{_solver}, &_tracker},
			_varElimination{&_solver->eliminationStack, ProofHandler<PT...>{_solver}},
			verbose{false} { }

	void run() {
		auto run_start = sys::hptCurrent();

		_initiate();
		while(_iterate()) {
			// Run preprocessing until we reach a fix point.
		}

		_solver->perf.preprocTime += sys::hptElapsed(run_start);
	}

private:
	void _initiate() {
		UnitElimStats ue_stats;
		UnhideStats unhide_stats;
		simplify::BceStats bce_stats;
		SubsumeStats sub_stats;
		SubsumeStats rsub_stats;
		simplify::BveStats bve_stats;

		if(verbose)
			std::cout << "c Initial preprocessing pass." << std::endl;

		UnitEliminationType::perform(_solver, ue_stats);
		if(verbose)
			std::cout << "c     UE eliminated " << ue_stats.elimClauses << " clauses"
					", strengthened " << ue_stats.strengthenedClauses << " clauses in "
					<< std::chrono::duration_cast<std::chrono::milliseconds>(ue_stats.time).count()
					<< " ms" << std::endl;

		assert(_solver->trail.isReset());

		for(int i = 0; i < 5; i++)
			_unhiding.processAll(unhide_stats);
		if(verbose)
			std::cout << "c     Unhiding eliminated " << unhide_stats.transitiveEdges << " transitive edges"
					<< ", " << unhide_stats.hteClauses << " HTs"
					<< ", " << unhide_stats.hleLiterals << " HLs in "  << unhide_stats.hleClauses << " clauses"
					<< ", found " << unhide_stats.failedLiterals << " failed literals in "
					<< std::chrono::duration_cast<std::chrono::milliseconds>(unhide_stats.time).count()
					<< " ms" << std::endl;

		_varElimination.bceAll(_tracker, _solver->clauseSpace.reducible().begin(),
				_solver->clauseSpace.reducible().end(), _solver->occlists, bce_stats);
		_varElimination.bceAll(_tracker, _solver->clauseSpace.permanent().begin(),
				_solver->clauseSpace.permanent().end(), _solver->occlists, bce_stats);
		if(verbose)
			std::cout << "c     BCE eliminated " << bce_stats.elimClauses << " clauses in "
					<< std::chrono::duration_cast<std::chrono::milliseconds>(bce_stats.time).count()
					<< " ms" << std::endl;
		_checkCompact();

		_subsumption.backwardSubsumeAll(_solver->clauseSpace.reducible().begin(),
				_solver->clauseSpace.reducible().end(), sub_stats);
		_subsumption.backwardSubsumeAll(_solver->clauseSpace.permanent().begin(),
				_solver->clauseSpace.permanent().end(), sub_stats);
		if(verbose)
			std::cout << "c     Backward subsumption eliminated " << sub_stats.subClauses << " clauses in "
					<< std::chrono::duration_cast<std::chrono::milliseconds>(sub_stats.time).count()
					<< " ms" << std::endl;
		_checkCompact();

		_subsumption.backwardResolveAll(_solver->clauseSpace.reducible().begin(),
				_solver->clauseSpace.reducible().end(), rsub_stats);
		_subsumption.backwardResolveAll(_solver->clauseSpace.permanent().begin(),
				_solver->clauseSpace.permanent().end(), rsub_stats);
		if(verbose)
			std::cout << "c     Backward resolution subsumption resolved "
					<< rsub_stats.resClauses << " clauses in "
					<< std::chrono::duration_cast<std::chrono::milliseconds>(rsub_stats.time).count()
					<< " ms" << std::endl;
		_checkCompact();

		_varElimination.processAll(_tracker, _solver->varSpace, _solver->clauseSpace, _solver->occlists,
				_nameAllocator, bve_stats);
		if(verbose)
			std::cout << "c     BVE eliminated " << bve_stats.elimVars << " variables in "
					<< std::chrono::duration_cast<std::chrono::milliseconds>(bve_stats.time).count()
					<< " ms" << std::endl;
		_checkCompact();

		// We need to clean the watch lists before performing unit elimination in the next round.
		_solver->varSpace.cleanWatches(&_solver->clauseSpace);
	}

	bool _iterate() {
		UnitElimStats ue_stats;
		UnhideStats unhide_stats;
		simplify::BceStats bce_stats;
		simplify::BveStats bve_stats;

		_tracker.gather();
		if(!_tracker.numVars() && !_tracker.numNewClauses() && !_tracker.numStrengthened())
			return false;
		if(verbose)
			std::cout << "c Preprocessing pass: " << _tracker.numVars() << " touched variables, "
					<< _tracker.numNewClauses() << " new clauses, "
					<< _tracker.numStrengthened() << " strengthened clauses. " << std::endl;

		UnitEliminationType::perform(_solver, ue_stats);
		if(verbose)
			std::cout << "c     UE eliminated " << ue_stats.elimClauses << " clauses"
					", strengthened " << ue_stats.strengthenedClauses << " clauses in "
					<< std::chrono::duration_cast<std::chrono::milliseconds>(ue_stats.time).count()
					<< " ms" << std::endl;

		assert(_solver->trail.isReset());

		for(int i = 0; i < 5; i++)
			_unhiding.processAll(unhide_stats);
		if(verbose)
			std::cout << "c     Unhiding eliminated " << unhide_stats.transitiveEdges << " transitive edges"
					<< ", " << unhide_stats.hteClauses << " HTs"
					<< ", " << unhide_stats.hleLiterals << " HLs in "  << unhide_stats.hleClauses << " clauses"
					<< ", found " << unhide_stats.failedLiterals << " failed literals in "
					<< std::chrono::duration_cast<std::chrono::milliseconds>(unhide_stats.time).count()
					<< " ms" << std::endl;

		if(_tracker.numNewClauses()) {
			SubsumeStats back_sub_stats;
			SubsumeStats rsub_stats;
			SubsumeStats fwd_sub_stats;

			_varElimination.bceAll(_tracker, _tracker.beginNewClauses(), _tracker.endNewClauses(),
					_solver->occlists, bce_stats);
			if(verbose)
				std::cout << "c     BCE eliminated " << bce_stats.elimClauses << " clauses in "
						<< std::chrono::duration_cast<std::chrono::milliseconds>(bce_stats.time).count()
						<< " ms" << std::endl;
			_checkCompact();

			_subsumption.backwardSubsumeAll(_tracker.beginNewClauses(), _tracker.endNewClauses(), back_sub_stats);
			if(verbose)
				std::cout << "c     Backward subsumption (new clauses) eliminated " << back_sub_stats.subClauses << " clauses in "
						<< std::chrono::duration_cast<std::chrono::milliseconds>(back_sub_stats.time).count()
						<< " ms" << std::endl;
			_checkCompact();

			_subsumption.backwardResolveAll(_tracker.beginNewClauses(), _tracker.endNewClauses(), rsub_stats);
			if(verbose)
				std::cout << "c     Backward resolution subsumption (new clauses) resolved "
						<< rsub_stats.resClauses << " clauses in "
						<< std::chrono::duration_cast<std::chrono::milliseconds>(rsub_stats.time).count()
						<< " ms" << std::endl;
			_checkCompact();

			_subsumption.forwardSubsumeAll(_tracker.beginNewClauses(), _tracker.endNewClauses(), fwd_sub_stats);
			if(verbose)
				std::cout << "c     Forward subsumption (new clauses) eliminated " << fwd_sub_stats.subClauses << " clauses in "
						<< std::chrono::duration_cast<std::chrono::milliseconds>(fwd_sub_stats.time).count()
						<< " ms" << std::endl;
			_checkCompact();
		}

		if(_tracker.numStrengthened()) {
			SubsumeStats sub_stats;
			SubsumeStats rsub_stats;

			_subsumption.backwardSubsumeAll(_tracker.beginStrengthened(), _tracker.endStrengthened(), sub_stats);
			if(verbose)
				std::cout << "c     Backward subsumption (strengthened clauses) eliminated " << sub_stats.subClauses << " clauses in "
						<< std::chrono::duration_cast<std::chrono::milliseconds>(sub_stats.time).count()
						<< " ms" << std::endl;
			_checkCompact();

			_subsumption.backwardResolveAll(_tracker.beginStrengthened(), _tracker.endStrengthened(), rsub_stats);
			if(verbose)
				std::cout << "c     Backward resolution subsumption (strengthened clauses) resolved "
						<< rsub_stats.resClauses << " clauses in "
						<< std::chrono::duration_cast<std::chrono::milliseconds>(rsub_stats.time).count()
						<< " ms" << std::endl;
			_checkCompact();
		}

		if(_tracker.numVars()) {
			_varElimination.processQueue(_tracker, _solver->clauseSpace, _solver->occlists,
					_nameAllocator, bve_stats);
			if(verbose)
				std::cout << "c     BVE eliminated " << bve_stats.elimVars << " variables in "
						<< std::chrono::duration_cast<std::chrono::milliseconds>(bve_stats.time).count()
						<< " ms" << std::endl;
			_checkCompact();
		}

		// We need to clean the watch lists before performing unit elimination in the next round.
		_solver->varSpace.cleanWatches(&_solver->clauseSpace);
		return true;
	}

private:
	void _checkCompact() {
		if(!_solver->clauseSpace.wantClauseCompaction())
			return;

		_solver->varSpace.cleanWatches(&_solver->clauseSpace);

		auto compactor = _solver->clauseSpace.grabCompactor();
		_tracker.onClauseCompaction(&compactor);
		compactor.commit();
	}

	SolverType *_solver;

	ClauseNameAllocator<PT...> _nameAllocator;
	SimplificationTrackerType _tracker;
	UnitEliminationType _unitElimination;
	UnhidingType _unhiding;
	SubsumptionType _subsumption;
	VarElimType _varElimination;

public:
	bool verbose;
};

// This inprocessor does not try to be efficient.
// It should be run when there is nothing better to do (e.g. when a parallel
// solver instance is idle).
template<typename... PT>
struct ThoroughInprocessor {
	using SolverType = Solver<PT...>;
	using VariableRefType = VariableRef<PT...>;
	using ClauseIdType = ClauseId<PT...>;
	using ClauseRefType = ClauseRef<PT...>;

	struct NullSimplificationTracker {
		void touch(VariableRefType) { }
		void markNewClause(ClauseRefType) { }
		void markStrengthened(ClauseRefType) { }
	};
	
	using SubsumptionType = simplify::Subsumption<
		simplify::UseClauseNameAllocator<ClauseNameAllocator<PT...>>,
		simplify::UseVariableSpace<VariableSpace<PT...>>,
		simplify::UseClauseSpace<ClauseSpace<PT...>>,
		simplify::UseOcclists<typename SolverType::OcclistsType>,
		simplify::UseProofHandler<ProofHandler<PT...>>,
		simplify::UseSimplificationTracker<NullSimplificationTracker>
	>;

	ThoroughInprocessor(SolverType *solver)
	: _solver{solver}, _nameAllocator{*_solver},
			_subsumption{&_solver->clauseSpace, &_solver->occlists,
					&_nameAllocator, ProofHandler<PT...>{_solver}, &_tracker} { }

	void step() {
		assert(_solver->trail.isReset());

		if(_clauseQueue.empty()) {
			_solver->clauseSpace.forEach([&] (ClauseRefType clause) {
				if(clause.isPresent())
					_clauseQueue.push_back(clause.id());
			});
		}else{
			ClauseRefType clause{_solver->clauseSpace, _clauseQueue.front()};
			_clauseQueue.pop_front();

			if(!clause.isPresent())
				return;

			_subsumption.backwardSubsumeSingle(clause, _subsumeStats);
//			_subsumption.backwardResolveSingle(clause, _subsumeStats);
			_checkCompact();
		}
	}

	template<typename C>
	void onClauseCompaction(C *compactor) {
		auto wit = _clauseQueue.begin();
		for(auto rit = _clauseQueue.begin(); rit != _clauseQueue.end(); ++rit) {
			ClauseRefType clause{_solver->clauseSpace, *rit};
			if(!clause.isPresent())
				continue;
			compactor->compact(clause);
			*wit++ = clause.prospectiveId();
		}
		_clauseQueue.erase(wit, _clauseQueue.end());
	}

	const SubsumeStats &stats() {
		return _subsumeStats;
	}

private:
	void _checkCompact() {
		if(!_solver->clauseSpace.wantClauseCompaction())
			return;

		_solver->varSpace.cleanWatches(&_solver->clauseSpace);

		auto compactor = _solver->clauseSpace.grabCompactor();
		compactor.commit();
	}

	SolverType *_solver;

	ClauseNameAllocator<PT...> _nameAllocator;
	NullSimplificationTracker _tracker;
	SubsumptionType _subsumption;

	SubsumeStats _subsumeStats;
	std::deque<ClauseIdType> _clauseQueue;
};

// TODO: Implement a PartialInprocessor that can be run during the usual search.

} } // namespace satuzk::cdcl

