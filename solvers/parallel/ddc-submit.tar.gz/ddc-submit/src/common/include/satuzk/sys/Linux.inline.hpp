
#include <unistd.h>
#include <sys/time.h>
#include <sys/mman.h>
#include <sys/resource.h>

void *sysPageAllocate(size_t length) {
	void *pointer = mmap(NULL, length, PROT_READ | PROT_WRITE,
			MAP_ANONYMOUS | MAP_PRIVATE, -1, 0);
	if(pointer == MAP_FAILED)
		throw std::runtime_error("mmap() failed");
	return pointer;
}
void sysPageDeallocate(void *pointer, size_t length) {
	int result = munmap(pointer, length);
	if(result == -1)
		throw std::runtime_error("munmap() failed");
}

sys_msecs_t sysGetWallTime() {
	timeval walltime;
	if(gettimeofday(&walltime, NULL) != 0)
		throw std::runtime_error("gettimeofday() failed\n");
	return walltime.tv_sec * 1000
			+ walltime.tv_usec / 1000;
}

sys_msecs_t sysGetCpuTime() {
	rusage usageinfo;
	if(getrusage(RUSAGE_THREAD, &usageinfo) != 0)
		throw std::runtime_error("rusage() failed");
	return usageinfo.ru_utime.tv_sec * 1000
			+ usageinfo.ru_utime.tv_usec / 1000;
}

uint64_t sysGetUsedMemory() {
}

int sysPeakMemory() {
#if 0
    char  name[256];
    pid_t pid = getpid();

    sprintf(name, "/proc/%d/status", pid);
    FILE* in = fopen(name, "rb");
    if (in == NULL) return 0;

    // Find the correct line, beginning with "VmPeak:":
    int peak_kb = 0;
    while (!feof(in) && fscanf(in, "VmHWM: %d kB", &peak_kb) != 1)
        while (!feof(in) && fgetc(in) != '\n')
            ;
    fclose(in);

    return peak_kb;
#else
	rusage usageinfo;
	if(getrusage(RUSAGE_SELF, &usageinfo) != 0)
		throw std::runtime_error("rusage() failed");
	return usageinfo.ru_maxrss;
#endif
}


