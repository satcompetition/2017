
#include <mpi.h>

namespace satuzk {
namespace mpiutil {

int Comm_rank(MPI_Comm communicator) {
	int rank;
	MPI_Comm_rank(communicator, &rank);
	return rank;
}

int Comm_size(MPI_Comm communicator) {
	int size;
	MPI_Comm_size(communicator, &size);
	return size;
}

template<typename T>
struct ResolveDatatype;

template<>
struct ResolveDatatype<int>
: public std::integral_constant<MPI_Datatype, MPI_INT> { };

template<>
struct ResolveDatatype<unsigned>
: public std::integral_constant<MPI_Datatype, MPI_UNSIGNED> { };

template<>
struct ResolveDatatype<long>
: public std::integral_constant<MPI_Datatype, MPI_LONG> { };

template<>
struct ResolveDatatype<unsigned long>
: public std::integral_constant<MPI_Datatype, MPI_UNSIGNED_LONG> { };

template<typename T>
MPI_Datatype Primitive = ResolveDatatype<T>::value;

} } // namespace satuzk::mpiutil

