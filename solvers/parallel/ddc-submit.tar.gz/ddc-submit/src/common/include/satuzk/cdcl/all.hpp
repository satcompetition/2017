
namespace satuzk {
namespace cdcl {

// --------------------------------------------------------
// Basic types extracted from policy tags
// --------------------------------------------------------

template<typename T>
struct UseHooks { typedef T Type; };

template<typename T>
struct UseLiteralIndex { };

template<typename T>
struct UseActivity { };

template<typename T>
struct UseClauseIndex { };

template<typename T>
struct UseClauseSize { };

template<typename... PT>
using Hooks_ = ExtractTypeOr<UseHooks, DefaultHooks, PT...>;

template<typename... PT>
using LiteralIndex = ExtractTypeOr<UseLiteralIndex, uint32_t, PT...>;

template<typename... PT>
using Activity = ExtractTypeOr<UseActivity, double, PT...>;

template<typename... PT>
using ClauseIndex = ExtractTypeOr<UseClauseIndex, uint32_t, PT...>;

template<typename... PT>
using ClauseSize = ExtractTypeOr<UseClauseSize, uint32_t, PT...>;

// --------------------------------------------------------
// Forward declarations and normalized API types
// --------------------------------------------------------

template<typename... PT>
struct ClauseNameAllocatorStruct;

template<typename... PT>
struct AntecedentStruct;

template<typename... PT>
struct ConflictStruct;

template<typename... PT>
struct VsidsStateStruct;

template<typename... PT>
struct LearnStateStruct;

template<typename... PT>
struct VariableHooksStruct;

template<typename... PT>
struct ClauseHooksStruct;

template<typename... PT>
struct TrailHooksStruct;

template<typename... PT>
struct SolverStruct;

template<typename... PT>
using DecisionLevel = std::make_signed_t<LiteralIndex<PT...>>;

template<typename... PT>
using TrailIndex = LiteralIndex<PT...>;

template<typename... PT>
using VariableId = vars::VariableId<
	vars::UseIndex<LiteralIndex<PT...>>
>;

template<typename... PT>
using LiteralId = typename VariableId<PT...>::LiteralIdType;

template<typename... PT>
using ClauseId = cclauses::ClauseId<
	cclauses::UseIndex<ClauseIndex<PT...>>
>;

template<typename... PT>
using ClauseName = cclauses::ClauseName<
	cclauses::UseIndex<ClauseIndex<PT...>>
>;

template<typename... PT>
using ClauseNameAllocator = ClauseNameAllocatorStruct<PT...>;

template<typename... PT>
using Antecedent = AntecedentStruct<PT...>;

template<typename... PT>
using Conflict = ConflictStruct<PT...>;

template<typename... PT>
using VariableSpace = vars::VariableSpace<
	vars::UseIndex<LiteralIndex<PT...>>,
	vars::UseClauseId<ClauseId<PT...>>,
	vars::UseAntecedent<Antecedent<PT...>>,
	vars::UseHooks<VariableHooksStruct<PT...>>
>;

template<typename... PT>
using VariableRef = typename VariableSpace<PT...>::VariableRef;

template<typename... PT>
using LiteralRef = typename VariableSpace<PT...>::LiteralRef;

template<typename... PT>
using ClauseSpace = cclauses::ClauseSpace<
	cclauses::UseIndex<ClauseIndex<PT...>>,
	cclauses::UseClauseSize<ClauseSize<PT...>>,
	cclauses::UseLiteralId<LiteralId<PT...>>,
	cclauses::UseActivity<Activity<PT...>>,
	cclauses::UseVariableSpace<VariableSpace<PT...>>,
	cclauses::UseHooks<ClauseHooksStruct<PT...>>
>;

template<typename... PT>
using ClauseRef = typename ClauseSpace<PT...>::ClauseRef;

template<typename... PT>
using Occlists = satutils::Occlists<
	satutils::UseAtom<LiteralId<PT...>>,
	satutils::UseConstraintId<ClauseId<PT...>>,
	satutils::UseConstraintRef<ClauseRef<PT...>>,
	satutils::UseConstraintSpace<ClauseSpace<PT...>>
>;

template<typename... PT>
using Assignment = satutils::Assignment<
	satutils::UseVariableSpace<VariableSpace<PT...>>,
	satutils::UseAntecedent<Antecedent<PT...>>,
	satutils::UseDecisionLevel<DecisionLevel<PT...>>
>;

template<typename... PT>
using Trail = satutils::Trail<
	satutils::UseAtomSpace<VariableSpace<PT...>>,
	satutils::UseAntecedent<Antecedent<PT...>>,
	satutils::UseConflict<Conflict<PT...>>,
	satutils::UseDecisionLevel<DecisionLevel<PT...>>,
	satutils::UseTrailIndex<TrailIndex<PT...>>,
	satutils::UseHooks<TrailHooksStruct<PT...>>
>;

template<typename... PT>
using VsidsState = VsidsStateStruct<PT...>;

template<typename... PT>
using LearnState = LearnStateStruct<PT...>;

template<typename... PT>
using Solver = SolverStruct<PT...>;

} } // namespace satuzk::cdcl

#include "antecedent.hpp"
#include "conflict.hpp"
#include "vsids.hpp"
#include "propagate.hpp"
#include "learn.hpp"

