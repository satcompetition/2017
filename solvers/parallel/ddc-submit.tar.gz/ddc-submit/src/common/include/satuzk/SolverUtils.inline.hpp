
namespace satuzk {
namespace cdcl {

// luby sequence:
// t(i) = 2^(k-1)				if i = 2^k - 1
// t(i) = t(i - 2^(k-1) + 1)	if 2^(k-1) <= i < 2^k - 1
inline unsigned int lubySequence(unsigned int i) {
	while(i != 0) {
		// calculate k maximal so that i <= 2^k - 1
		unsigned int rem = i;
		unsigned int k = 0;
		unsigned int kpow = 1; // k-th power of 2
		while(rem != 0) {
			k++;
			rem /= 2;
			kpow *= 2;
		}
		
		// first case: t(i) = 2^(k-1)
		if(i == kpow - 1)
			return kpow / 2;
		// second case: t(i) = t(i - 2^(k-1) + 1)
		i = i - kpow / 2 + 1;
	}
	return 1;
}

template<typename... PT, typename Iterator>
int findPolarity(Iterator begin, Iterator end, VariableId<PT...> variable) {
	for(auto it = begin; it != end; ++it) {
		if((*it).variable() == variable)
			return (*it).polarity();
	}
	return 0;
}

template<typename... PT>
std::vector<LiteralId<PT...>> findFailedAssumptions(SolverStruct<PT...> &solver) {
	assert(solver.trail.conflict());

	std::vector<LiteralId<PT...>> stack;
	std::vector<LiteralId<PT...>> result;
	
	std::vector<bool> marked;
	marked.resize(solver.varSpace.count());

	auto visit = [&] (LiteralId<PT...> literal) {
		assert(solver.assignment.isTrue(literal));
		if(marked[literal.variable().getIndex()])
			return;
		marked[literal.variable().getIndex()] = true;
		stack.push_back(literal);
	};

	auto conflict = solver.trail.conflict();
	for(auto it = conflict.begin(solver); it != conflict.end(solver); ++it)
		visit(*it);

	while(!stack.empty()) {
		LiteralId<PT...> literal = stack.back();
		stack.pop_back();

		auto antecedent = solver.varAntecedent(literal.variable());
		if(!antecedent.isInitial()) {
			for(auto it = antecedent.begin(solver); it != antecedent.end(solver); ++it)
				visit(*it);
		}else{
			if(solver.isAssumed(literal))
				result.push_back(literal);
		}
	}

	return result;
}

template<typename... PT>
void checkSolution(SolverStruct<PT...> &solver) {
	solver.clauseSpace.forEach([&] (auto clause) {
		if(!clause.isPresent())
			return;

		bool satisfied = false;
		for(auto l_it = clause.beginLits(); l_it != clause.endLits(); ++l_it)
			if(solver.assignment.isTrue(*l_it))
				satisfied = true;

		if(!satisfied)
			std::cout << (clause.isEssential() ? "Essential clause " : "Clause ")
					<< clause << " is not satisfied!" << std::endl;
	});
}

} } // namespace satuzk::cdcl

