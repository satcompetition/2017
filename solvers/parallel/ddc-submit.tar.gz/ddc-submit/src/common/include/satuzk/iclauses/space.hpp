
#include <stddef.h>
#include <limits.h>

namespace satuzk {
namespace iclauses {

// flags that disable expensive debugging checks
constexpr bool kDbgCheckNewClauses = false;

struct ClauseNameStruct {
	ClauseNameStruct() = default;

	ClauseNameStruct(uint64_t bits)
	: _bits(bits) { }

	ClauseNameStruct(uint16_t origin, uint64_t local)
	: _bits((uint64_t(origin) << 48) | local) {
		// make sure that the local part uses only 48-bits
		assert((local % (uint64_t(1) << 48)) == local);
	}

	bool operator== (ClauseNameStruct other) const {
		return _bits == other._bits;
	}
	bool operator< (ClauseNameStruct other) const {
		if(origin() != other.origin())
			return origin() < other.origin();
		return local() < other.local();
	}

	uint64_t bits() const {
		return _bits;
	}

	uint16_t origin() const {
		return _bits >> 48;
	}
	uint64_t local() const {
		return _bits % (uint64_t(1) << 48);
	}

private:
	uint64_t _bits;
};

std::ostream &operator<<(std::ostream &out, ClauseNameStruct name) {
	out << "(" << name.origin() << "/" << name.local() << ")";
	return out;
}

/*template<typename... PT>
struct NameToIdMapStruct {
	typedef ClauseId<PT...> ClauseIdType;
	typedef ClauseNameStruct ClauseNameType;

	void insert(ClauseNameType name, ClauseIdType id) { }

	ClauseIdType at(ClauseNameType name) {
		assert(!"NameToIdMap is disabled in this policy");
	}

	void update(ClauseNameType name, ClauseIdType id) { }
	void remove(ClauseNameType name) { }
};*/

static constexpr bool _profileNameToIdMap = false;

template<typename... PT>
struct NameToIdMapStruct {
	typedef ClauseId<PT...> ClauseIdType;
	typedef ClauseNameStruct ClauseNameType;
	typedef ClauseRef<PT...> ClauseRefType;
	typedef ClauseSpace<PT...> ClauseSpaceType;

public:
	// even the smallest instances contain thousands of clauses:
	// initialize the table size with 1024.
	NameToIdMapStruct(ClauseSpaceType *space)
	: _space(space), _bucketShift(10), _table(size_t(1) << _bucketShift), _numItems(0),
			_prime(3), _maxProbes(0) { }

	void insert(ClauseNameType name, ClauseIdType id, bool nested = false) {
		if(_numItems >= (size_t(1) << (_bucketShift - 1)) || name.origin() >= _prime) {
			// for now the table only grows, so we just increment _bucketShift
			auto new_shift = (_numItems >= (size_t(1) << (_bucketShift - 1)))
					? (_bucketShift + 1) : _bucketShift;
			assert(_numItems < (size_t(1) << new_shift));

			// using the smallest prime greater than all origin numbers
			// makes sure (at least empirically) that the hash function produces
			// a good distribution for typical instances.
			auto isPrime = [] (int number) {
				// this is a horrible algorithm but we only expect very small numbers as input
				for(int k = 2; k < number; k++)
					if(number % k == 0)
						return false;
				return true;
			};
		
			auto new_prime = std::max<unsigned int>(name.origin() + 1, _prime);
			while(!isPrime(new_prime))
				new_prime++;
			
			if(_profileNameToIdMap) {
				std::cout << "Fill factor: " << (float(_numItems) / (size_t(1) << _bucketShift))
						<< "; rehash to shift: " << new_shift
						<< ", prime: " << new_prime << std::endl;
			}

			// TODO: this self-assignment is not the most beautiful construct
			assert(!nested);
			*this = NameToIdMapStruct(Rehash(), _space, new_shift, new_prime,
					_table.begin(), _table.end());
		}

		size_t h = _hash(name);
		for(uint32_t k = 1; ; k++) {
			assert(k <= (size_t(1) << _bucketShift));

			// make sure the name does not already exist
			size_t p = (h + k - 1) % (size_t(1) << _bucketShift);
			assert(!(_table[p] && ClauseRefType(*_space, _table[p]).name() == name));

			if(!_table[p]) {
				_table[p] = id;

				if(k > _maxProbes) {
					if(_profileNameToIdMap)
						std::cout << "maxProbes: " << k << std::endl;
					_maxProbes = k;
				}
				_numItems++;
				break;
			}
		}
	}

	ClauseIdType at(ClauseNameType name) {
		size_t h = _hash(name);
		for(uint32_t k = 1; ; k++) {
			assert(k <= _maxProbes);

			size_t p = (h + k - 1) % (size_t(1) << _bucketShift);
			if(_table[p] && ClauseRefType(*_space, _table[p]).name() == name)
				return _table[p];
		}
	}

	void update(ClauseNameType name, ClauseIdType id) {
		size_t h = _hash(name);
		for(uint32_t k = 1; ; k++) {
			assert(k <= _maxProbes);

			size_t p = (h + k - 1) % (size_t(1) << _bucketShift);
			if(_table[p] && ClauseRefType(*_space, _table[p]).name() == name) {
				_table[p] = id;
				return;
			}
		}
	}

	void remove(ClauseNameType name) {
		size_t h = _hash(name);
		for(uint32_t k = 1; ; k++) {
			assert(k <= _maxProbes);

			size_t p = (h + k - 1) % (size_t(1) << _bucketShift);
			if(_table[p] && ClauseRefType(*_space, _table[p]).name() == name) {
				_table[p] = ClauseIdType();
				return;
			}
		}
	}

private:
	struct Rehash { };

	template<typename Iterator>
	NameToIdMapStruct(Rehash, ClauseSpaceType *space,
			size_t new_shift, size_t new_prime, Iterator begin, Iterator end)
	: _space(space), _bucketShift(new_shift), _table(size_t(1) << _bucketShift), _numItems(0),
			_prime(new_prime), _maxProbes(0) {
		// do not allow rehashing here 
		for(auto it = begin; it != end; ++it)
			if(*it)
				insert(ClauseRefType(*_space, *it).name(), *it, true);
	}

	size_t _hash(ClauseNameType name) {
		return (name.local() * _prime) | name.origin();
	}

	ClauseSpaceType *_space;
	size_t _bucketShift;
	std::vector<ClauseIdType> _table;
	size_t _numItems;
	unsigned int _prime;
	size_t _maxProbes;
};

template<typename... PT>
class ClauseSpaceStruct {
public:
	typedef LiteralId<PT...> LiteralIdType;
	typedef Index<PT...> IndexType;
	typedef ClauseId<PT...> ClauseIdType;
	typedef ClauseNameStruct ClauseNameType;
	typedef ClauseSize<PT...> ClauseSizeType;
	typedef Activity<PT...> ActivityType;
	
	typedef VariableSpace<PT...> VariableSpaceType;
	typedef typename VariableSpace<PT...>::LiteralRef LiteralRefType;
	typedef Hooks<PT...> HooksType;

	typedef NameToIdMapStruct<PT...> NameToIdType;

	typedef uint64_t SignatureType;
	
	struct alignas(16) ClauseHead {
		// clause is installed i.e. in watch lists
		static const uint32_t kFlagInstalled = 1;
		// marked for deletion
		static const uint32_t kFlagDelete = 2;
		// marked essential i.e. must not be deleted
		static const uint32_t kFlagEssential = 4;
		// clause is frozen, i.e. not installed but will be reinstalled later
		static const uint32_t kFlagFrozen = 8;
		// the clause has been marked by some algorithm.
		// algorithms should remove this mark after they are done.
		static const uint32_t kFlagMarked = 16;
		static const uint32_t kFlagImproved = 128;
		static const uint32_t kFlagCheckedDist = 256;
		static const uint32_t kFlagCreatedVecd = 512;
		static const uint32_t kFlagCheckedSsub = 1024;

		// watched literals.
		LiteralIdType assertedWatch;
		LiteralIdType triggerWatch;
		// number of literals of the clause.
		ClauseSizeType numLiterals;
		// offset of this clause inside the literal vector.
		uint32_t offset;
		
		ClauseHead() = default;
		ClauseHead(ClauseSizeType num_literals, size_t offset)
		: numLiterals(num_literals), offset(offset) {
			// TODO: make sure offset fits into uint32_t
		}
	};
	static_assert(std::is_trivially_copyable<ClauseHead>::value, "head not trivial");

	struct ClauseRef;

	class Iterator
		: public std::iterator<std::forward_iterator_tag, ClauseIdType> {
	public:
		Iterator(ClauseSpaceStruct &space, IndexType index)
			: _space(&space), _index(index) { }
		
		void operator++ () {
			_index++;
		}
		bool operator== (const Iterator &other) const {
			return _index == other._index;
		}
		bool operator!= (const Iterator &other) const {
			return !(*this == other);
		}
		ClauseRef operator* () const {
			return ClauseRef(*_space, ClauseIdType::fromIndex(_index));
		}
		ArrowProxy<ClauseRef> operator-> () const {
			return ArrowProxy<ClauseRef>(**this);
		}
		
	private:
		ClauseSpaceStruct *_space;
		IndexType _index;
	};

	struct LiteralIterator {
		LiteralIterator(ClauseSpaceStruct &space, LiteralIdType *pointer)
		: _space(&space), _pointer(pointer) { }

		// Iterator concept
		LiteralIterator &operator++ () {
			_pointer++;
			return *this;
		}
		LiteralRefType operator* () const {
			return LiteralRefType(*_space->varSpace, *_pointer);
		}

		// InputIterator concept
		bool operator== (const LiteralIterator &other) const {
			return _pointer == other._pointer;
		}
		bool operator!= (const LiteralIterator &other) const {
			return !(*this == other);
		}
		ArrowProxy<LiteralRefType> operator-> () const {
			return ArrowProxy<LiteralRefType>(**this);
		}
		LiteralIterator operator++ (int) {
			LiteralIterator copy = *this;
			++(*this);
			return copy;
		}
	
	public:
		// std::iterator_traits typedefs
		typedef std::input_iterator_tag iterator_category;
		typedef LiteralRefType value_type;

		typedef decltype(*std::declval<LiteralIterator>()) reference;
		typedef std::add_pointer_t<reference> pointer;
		typedef ptrdiff_t difference_type;
		
	private:
		ClauseSpaceStruct *_space;
		LiteralIdType *_pointer;
	};

	class ClauseRef {
	public:
		typedef ClauseSpaceStruct::LiteralIterator LiteralIterator;

		friend std::ostream &operator<<(std::ostream &out, ClauseRef clause) {
			for(auto it = clause.beginLits(); it != clause.endLits(); ++it)
				out << (it == clause.beginLits() ? "[" : ", ") << it->toNumber();
			out << "]";
			return out;
		}

		ClauseRef()
		: _space(nullptr) { }

		ClauseRef(ClauseSpaceStruct &space, ClauseIdType id)
		: _space(&space), _id(id) { }

		ClauseSpaceStruct &space() {
			return *_space;
		}

		ClauseIdType id() const {
			return _id;
		}

		bool operator== (const ClauseRef &other) {
			return _space == other._space && _id == other._id;
		}

		IndexType getIndex() const {
			return _id.getIndex();
		}

		size_t length() {
			auto head = _space->_accessHead(getIndex());
			return head->numLiterals;
		}

		void prefetchLits() {
			return __builtin_prefetch(_space->_accessLiteral(_id, 0), 0);
		}

		LiteralIterator beginLits() {
			return LiteralIterator(*_space, _space->_accessLiteral(_id, 0));
		}
		LiteralIterator endLits() {
			return LiteralIterator(*_space, _space->_accessLiteral(_id, length()));
		}
		
		LiteralIdType assertedWatch() {
			if(kDbgSlowAssertions)
				assert(length() >= 1);
			auto head = _space->_accessHead(getIndex());
			return head->assertedWatch;
		}
		LiteralIdType triggerWatch() {
			if(kDbgSlowAssertions)
				assert(length() >= 2);
			auto head = _space->_accessHead(getIndex());
			return head->triggerWatch;
		}
		void swapWatches() {
			if(kDbgSlowAssertions)
				assert(length() >= 2);
			auto head = _space->_accessHead(getIndex());
			std::swap(head->assertedWatch, head->triggerWatch);
		}
		void updateTriggerWatch(LiteralIterator it) {
			if(kDbgSlowAssertions)
				assert(length() >= 2);
			auto head = _space->_accessHead(getIndex());
			head->triggerWatch = it->id();
		}

		ClauseNameType name() {
			return _space->_names[getIndex()];
		}

		bool isPresent() {
			return !(_space->_flags[getIndex()] & ClauseHead::kFlagDelete);
		}
		void erase() {
			assert(!(_space->_flags[getIndex()] & ClauseHead::kFlagDelete));

			if(_space->_flags[getIndex()] & ClauseHead::kFlagEssential)
				_space->currentEssentialClauses--;

			_space->_flags[getIndex()] |= ClauseHead::kFlagDelete;
			
			_space->_presentClauses--;
			_space->_presentLiterals -= length();
			_space->_deletedClauses++;

			_space->hooks.onErase(*this);
		}

		ClauseIdType prospectiveId() {
			assert(!(_space->_flags[getIndex()] & ClauseHead::kFlagDelete));
			return _space->_prospective[getIndex()];
		}

		bool isEssential() {
			return _space->_flags[getIndex()] & ClauseHead::kFlagEssential;
		}
		void markAsEssential() {
			assert(!(_space->_flags[getIndex()] & ClauseHead::kFlagEssential));
			_space->_flags[getIndex()] |= ClauseHead::kFlagEssential;

			_space->currentEssentialClauses++;
		}
		void markAsNotEssential() {
			assert(_space->_flags[getIndex()] & ClauseHead::kFlagEssential);
			_space->_flags[getIndex()] &= ~ClauseHead::kFlagEssential;

			_space->currentEssentialClauses--;
		}
		
		ActivityType getActivity() {
			return _space->_activities[getIndex()];
		}

	private:
		ClauseSpaceStruct *_space;
		ClauseIdType _id;
	};

	ClauseSpaceStruct(VariableSpaceType &var_space, HooksType hooks)
	: varSpace(&var_space), hooks(std::move(hooks)),
			_allClauses(0), _allLiterals(0), _presentClauses(0), _presentLiterals(0),
			_deletedClauses(0), currentEssentialClauses(0), _nameToIdMap(this) {
	}

private:
	ClauseHead *_accessHead(IndexType index) {
		if(kDbgSlowAssertions)
			assert(index < _heads.size());
		return &_heads[index];
	}

	LiteralIdType *_accessLiteral(ClauseIdType id, ClauseSizeType i) {
		ClauseHead *head = _accessHead(id.getIndex());
		// TODO: this assertion would be correct if not for past-the-end iterators.
		//assert(head->offset + i < _literals.size());
		return &_literals[head->offset + i];
	}

public:
	template<typename Iterator>
	ClauseRef allocate(ClauseNameType name, ClauseSizeType length, Iterator begin, Iterator end) {
		// sanity check. high performance overhead
		if(kDbgCheckNewClauses)
			for(auto i = begin; i != end; ++i) {
//FIXME				assert(varIsPresent((*i).variable()));
				for(auto j = begin; j != end; ++j) {
					if(i == j)
						continue;
					assert(*i != *j && *i != (*j).inverse());
				}
			}
		
		// remember the clause index and offset before we modify data structures.
		IndexType index = _heads.size();
		size_t offset = _literals.size();
		ClauseRef ref(*this, ClauseIdType::fromIndex(index));
		
		// push the literals of this clause.
		// calculate the signature while we're doing that.
		SignatureType signature = 0;
		ClauseSizeType k = 0;
		for(Iterator it = begin; it != end; ++it) {
			_literals.push_back(it->id());
			signature |= (1 << (it->variable().getIndex() % (sizeof(SignatureType) * CHAR_BIT)));
			k++;
		}
		assert(k == length);

		// setup the fixed-size data structures.
		_heads.push_back(ClauseHead(length, offset));
		_flags.push_back(0);
		_names.push_back(name);
		_signatures.push_back(signature);
		_activities.push_back(0.0);
		_lbds.push_back(0);

		// setup related data structures.
		_nameToIdMap.insert(name, ref.id());

		if(length >= 1)
			_accessHead(ref.getIndex())->assertedWatch = begin->id();
		if(length >= 2)
			_accessHead(ref.getIndex())->triggerWatch = std::next(begin)->id();

		_allClauses++;
		_allLiterals += length;
		_presentClauses++;
		_presentLiterals += length;
		
		hooks.onAllocate(ref);
		return ref;
	}

	Iterator beginRefs() {
		return Iterator(*this, 0);
	}
	Iterator endRefs() {
		return Iterator(*this, _heads.size());
	}

	ClauseRef findName(ClauseNameType name) {
		return ClauseRef(*this, _nameToIdMap.at(name));
	}

	unsigned int numClauses() {
		return _allClauses;
	}
	unsigned int numPresent() {
		return _presentClauses;
	}
	uint64_t presentLiterals() {
		return _presentLiterals;
	}
	unsigned int numDeleted() {
		return _deletedClauses;
	}
	size_t usedSpace() {
		return _heads.size() * sizeof(ClauseHead)
				+ _literals.size() * sizeof(LiteralIdType);
	}

	void clauseSetActivity(ClauseIdType clause, ActivityType activity) {
		_activities[clause.getIndex()] = activity;
	}
	ActivityType clauseGetActivity(ClauseIdType clause) {
		return _activities[clause.getIndex()];
	}

	void clauseSetSignature(ClauseIdType clause, uint64_t signature) {
		_signatures[clause.getIndex()] = signature;
	}
	uint64_t clauseGetSignature(ClauseIdType clause) {
		return _signatures[clause.getIndex()];
	}

	void clauseSetLbd(ClauseIdType clause, uint16_t lbd) {
		_lbds[clause.getIndex()] = lbd;
	}
	uint16_t clauseGetLbd(ClauseIdType clause) {
		return _lbds[clause.getIndex()];
	}
	
	ClauseIdType getMoveDestination(ClauseIdType clause) {
		assert(wasMoved(clause));
		return ClauseIdType::fromIndex(_accessHead(clause.getIndex())->movedTail.destination);
	}

	void setFlagInstalled(ClauseIdType clause) { _flags[clause.getIndex()] |= ClauseHead::kFlagInstalled; }
	bool getFlagInstalled(ClauseIdType clause) { return _flags[clause.getIndex()] & ClauseHead::kFlagInstalled; }
	void unsetFlagInstalled(ClauseIdType clause) { _flags[clause.getIndex()] &= ~ClauseHead::kFlagInstalled; }

	void setFlagFrozen(ClauseIdType clause) { _flags[clause.getIndex()] |= ClauseHead::kFlagFrozen; }
	bool getFlagFrozen(ClauseIdType clause) { return _flags[clause.getIndex()] & ClauseHead::kFlagFrozen; }
	void unsetFlagFrozen(ClauseIdType clause) { _flags[clause.getIndex()] &= ~ClauseHead::kFlagFrozen; }
	
	void setFlagMarked(ClauseIdType clause) { _flags[clause.getIndex()] |= ClauseHead::kFlagMarked; }
	bool getFlagMarked(ClauseIdType clause) { return _flags[clause.getIndex()] & ClauseHead::kFlagMarked; }
	void unsetFlagMarked(ClauseIdType clause) { _flags[clause.getIndex()] &= ~ClauseHead::kFlagMarked; }

	bool getFlagImproved(ClauseIdType clause) { return _flags[clause.getIndex()] & ClauseHead::kFlagImproved; }
	void setFlagImproved(ClauseIdType clause) { _flags[clause.getIndex()] |= ClauseHead::kFlagImproved; }
	void unsetFlagImproved(ClauseIdType clause) { _flags[clause.getIndex()] &= ~ClauseHead::kFlagImproved; }
	
	void setFlagCheckedDist(ClauseIdType clause) { _flags[clause.getIndex()] |= ClauseHead::kFlagCheckedDist; }
	bool getFlagCheckedDist(ClauseIdType clause) { return _flags[clause.getIndex()] & ClauseHead::kFlagCheckedDist; }

	void setFlagCreatedVecd(ClauseIdType clause) { _flags[clause.getIndex()] |= ClauseHead::kFlagCreatedVecd; }

	void setFlagCheckedSsub(ClauseIdType clause) { _flags[clause.getIndex()] |= ClauseHead::kFlagCheckedSsub; }
	bool getFlagCheckedSsub(ClauseIdType clause) { return _flags[clause.getIndex()] & ClauseHead::kFlagCheckedSsub; }

	void compactClauses() {
		if(!(_presentClauses < _allClauses / 2
				|| _presentLiterals < _allLiterals / 2))
			return;

		// allocate a new clause id for each non-erased clause.
		_prospective.resize(numClauses());
		uintptr_t allocated = 0;
		for(auto it = beginRefs(); it != endRefs(); ++it) {
			if(!(_flags[it->getIndex()] & ClauseHead::kFlagDelete)) {
				_prospective[it->getIndex()] = ClauseIdType::fromIndex(allocated);
				allocated++;
			}else{
				// make sure currentEssentialClauses is correct
//FIXME				assert(!(head->flags & ClauseHead::kFlagEssential));
			}
		}

		// allow external code to update clause references
		hooks.onCompact();

		// perform the actual compaction.
		size_t compacted_clauses = 0;
		size_t compacted_literals = 0;

		uintptr_t dest = 0, offset = 0;
		for(uintptr_t src = 0; src < numClauses(); ++src) {
			if(!(_flags[src] & ClauseHead::kFlagDelete)) {
				assert(dest == _prospective[src].getIndex());
				assert(dest <= src);
				assert(offset <= _heads[src].offset);
				
				// update related data structures.
				_nameToIdMap.update(_names[src], ClauseIdType::fromIndex(dest));

				// copy the fixed-size structures.
				_heads[dest] = _heads[src];
				_flags[dest] = _flags[src];
				_names[dest] = _names[src];
				_signatures[dest] = _signatures[src];
				_activities[dest] = _activities[src];
				_lbds[dest] = _lbds[src];

				// copy a clause-dependent number of literals.
				_heads[dest].offset = offset;
				for(ClauseSizeType i = 0; i < _heads[src].numLiterals; i++)
					_literals[offset++] = _literals[_heads[src].offset + i];
				
				compacted_clauses++;
				compacted_literals += _heads[dest].numLiterals;
				dest++;
			}else{
				// update related data structures.
				_nameToIdMap.remove(_names[src]);
			}
		}

		// cut off all remaining slots in the data structures.
		_heads.resize(dest);
		_flags.resize(dest);
		_names.resize(dest);
		_signatures.resize(dest);
		_activities.resize(dest);
		_lbds.resize(dest);
		_literals.resize(offset);
		_prospective.clear();

		_allClauses = compacted_clauses;
		_allLiterals = compacted_literals;
		_presentClauses = compacted_clauses;
		_presentLiterals = compacted_literals;
		_deletedClauses = 0;

		hooks.afterCompact();
	}
	
	size_t currentEssentialClauses;

private:
	VariableSpaceType *varSpace;
	HooksType hooks;
	
	std::vector<ClauseHead> _heads;
	std::vector<uint32_t> _flags;
	std::vector<ClauseNameType> _names;
	std::vector<SignatureType> _signatures;
	std::vector<ActivityType> _activities;
	std::vector<uint16_t> _lbds;
	std::vector<LiteralIdType> _literals;

	std::vector<ClauseIdType> _prospective;
	
	unsigned int _allClauses;
	uint64_t _allLiterals;
	unsigned int _presentClauses;
	uint64_t _presentLiterals;
	unsigned int _deletedClauses;

	NameToIdType _nameToIdMap;
};

} } // namespace satuzk::iclauses

