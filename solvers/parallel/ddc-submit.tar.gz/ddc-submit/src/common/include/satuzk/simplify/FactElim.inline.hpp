
namespace satuzk {

template<typename Defs>
void eliminateFacts(Solver<Defs> &solver) {
	solver.start();

	std::vector<LiteralType<Defs>> facts;
	for(OrderType<Defs> op = solver.p_propagateConfig.firstAssignAtLevel(1);
			op < solver.p_propagateConfig.lastAssignAtLevel(1); op++)
		facts.push_back(solver.p_propagateConfig.getAssignByOrder(op));

	solver.reset();

	auto hasFact = [&facts] (LiteralType<Defs> literal) -> bool {
		return std::find(facts.begin(), facts.end(), literal) != facts.end();
	};

	std::vector<ClauseType<Defs>> queue;
	for(auto cp = solver.clausesBegin(); cp != solver.clausesEnd(); ++cp) {
		if(!solver.clauseIsPresent(*cp))
			continue;

		queue.push_back(*cp);
	}

	for(auto cp = queue.begin(); cp != queue.end(); ++cp) {
		assert(solver.clauseIsPresent(*cp));

		bool has_sat = false, has_fact = false;
		for(auto lp = solver.clauseBegin(*cp); lp != solver.clauseEnd(*cp); ++lp) {
			if(hasFact(*lp))
				has_sat = true;
			if(hasFact((*lp).inverse()))
				has_fact = true;
		}

		if(has_sat) {
			if(solver.clauseIsEssential(*cp))
				solver.clauseUnsetEssential(*cp);
			if(solver.clauseIsInstalled(*cp))
				solver.uninstallClause(*cp);
			solver.deleteClause(*cp);
		}else if(has_fact) {
			std::vector<LiteralType<Defs>> literals;
			for(auto lp = solver.clauseBegin(*cp); lp != solver.clauseEnd(*cp); ++lp) {
				assert(!hasFact(*lp));
				if(hasFact((*lp).inverse()))
					continue;
				literals.push_back(*lp);
			}

			auto new_clause = solver.allocClause(literals.size(),
					literals.begin(), literals.end());
			if(solver.clauseIsEssential(*cp))
				solver.clauseSetEssential(new_clause);
			solver.installClause(new_clause);

			if(solver.clauseIsEssential(*cp))
				solver.clauseUnsetEssential(*cp);
			if(solver.clauseIsInstalled(*cp))
				solver.uninstallClause(*cp);
			solver.deleteClause(*cp);
		}
	}
	
	for(auto it = facts.begin(); it != facts.end(); ++it) {
		solver.p_extModelConfig.pushFact(solver, *it);
		solver.deleteVar(it->variable());
	}
}

} // namespace satuzk

