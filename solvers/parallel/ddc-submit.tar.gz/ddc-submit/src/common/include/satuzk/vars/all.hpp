
namespace satuzk {
namespace vars {

// --------------------------------------------------------
// Basic types extracted from policy tags
// --------------------------------------------------------

template<typename T>
struct UseIndex { };

template<typename T>
struct UseClauseId { };

template<typename T>
struct UseAntecedent { };

template<typename T>
struct UseHooks { };

template<typename... PT>
using Index = ExtractType<UseIndex, PT...>;

template<typename... PT>
using ClauseId = ExtractType<UseClauseId, PT...>;

template<typename... PT>
using Antecedent = ExtractType<UseAntecedent, PT...>;

template<typename... PT>
using Hooks = ExtractType<UseHooks, PT...>;

// --------------------------------------------------------
// Forward declarations and normalized API types
// --------------------------------------------------------

template<typename... PT>
class VariableIdStruct;

template<typename... PT>
class LiteralIdStruct;

template<typename... PT>
class VariableSpaceStruct;

template<typename... PT>
using DecisionLevel = Index<PT...>;

template<typename... PT>
using VariableId = VariableIdStruct<
	UseIndex<Index<PT...>>
>;

template<typename... PT>
using LiteralId = LiteralIdStruct<
	UseIndex<Index<PT...>>
>;

template<typename... PT>
using VariableSpace = VariableSpaceStruct<PT...>;

} } // namespace satuzk::vars

#include "basic.hpp"
#include "space.hpp"

