
class BaseParser {
public:
	BaseParser(int fd) : p_fd(fd),
			p_readPointer(0), p_readLimit(0), p_eof(false) {
		read();
	}

	//---------------------------------------------------------------
	// low level functions
	//---------------------------------------------------------------

	void read() {
		assert(p_readPointer == p_readLimit);
		ssize_t len = ::read(p_fd, p_readBuffer, kReadBufferSize);
		if(len == -1)
			throw std::runtime_error("Could not read input");
		if(len == 0)
			p_eof = true;
		p_readLimit = len;
		p_readPointer = 0;
	}
	void consume() {
		p_readPointer++;
		if(p_readPointer == p_readLimit)
			read();
	}
	bool atEndOfFile() {
		return p_eof;
	}
	char fetch() {
		assert(p_readPointer < p_readLimit);
		return p_readBuffer[p_readPointer];
	}
	
	//---------------------------------------------------------------
	// high level functions
	//---------------------------------------------------------------

	bool checkSpace() {
		return fetch() == ' ' || fetch() == '\t';
	}
	bool checkBreak() {
		return fetch() == '\n' || fetch() == '\r';
	}
	
	void skipSpace() {
		while(!atEndOfFile() && checkSpace())
			consume();
	}
	void skipSpaceOrBreak() {
		while(!atEndOfFile() && (checkSpace() || checkBreak()))
			consume();
	}
	void skipUntilBreakOrEnd() {
		while(!atEndOfFile() && !checkBreak())
			consume();
		if(!atEndOfFile())
			consume();
	}
	
	void forceBreakOrEnd() {
		if(atEndOfFile())
			return;
		if(!checkBreak())
			throw std::runtime_error("Expected end-of-line");
		consume();
	}

	void readWord() {
		p_tempLength = 0;
		while(!atEndOfFile() && !checkSpace() && !checkBreak()) {
			if(p_tempLength >= kTempBufferSize)
				throw std::logic_error("Buffer limit reached");
			p_tempBuffer[p_tempLength++] = fetch();
			consume();
		}
	}	
	bool bufferMatch(const char *string) {
		for(int i = 0; string[i] != 0; i++) {
			if(i >= p_tempLength)
				return false;
			if(string[i] != p_tempBuffer[i])
				return false;
		}
		return true;
	}
	int64_t bufferGetInt() {
		int64_t num = 0;
		bool neg = false;
		int i = 0;
		
		if(p_tempLength == 0)
			throw std::runtime_error("Expected number (empty buffer)");
		if(i < p_tempLength && p_tempBuffer[i] == '-') {
			neg = true;
			i++;
		}
		while(i < p_tempLength) {
			if(!(p_tempBuffer[i] >= '0' && p_tempBuffer[i] <= '9'))
				throw std::runtime_error("Expected number (illegal char)");
			num = num * 10 + (p_tempBuffer[i] - '0');
			i++;
		}
		return neg ? -num : num;
	}
	
private:
	static const int kReadBufferSize = 16 * 1024;
	static const int kTempBufferSize = 1024;
	
	int p_fd;
	
	char p_readBuffer[kReadBufferSize];
	int p_readPointer;
	int p_readLimit;
	bool p_eof;
	
	char p_tempBuffer[kTempBufferSize];
	int p_tempLength;
};

namespace satuzk {
namespace cdcl {

template<typename... PT>
class CnfParser {
public:
	typedef VariableSpace<PT...> VariableSpaceType;
	typedef VariableId<PT...> VariableIdType;
	typedef VariableRef<PT...> VariableRefType;
	typedef LiteralId<PT...> LiteralIdType;

	typedef ClauseSpace<PT...> ClauseSpaceType;
	typedef ClauseRef<PT...> ClauseRefType;

	CnfParser(VariableSpaceType &var_space, ClauseSpaceType &clause_space, int fd)
	: _varSpace(&var_space), _clauseSpace(&clause_space), _clauseNumber(1), _base(fd) { }

	void parse() {
		while(!_base.atEndOfFile()) {
			_base.skipSpaceOrBreak();
			if(_base.atEndOfFile())
				break;
			_base.readWord();
			
			if(_base.bufferMatch("c")) {
				_base.skipUntilBreakOrEnd();
			}else if(_base.bufferMatch("p")) {
				// read the file type
				_base.skipSpace();
				_base.readWord();
				if(!_base.bufferMatch("cnf"))
					throw std::runtime_error("Illegal cnf file");
				
				// read the number of vars and clauses
				_base.skipSpace();
				_base.readWord();
				int num_vars = _base.bufferGetInt();
				
				_base.skipSpace();
				_base.readWord();
				int num_clauses = _base.bufferGetInt();

				handleProblem(num_vars, num_clauses);

				_base.skipSpace();
				_base.forceBreakOrEnd();
			}else{
				// the line contains a clause
				std::vector<long> lits;
				while(true) {
					int lit = _base.bufferGetInt();
					if(lit == 0) {
						_base.skipSpace();
						_base.forceBreakOrEnd();
						break;
					}
					lits.push_back(lit);
					_base.skipSpaceOrBreak();
					_base.readWord();
				}
				if(lits.size() == 0)
					throw std::runtime_error("File contains empty clause");
				
				handleClause(lits);
			}
		}
	}
	
private:
	void handleProblem(long num_vars, long num_clauses) {
		_varSpace->reserveVars(num_vars);
		for(long i = 0; i < num_vars; ++i)	
			_varSpace->allocVar();
	}

	void handleClause(std::vector<long> &numbers) {
		// transform input variable names to internal variables
		std::vector<LiteralIdType> literals;
		for(auto it = numbers.begin(); it != numbers.end(); ++it) {
			long name = *it < 0 ? -(*it) : *it;
			
			auto var = VariableIdType::fromNumber(name);
			literals.push_back(*it > 0 ? var.positive() : var.negative());
		}
		
		// permutate the input clause
		//std::shuffle(literals.begin(), literals.end(),
		//		p_config.p_rndEngine);
		
		ClauseRefType clause = _clauseSpace->allocate({ 0, _clauseNumber }, literals.size(),
				literals.begin(), literals.end(), ClauseAllocation::permanent);
		clause.markAsEssential();
		_clauseNumber++;
	}

	VariableSpaceType *_varSpace;
	ClauseSpaceType *_clauseSpace;
	size_t _clauseNumber;
	
	BaseParser _base;
};

} } // namespace satuzk::cdcl

