
namespace satuzk {

struct SubsumeStats {
	uint64_t resShortcuts;
	uint64_t resChecks;
	uint64_t resExpensiveChecks;
	uint64_t resFacts;
	uint64_t resClauses;
	uint64_t subClauses;
	uint64_t ops;
	std::chrono::nanoseconds time;

	inline SubsumeStats() : resShortcuts(0), resChecks(0), resExpensiveChecks(0),
			resFacts(0), resClauses(0), subClauses(0), ops(0), time(0) { }
	
	inline SubsumeStats &operator+= (const SubsumeStats &other) {
		resShortcuts += other.resShortcuts;
		resChecks += other.resChecks;
		resExpensiveChecks += other.resExpensiveChecks;
		resFacts += other.resFacts;
		resClauses += other.resClauses;
		subClauses += other.subClauses;
		ops += other.ops;
		time += other.time;
		return *this;
	}
};

} // namespace satuzk

