
#ifndef SATUZK_DISTRIBUTED_COMMON_HPP
#define SATUZK_DISTRIBUTED_COMMON_HPP

namespace satuzk {
namespace distributed {

template<typename Iterator>
auto splitWork(Iterator begin, Iterator end, int num_workers, int worker_rank) {
	struct Range {
		Range(Iterator reference, size_t start, size_t count)
		: _reference(reference), _start(start), _count(count) { }

		Iterator begin() {
			return std::next(_reference, _start);
		}
		Iterator end() {
			return std::next(_reference, _start + _count);
		}
	
	private:
		Iterator _reference;
		size_t _start;
		size_t _count;
	};

	size_t overall_size = std::distance(begin, end);
	size_t small_part = overall_size / num_workers;
	size_t large_part = small_part + 1;
	size_t num_large = overall_size % num_workers;

	if(worker_rank < num_large) {
		return Range(begin, large_part * worker_rank, large_part);
	}else{
		return Range(begin, large_part * num_large
				+ small_part * (worker_rank - num_large), small_part);
	}
}

// --------------------------------------------------------
// Basic types extracted from policy tags
// --------------------------------------------------------

template<typename T>
struct UsePerSuiteData { };

// --------------------------------------------------------
// Forward declarations and normalized API types
// --------------------------------------------------------

template<typename... PT>
class SuiteStruct;

template<typename... PT>
class WorkerStruct;

template<typename... PT>
using PerSuiteData = ExtractType<UsePerSuiteData, PT...>;

template<typename... PT>
using Suite = SuiteStruct<>;

template<typename... PT>
using Worker = WorkerStruct<>;

} } // namespace satuzk::distributed

#endif // SATUZK_DISTRIBUTED_COMMON_HPP

