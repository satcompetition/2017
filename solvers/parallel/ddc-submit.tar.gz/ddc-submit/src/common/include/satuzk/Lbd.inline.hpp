
namespace satuzk {
namespace cdcl {

template<typename... PT, typename Iterator>
int computeGlobalLbd(Solver<PT...> &solver, Iterator begin, Iterator end) {

	solver.lbdInit();
	for(auto it = begin; it != end; ++it) {
		auto level = solver.assignment.level(it->variable());
		if(!level)
			continue;
		solver.lbdInsert(level);
	}
	for(auto it = begin; it != end; ++it) {
		auto level = solver.assignment.level(it->variable());
		if(!level)
			continue;
		solver.lbdCleanup(level);
	}
	return solver.lbdResult();
}

template<typename... PT, typename Iterator>
int computeLocalLbd(Solver<PT...> &solver, Iterator begin, Iterator end) {

	solver.lbdInit();
	for(auto it = begin; it != end; ++it) {
		auto level = solver.assignment.level(it->variable());
		if(level <= solver.trail.initialPoint())
			continue;
		solver.lbdInsert(level);
	}
	for(auto it = begin; it != end; ++it) {
		auto level = solver.assignment.level(it->variable());
		if(level <= solver.trail.initialPoint())
			continue;
		solver.lbdCleanup(level);
	}
	return solver.lbdResult();
}

} } // namespace satuzk::cdcl

