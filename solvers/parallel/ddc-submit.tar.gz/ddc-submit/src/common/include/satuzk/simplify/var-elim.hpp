
#include <experimental/optional>

namespace satuzk {
namespace simplify {

struct BveStats {
	uint64_t numFacts;
	uint64_t elimVars;
	uint64_t ops;
	std::chrono::nanoseconds time;

	inline BveStats() : numFacts(0), elimVars(0), ops(0), time(0) { }

	BveStats &operator+= (const BveStats &other) {
		numFacts += other.numFacts;
		elimVars += other.elimVars;
		ops += other.ops;
		time += other.time;
		return *this;
	}
};

struct BceStats {
	uint64_t elimClauses;
	std::chrono::nanoseconds time;

	BceStats()
	: elimClauses{0}, time{0} { }
};

template<typename... PT>
struct Polarity {
	typedef VariableRef<PT...> VariableRefType;
	
	Polarity() = delete;
	
	template<typename Iterator>
	static int find(Iterator begin, Iterator end, VariableRefType variable) {
		for(auto it = begin; it != end; ++it) {
			if(it->variable() == variable)
				return it->polarity();
		}
		return 0;
	}
};

template<typename... PT>
struct Resolution {
	typedef VariableSpace<PT...> VariableSpaceType;

	using LiteralIdType = typename VariableSpaceType::LiteralIdType;
	typedef VariableRef<PT...> VariableRefType;
	typedef LiteralRef<PT...> LiteralRefType;
	typedef ClauseRef<PT...> ClauseRefType;

	Resolution() = delete;

	// Returns true iff the resolvent is trivial.
	static bool trivial(ClauseRefType clause1, ClauseRefType clause2, VariableRefType variable) {
		// Prefer less iterations of the outer loop. This improves performance a lot.
		using std::swap;
		if(clause1.length() > clause2.length())
			swap(clause1, clause2);

		for(auto it = clause1.beginLits(); it != clause1.endLits(); ++it) {
			if(it->variable() == variable)
				continue;

			auto s = uint64_t(1) << (it->variable().getIndex() % 64);
			if(!(clause2.signature() & s))
				continue;

			int polarity1 = it->polarity();
			int polarity2 = Polarity<PT...>::find(clause2.beginLits(), clause2.endLits(), it->variable());
			if(polarity1 == -polarity2)
				return true;
		}
		return false;
	}
	
	// Returns the length of the resolvent if it is not trivial.
	static std::experimental::optional<size_t> length(ClauseRefType clause1, ClauseRefType clause2,
			VariableRefType variable) {
		assert(clause1.length());
		assert(clause2.length());
		size_t length = clause1.length() + clause2.length() - 2;
		for(auto it = clause1.beginLits(); it != clause1.beginLits(); ++it) {
			if(it->variable() == variable)
				continue;

			int polarity1 = it->polarity();
			int polarity2 = Polarity<PT...>::find(clause2.beginLits(), clause2.endLits(), it->variable());
			if(polarity1 == -polarity2)
				return std::experimental::nullopt;
			if(polarity1 == polarity2)
				length--;
		}
		return length;
	}

	// Builds the resolvent of the two given clauses.
	static void build(ClauseRefType clause1, ClauseRefType clause2,
			VariableRefType variable, std::vector<LiteralIdType> &result) {
		for(auto it = clause1.beginLits(); it != clause1.endLits(); ++it) {
			if(it->variable() == variable)
				continue;
			result.push_back(it->id());
		}
		for(auto it = clause2.beginLits(); it != clause2.endLits(); ++it) {
			if(it->variable() == variable)
				continue;
			if(std::find(clause1.beginLits(), clause1.endLits(), *it) != clause1.endLits())
				continue;
			result.push_back(it->id());
		}
	}
};

template<typename... PT>
struct VarElim {
	typedef VariableSpace<PT...> VariableSpaceType;
	typedef ClauseSpace<PT...> ClauseSpaceType;
	typedef Occlists<PT...> OcclistsType;
	typedef ClauseNameAllocator<PT...> ClauseNameAllocatorType;
	typedef EliminationStack<PT...> EliminationStackType;
	typedef ProofHandler<PT...> ProofHandlerType;

	using LiteralIdType = typename VariableSpaceType::LiteralIdType;
	typedef VariableRef<PT...> VariableRefType;
	typedef LiteralRef<PT...> LiteralRefType;
	typedef ClauseRef<PT...> ClauseRefType;

	VarElim(EliminationStackType *elim_stack, ProofHandlerType proof_handler)
	: _eliminationStack{elim_stack}, _proofHandler{std::move(proof_handler)} { }

	bool isBlockingLiteral(OcclistsType &occlists, ClauseRefType clause, LiteralRefType literal) {
		auto inverse = literal.inverse();
		for(auto cit = occlists.begin(inverse.id()); cit != occlists.end(inverse.id()); ++cit) {
			if(!cit->isPresent())
				continue;
			if(!Resolution<PT...>::trivial(clause, *cit, literal.variable()))
				return false;
		}
		return true;
	}

	LiteralRefType findBlockingLiteral(OcclistsType &occlists, ClauseRefType clause) {
		for(auto it = clause.beginLits(); it != clause.endLits(); ++it)
			if(isBlockingLiteral(occlists, clause, *it))
				return *it;
		return LiteralRefType{};
	}

	template<typename S>
	void bceSingle(S &queue, OcclistsType &occlists, ClauseRefType clause, BceStats &stats) {
		if(!clause.isPresent())
			return;
		if(clause.length() <= 1)
			return;

		auto literal = findBlockingLiteral(occlists, clause);
		if(!literal)
			return;
		
		_eliminationStack->pushBlockedClause(clause, literal.id());

		for(auto it = clause.beginLits(); it != clause.endLits(); ++it)
			queue.touch(it->variable());

		_proofHandler.reduce(clause);
		clause.forceErase();
		stats.elimClauses++;
	}

	template<typename S, typename Iterator>
	void bceAll(S &queue, Iterator begin, Iterator end, OcclistsType &occlists, BceStats &stats) {
		auto start = sys::ThreadClock::now();

		for(auto cit = begin; cit != end; ++cit)
			bceSingle(queue, occlists, *cit, stats);

		stats.time += sys::ThreadClock::now() - start;
	}

	bool isWorthwhile(ClauseSpaceType &clause_space, OcclistsType &occlists,
			VariableRefType variable, BveStats &stats) {
		size_t resolvents = 0;
		size_t ncount = 0;
		size_t pcount = 0;
		
		LiteralRefType positive = variable.positive();
		LiteralRefType negative = variable.negative();
		
		// Count original clauses.
		bool occurs_as_unit = false;
		for(auto it = occlists.begin(positive.id()); it != occlists.end(positive.id()); ++it) {
			if(it->isPresent())
				pcount++;
			if(it->length() == 1)
				occurs_as_unit = true;
		}
		for(auto it = occlists.begin(negative.id()); it != occlists.end(negative.id()); ++it) {
			if(it->isPresent())
				ncount++;
			if(it->length() == 1)
				occurs_as_unit = true;
		}

		// Eliminate units via a separate preprocessing pass.
		if(occurs_as_unit)
			return false;

		// Satelite uses this cut-off heuristic.
		if(ncount >= 8 || pcount >= 8)
			return false;

		// Count resolvents.
		for(auto pit = occlists.begin(positive.id()); pit != occlists.end(positive.id()); ++pit) {
			if(!pit->isPresent())
				continue;
			for(auto nit = occlists.begin(negative.id()); nit != occlists.end(negative.id()); ++nit) {
				if(!nit->isPresent())
					continue;

				stats.ops++;

				auto res_length = Resolution<PT...>::length(*nit, *pit, variable);
				if(!res_length)
					continue;
				if(*res_length > 30)
					return false;

				resolvents++;
				if(resolvents > pcount + ncount)
					return false;
			}
		}
		return true;
	}

	template<typename S>
	void eliminateVariable(S &queue, ClauseSpaceType &clause_space, OcclistsType &occlists,
			VariableRefType variable, ClauseNameAllocatorType &name_alloc, BveStats &stats) {
		assert(variable.isPresent());
		_eliminationStack->pushVariableResolution(variable, &occlists);

		LiteralRefType positive = variable.positive();
		LiteralRefType negative = variable.negative();
		
		std::vector<LiteralIdType> resolvent;

		// Build all resolvents.
		auto pend = occlists.end(positive.id());
		auto nend = occlists.end(negative.id());
		for(auto pit = occlists.begin(positive.id()); pit != pend; ++pit) {
			if(!pit->isPresent())
				continue;
			for(auto nit = occlists.begin(negative.id()); nit != nend; ++nit) {
				if(!nit->isPresent())
					continue;

				if(Resolution<PT...>::trivial(*pit, *nit, variable))
					continue;

				resolvent.clear();
				Resolution<PT...>::build(*pit, *nit, variable, resolvent);
				auto vit = std::find_if(resolvent.begin(), resolvent.end(), [&] (LiteralIdType literal) {
					return literal.variable() == variable.id();
				});	
				assert(vit == resolvent.end());

				auto res_clause = clause_space.allocate(name_alloc.allocate(),
						resolvent.size(), resolvent.begin(), resolvent.end());
				if(pit->isEssential() || nit->isEssential())
					res_clause.markAsEssential();
//FIXME				solver.clauseSpace.setFlagCreatedVecd(res_clause);
				_proofHandler.emit(res_clause);

				queue.markNewClause(res_clause);

				if(resolvent.size() == 1)
					stats.numFacts++;
			}
		}

		constexpr bool touchSiblings = false;

		// Delete all clauses containing the variable. We do this in a second loop
		// to catch the case where one of the occlists is empty.
		for(auto cit = occlists.begin(positive.id()); cit != pend; ++cit) {
			if(!cit->isPresent())
				continue;

			if(touchSiblings)
				for(auto it = cit->beginLits(); it != cit->endLits(); ++it)
					queue.touch(it->variable());

			_proofHandler.reduce(*cit);
			cit->forceErase();
		}
		for(auto cit = occlists.begin(negative.id()); cit != nend; ++cit) {
			if(!cit->isPresent())
				continue;

			if(touchSiblings)
				for(auto it = cit->beginLits(); it != cit->endLits(); ++it)
					queue.touch(it->variable());

			_proofHandler.reduce(*cit);
			cit->forceErase();
		}

//FIXME: uncomment after refactoring blocked clause elimination
//		for(auto i = queued_for_install.begin(); i != queued_for_install.end(); ++i) {
//			if(!solver.clauseIsPresent(*i))
//				continue;
//			if(solver.clauseLength(*i) <= 2)
//				continue;
//			bceEliminateSingle(solver, *i, solver.stat.simp.bce);
//		}

		variable.erase();
		stats.elimVars++;
	}
	
	template<typename S>
	void processSingle(S &queue, ClauseSpaceType &clause_space, OcclistsType &occlists,
			VariableRefType variable, ClauseNameAllocatorType &name_alloc, BveStats &stats) {
		if(!variable.isPresent())
			return;
		if(variable.isProtected())
			return;

		if(isWorthwhile(clause_space, occlists, variable, stats))
			eliminateVariable(queue, clause_space, occlists, variable, name_alloc, stats);
	}

	template<typename S>
	void processAll(S &queue, VariableSpaceType &var_space, ClauseSpaceType &clause_space,
			OcclistsType &occlists, ClauseNameAllocatorType &name_alloc, BveStats &stats) {
		auto start = sys::ThreadClock::now();

		std::vector<VariableRefType> pq;
		for(auto it = var_space.begin(); it != var_space.end(); ++it) {
			if((*it).isPresent())
				pq.push_back(*it);
		}

		std::sort(pq.begin(), pq.end(), [&] (VariableRefType a, VariableRefType b) {
			return occlists.size(a.positive().id()) * occlists.size(a.negative().id())
					< occlists.size(b.positive().id()) * occlists.size(b.negative().id());
		});

		for(auto it = pq.begin(); it != pq.end(); ++it)
			processSingle(queue, clause_space, occlists, *it, name_alloc, stats);

		stats.time += sys::ThreadClock::now() - start;
	}

	template<typename S>
	void processQueue(S &queue, ClauseSpaceType &clause_space,
			OcclistsType &occlists, ClauseNameAllocatorType &name_alloc, BveStats &stats) {
		auto start = sys::ThreadClock::now();

		for(auto it = queue.beginVars(); it != queue.endVars(); ++it)
			processSingle(queue, clause_space, occlists, *it, name_alloc, stats);

		stats.time += sys::ThreadClock::now() - start;
	}

private:
	EliminationStackType *_eliminationStack;
	ProofHandlerType _proofHandler;
};

} } // namespace satuzk::simplify

