
#include <tuple>

namespace satuzk {
namespace cdcl {

typedef int64_t LookaheadValue;

enum LookaheadResult {
	kResNone = 0,
	kResOkay = 1,
	kResFailedLiteral = 3,
	kResFormulaUnsat = 4,
	kResFailedAssumption = 5,
};

template<typename... PT>
struct Lookahead {
	typedef VariableSpace<PT...> VariableSpaceType;
	typedef typename VariableSpaceType::VariableRef VariableRefType;
	typedef typename VariableSpaceType::LiteralIdType LiteralIdType;
	typedef typename VariableSpaceType::LiteralRef LiteralRefType;
	
	typedef ClauseRef<PT...> ClauseRefType;
	
	typedef TrailIndex<PT...> TrailIndexType;
	
	typedef Antecedent<PT...> AntecedentType;
	typedef Occlists<PT...> OcclistsType;
	typedef Assignment<PT...> AssignmentType;
	typedef Trail<PT...> TrailType;
	
	typedef Solver<PT...> SolverType;

	Lookahead() = delete;

	static std::vector<VariableRefType> preselect(VariableSpaceType &var_space,
			OcclistsType &occlists, AssignmentType &assignment) {
		std::vector<VariableRefType> result;

		for(auto it = var_space.begin(); it != var_space.end(); ++it) {
			if(!it->isPresent())
				continue;
			if(assignment.isAssigned(it->id()))
				continue;
			result.push_back(*it);
		}
		
		auto comparator = [&occlists] (VariableRefType a, VariableRefType b) -> bool {
			size_t score_a = occlists.size(a.positive().id())
					* occlists.size(a.negative().id());
			size_t score_b = occlists.size(b.positive().id())
					* occlists.size(b.negative().id());
			return score_a > score_b;
		};
		std::sort(result.begin(), result.end(), comparator);

		if(result.size() < 10000)
			return result;
		result.erase(result.begin() + 10000, result.end());	
		return result;
	}

	// precondition: literal is assigned to false and part of clause
	// only counts the clause if literal is the first false literal from this declevel!
	static bool isTouched(LiteralRefType literal, ClauseRefType clause,
			AssignmentType &assignment, TrailType &trail) {
		bool seen = false;
		for(auto it = clause.beginLits(); it != clause.endLits(); ++it) {
			if(*it == literal) {
				seen = true;
				continue;
			}

			if(assignment.isTrue(*it))
				return false;
			if(!seen && assignment.isFalse(*it)
					&& assignment.level(it->variable()) == trail.currentLevel())
				return false;
		}
		return true;
	}

	static LookaheadValue evaluate(OcclistsType &occlists, AssignmentType &assignment,
			TrailType &trail) {
		return trail.trailLength() - trail.indexOfLevel(trail.currentLevel());
/*
		LookaheadValue value = 0;
		for(TrailIndexType index = trail.indexOfLevel(trail.currentLevel());
				index < trail.trailLength(); index++) {
			LiteralRefType literal = trail.atomAt(index);

			for(auto it = occlists.begin(literal.inverse().id());
					it != occlists.end(literal.inverse().id()); ++it) {
				if(!it->isEssential())
					continue;
				if(isTouched(literal.inverse(), *it, assignment, trail))
					value++;
			}
		}
		return value;
*/
	}

	static std::tuple<LookaheadResult, ClauseRefType, LookaheadValue> lookaheadSingle(LiteralRefType literal,
			SolverType &solver, OcclistsType &occlists, AssignmentType &assignment,
			TrailType &trail) {
		assert(trail.currentLevel() == trail.initialPoint());
		assert(!trail.conflict());
		assert(!assignment.isAssigned(literal.variable().id()));
		
		trail.beginLevel();
		trail.enqueue(literal, AntecedentType::makeInitial());
		trail.propagate();

		if(trail.conflict()) {
			if(solver.isResolveable()) {
				std::vector<LiteralIdType> lits;
				lits.push_back(literal.inverse().id());
				for(auto assumption : findFailedAssumptions(solver))
					lits.push_back(assumption.inverse());

				// Reorder the learned clause so that its watched literals are correct.
				if(lits.size() > 1) {
					auto c = [&] (auto a, auto b) {
						return assignment.level(a.variable()) < assignment.level(b.variable());
					};
					auto it = std::max_element(std::next(lits.begin()), lits.end(), c);
					std::iter_swap(std::next(lits.begin()), it);
				}

				auto lbd = computeGlobalLbd(solver, lits.begin(), lits.end());
				solver.resolveToLearn(lits.size(), lits.begin(), lits.end());

				assert(!assignment.isAssigned(literal.variable()));
				for(auto it = lits.begin() + 1; it != lits.end(); ++it)
					assert(assignment.isFalse(*it));

				auto learned = solver.clauseSpace.allocate(solver.uniqueClauseName(),
						lits.size(), lits.begin(), lits.end());
				learned.updateLbd(lbd);

				solver.enqueueAfterLearning(learned);
				trail.repropagate();
			}

			// If the conflict is not resolved now, it is unresolvable.
			if(trail.conflict()) {
				assert(!solver.isResolveable());
				if(solver.isUnsatisfiable()) {
					return std::make_tuple(kResFormulaUnsat, ClauseRefType{}, 0);
				}else{
					assert(solver.isFailedAssumption());
					return std::make_tuple(kResFailedAssumption, ClauseRefType{}, 0);
				}
			}

			// Learned clauses assign the literal to false now.
			assert(trail.currentLevel() == trail.initialPoint());
			assert(assignment.isFalse(literal));

			auto antecedent = solver.varAntecedent(literal.variable().id());
			auto clause = ClauseRefType{solver.clauseSpace, antecedent.getClause()};
			return std::make_tuple(kResFailedLiteral, clause, 0);
		}

		LookaheadValue value = evaluate(occlists, assignment, trail);
		trail.backtrackLevel();
		return std::make_tuple(kResOkay, ClauseRefType{}, value);
	}

	static std::tuple<LookaheadResult, LiteralRefType, ClauseRefType, LookaheadValue>
	lookaheadVar(VariableRefType var, SolverType &solver,
			OcclistsType &occlists, AssignmentType &assignment, TrailType &trail) {
		assert(var.isPresent());

		// lookahead inside the positive branch
		auto pos = lookaheadSingle(var.positive(), solver, occlists, assignment, trail);
		if(std::get<0>(pos) == kResFormulaUnsat || std::get<0>(pos) == kResFailedAssumption
				|| std::get<0>(pos) == kResFailedLiteral)
			return std::make_tuple(std::get<0>(pos), var.positive(), std::get<1>(pos), 0);
		assert(std::get<0>(pos) == kResOkay);

		// lookahead inside the negative branch
		auto neg = lookaheadSingle(var.negative(), solver, occlists, assignment, trail);
		if(std::get<0>(neg) == kResFormulaUnsat || std::get<0>(neg) == kResFailedAssumption
				|| std::get<0>(neg) == kResFailedLiteral)
			return std::make_tuple(std::get<0>(neg), var.negative(), std::get<1>(neg), 0);
		assert(std::get<0>(neg) == kResOkay);

		// combine both lookahead to a single score
		LookaheadValue mixed = std::get<2>(pos) * std::get<2>(neg);
		auto better = std::get<2>(pos) > std::get<2>(neg) ? var.positive() : var.negative();
		return std::make_tuple(kResOkay, better, ClauseRefType{}, mixed);
	}

	static LookaheadResult lookaheadAll(const std::vector<VariableRefType> &selected,
			SolverType &solver,
			OcclistsType &occlists, AssignmentType &assignment, TrailType &trail,
			std::vector<std::pair<LiteralRefType, LookaheadValue>> &values,
			std::vector<LiteralRefType> &failed) {
		for(auto it = selected.begin(); it != selected.end(); ++it) {
			if(!it->isPresent())
				continue;
			if(assignment.isAssigned((*it).id()))
				continue;

			auto result = lookaheadVar(*it, solver, occlists, assignment, trail);
			if(std::get<0>(result) == kResFormulaUnsat
					|| std::get<0>(result) == kResFailedAssumption)
				return std::get<0>(result);

			if(std::get<0>(result) == kResFailedLiteral) {
				failed.push_back(std::get<1>(result));
				continue;
			}
			assert(std::get<0>(result) == kResOkay);
			
			values.push_back(std::make_pair(std::get<1>(result), std::get<2>(result)));
		}

		auto comparator = [] (std::pair<LiteralRefType, LookaheadValue> a,
					std::pair<LiteralRefType, LookaheadValue> b) {
			return a.second > b.second;
		};
		std::sort(values.begin(), values.end(), comparator);

		return kResOkay;
	}
};

} } // namespace satuzk::cdcl

