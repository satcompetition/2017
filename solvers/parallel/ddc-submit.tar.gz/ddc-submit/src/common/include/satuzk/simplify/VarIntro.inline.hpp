
namespace satuzk {

template<typename Solver>
bool bvaEqualToUnion(Solver &solver,
		typename Solver::Clause clause,
		const std::vector<typename Solver::Literal> &set1,
		const std::vector<typename Solver::Literal> &set2) {
	if(solver.clauseLength(clause) > set1.size() + set2.size())
		return false;

	for(auto it = solver.clauseBegin(clause); it != solver.clauseEnd(clause); ++it)
		if(std::find(set1.begin(), set1.end(), *it) == set1.end()
				&& std::find(set2.begin(), set2.end(), *it) == set2.end())
			return false;
	for(auto it = set1.begin(); it != set1.end(); ++it)
		if(!solver.clauseContains(clause, *it))
			return false;
	for(auto it = set2.begin(); it != set2.end(); ++it)
		if(!solver.clauseContains(clause, *it))
			return false;
	return true;
}

template<typename Solver>
typename Solver::Clause bvaFindUnion(Solver &solver,
		const std::vector<typename Solver::Literal> &set1,
		const std::vector<typename Solver::Literal> &set2) {
	assert(set1.size() > 0);
	assert(set2.size() > 0);
	typename Solver::Literal literal = bvaShortestOcclist(solver, set1.begin(), set1.end());
	for(auto cp = solver.occurBegin(literal); cp != solver.occurEnd(literal); ++cp) {
		if(!solver.clauseIsPresent(*cp))
			continue;
		
		if(bvaEqualToUnion(solver, *cp, set1, set2))
			return *cp;
	}
	
	return Solver::Clause::illegalClause();
}

// check if a clause contains a certain set of literals
template<typename Solver>
bool bvaClauseContainsSet(Solver &solver,
		typename Solver::Clause clause,
		const std::vector<typename Solver::Literal> &prefix) {
	for(auto lp = prefix.begin(); lp != prefix.end(); lp++)
		if(!solver.clauseContains(clause, *lp))
			return false;
	return true;
}

// check if the formula contains all resolvents
template<typename Solver>
bool bvaExistsAll(Solver &solver,
		const std::vector<typename Solver::Literal> &prefix,
		const std::vector<std::vector<typename Solver::Literal>> &suffixes) {
	for(auto it = suffixes.begin(); it != suffixes.end(); ++it)
		if(bvaFindUnion(solver, prefix, *it) == Solver::Clause::illegalClause())
			return false;
	return true;
}

template<typename Solver>
bool bvaSortedSetsEqual(const std::vector<typename Solver::Literal> &set1,
		const std::vector<typename Solver::Literal> &set2) {
	if(set1.size() != set2.size())
		return false;
	for(size_t i = 0; i < set1.size(); i++)
		if(set1[i] != set2[i])
			return false;
	return true;
}

template<typename Solver>
bool bvaCollectionContains(const std::vector<std::vector<typename Solver::Literal>> &collection,
		const std::vector<typename Solver::Literal> &set) {
	for(auto it = collection.begin(); it != collection.end(); ++it)
		if(bvaSortedSetsEqual<Solver>(set, *it))
			return true;
	return false;
}

template<typename Solver, typename Iterator>
typename Solver::Literal bvaShortestOcclist(Solver &solver,
		Iterator begin, Iterator end) {
	size_t best_length = solver.occurSize(*begin);
	typename Solver::Literal best_literal = *begin;

	auto it = begin;
	for(++it; it != end; ++it) {
		if(solver.occurSize(*it) < best_length) {
			best_length = solver.occurSize(*it);
			best_literal = *it;
		}
	}
	
	return best_literal;
}

template<typename Solver>
void bvaExtend(Solver &solver,
		const std::vector<typename Solver::Literal> &prefix,
		const std::vector<std::vector<typename Solver::Literal>> &prefix_collection,
		std::vector<std::vector<typename Solver::Literal>> &out_collection,
		std::vector<typename Solver::Clause> &resolvents,
		std::vector<typename Solver::Literal> &temp_suffix) {
	assert(prefix.size() > 0);
	
	typename Solver::Literal literal = bvaShortestOcclist(solver,
			prefix.begin(), prefix.end());
	for(auto cp = solver.occurBegin(literal); cp != solver.occurEnd(literal); ++cp) {
		if(!bvaClauseContainsSet(solver, *cp, prefix))
			continue;
		
		temp_suffix.clear();
		for(auto lp = solver.clauseBegin(*cp); lp != solver.clauseEnd(*cp); ++lp) {
			solver.perf.bvaOps += prefix.size();

			if(std::find(prefix.begin(), prefix.end(), *lp) == prefix.end())
				temp_suffix.push_back(*lp);
		}
		if(temp_suffix.size() == 0)
			continue;
		std::sort(temp_suffix.begin(), temp_suffix.end());

		if(bvaCollectionContains<Solver>(out_collection, temp_suffix))
			continue;
		
		if(bvaExistsAll(solver, temp_suffix, prefix_collection)) {
			out_collection.push_back(temp_suffix);
		}
	}
}

template<typename Solver>
void bvaCheckClause(Solver &solver, typename Solver::Clause clause) {
	std::vector<typename Solver::Literal> prefix;
		
	std::vector<typename Solver::Literal> suffix1;
	std::vector<typename Solver::Literal> suffix2;
	std::vector<typename Solver::Literal> temp_suffix;
	
	std::vector<std::vector<typename Solver::Literal>> collection1;
	std::vector<std::vector<typename Solver::Literal>> collection2;
	
	std::vector<typename Solver::Clause> resolvents;

	typename Solver::Literal literal = bvaShortestOcclist(solver,
			solver.clauseBegin(clause), solver.clauseEnd(clause));
	for(auto cp = solver.occurBegin(literal); cp != solver.occurEnd(literal); ++cp) {
		if(!solver.clauseIsPresent(*cp))
			continue;

		prefix.clear();
		suffix1.clear();
		suffix2.clear();

		// determine the common prefix (= common literals) of clause and *cp,
		// put all literals in *cp but not in clause into suffix1,
		// put all literals in clause but not in *cp into suffix2
		for(auto lp = solver.clauseBegin(*cp); lp != solver.clauseEnd(*cp); ++lp) {
			solver.perf.bvaOps += solver.clauseLength(clause);

			if(solver.clauseContains(clause, *lp)) {
				prefix.push_back(*lp);
			}else suffix1.push_back(*lp);
		}
		assert(prefix.size() > 0);
		
		if(suffix1.size() == 0)
			continue;

		std::sort(prefix.begin(), prefix.end());
		std::sort(suffix1.begin(), suffix1.end());
		
		for(auto lp = solver.clauseBegin(clause); lp != solver.clauseEnd(clause); ++lp) {
			solver.perf.bvaOps += prefix.size();

			if(std::find(prefix.begin(), prefix.end(), *lp) == prefix.end())
				suffix2.push_back(*lp);
		}
		if(suffix2.size() == 0)
			continue;
		
		std::sort(suffix2.begin(), suffix2.end());
		
		resolvents.clear();
		resolvents.push_back(clause);
		resolvents.push_back(*cp);
		
		// we maintain the following invariant: if c is in collection1
		// and c' is in collection2 then c + c' is a clause of the formula
		collection1.clear();
		collection1.push_back(prefix);
		
		collection2.clear();
		collection2.push_back(suffix1);
		collection2.push_back(suffix2);
		
		size_t s = 0;
		size_t t = 0;
		
		// extend the collections until we reach a fixed point
		while(s < collection1.size() && t < collection2.size()) {
			if(t < collection2.size()) {
				const std::vector<typename Solver::Literal> &prefix = collection2[t];
				bvaExtend(solver, prefix, collection2, collection1, resolvents, temp_suffix);
				t++;
			}
			if(s < collection1.size()) {
				const std::vector<typename Solver::Literal> &prefix = collection1[s];
				bvaExtend(solver, prefix, collection1, collection2, resolvents, temp_suffix);
				s++;
			}
		}
		
		for(auto it1 = collection1.begin(); it1 != collection1.end(); ++it1) {
			for(auto it2 = collection2.begin(); it2 != collection2.end(); ++it2) {
				typename Solver::Clause resolvent = bvaFindUnion(solver, *it1, *it2);
				assert(resolvent != Solver::Clause::illegalClause());
				if(std::find(resolvents.begin(), resolvents.end(), resolvent)
						== resolvents.end())
					resolvents.push_back(resolvent);
			}
		}
		
		if(resolvents.size() <= collection1.size() + collection2.size())
			continue;

		typename Solver::Variable var = solver.varAlloc();
		
		for(auto it = collection1.begin(); it != collection1.end(); ++it) {
			std::vector<typename Solver::Literal> &lits = *it;
			lits.push_back(var.oneLiteral());

			typename Solver::Clause res_clause = solver.allocClause(lits.size(), lits.begin(), lits.end());
			solver.clauseSetEssential(res_clause);
			solver.installClause(res_clause);
		}
		
		for(auto it = collection2.begin(); it != collection2.end(); ++it) {
			std::vector<typename Solver::Literal> &lits = *it;
			lits.push_back(var.zeroLiteral());

			typename Solver::Clause res_clause = solver.allocClause(lits.size(), lits.begin(), lits.end());
			solver.clauseSetEssential(res_clause);
			solver.installClause(res_clause);
		}

		for(auto it = resolvents.begin(); it != resolvents.end(); ++it) {
			if(solver.clauseIsEssential(*it))
				solver.clauseUnsetEssential(*it);
			if(solver.clauseIsInstalled(*it))
				solver.uninstallClause(*it);
			solver.deleteClause(*it);
		}

		solver.stat.simp.bvaNewVars++;
		solver.stat.simp.bvaRemovedClauses += resolvents.size()
				- collection1.size() - collection2.size();

		return;
	}
}

template<typename Solver>
void bvaEliminateAll(Solver &solver) {
	auto start_time = sys::hptCurrent();

	std::vector<typename Solver::Clause> queue;
	for(auto it = solver.clausesBegin(); it != solver.clausesEnd(); ++it)
		queue.push_back(*it);
	for(auto it = queue.begin(); it != queue.end(); ++it) {
		if(!solver.clauseIsPresent(*it))
			continue;
		bvaCheckClause(solver, *it);
	}

	solver.perf.bvaTime += sys::hptElapsed(start_time);
}

} // namespace satuzk

