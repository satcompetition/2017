
#include <utility>
#include <unordered_map>

#include <mpi.h>

#include <satuzk/distributed/common.hpp>

namespace satuzk {
namespace distributed {

static constexpr int kNoRank = -1;
static constexpr int kIllegalId = -1;

struct WorkerId {
	WorkerId()
	: rank(-1), index(-1) { }

	explicit WorkerId(int rank, int index)
	: rank(rank), index(index) { }

	bool operator== (const WorkerId &other) const {
		return rank == other.rank && index == other.index;
	}

	int rank;
	int index;
};

struct IdHash {
	size_t operator() (WorkerId id) const {
		return size_t(id.rank) * 47 + size_t(id.index);
	}
};


} } // namespace satuzk::distributed

namespace satuzk {
namespace distributed {

template<typename... PT>
struct SuiteStruct {
	using WorkerType = Worker<PT...>;

	SuiteStruct(int rank)
	: _rank(rank), _nextIndex(1) { }

	// prevent copy-construction and assignment of this class
	SuiteStruct(const SuiteStruct &) = delete;
	SuiteStruct(SuiteStruct &&) = delete;
	SuiteStruct &operator= (SuiteStruct) = delete;

	WorkerType &createWorker(MPI_Comm communicator) {
		WorkerId id(_rank, _nextIndex++);
		auto inserted = _workers.emplace(id, std::make_unique<WorkerType>(*this, id, communicator));
		assert(inserted.second);
		return *inserted.first->second;
	}

private:
	const int _rank;

	// next index that will be assigned to a worker
	int _nextIndex;

	std::unordered_map<
		WorkerId,
		std::unique_ptr<WorkerType>,
		IdHash
	> _workers;
};

} } // namespace satuzk::distributed

