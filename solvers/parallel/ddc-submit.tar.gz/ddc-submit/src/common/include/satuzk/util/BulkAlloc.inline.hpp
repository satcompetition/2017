
#include <assert.h>
#include <stddef.h>
#include <string.h>
#include <sys/mman.h>
#include <memory>

namespace util {
namespace memory {

template<typename T>
T align(T offset, size_t alignment) {
	return (offset + static_cast<T>(alignment - 1)) & ~static_cast<T>(alignment - 1);
}

class memory_arena {
private:
	static constexpr int align_shift = 12;

public:
	void swap(memory_arena &u, memory_arena &v) {
		using std::swap;
		swap(u._memory, v._memory);
		swap(u._offset, v._offset);
		swap(u._arena_size, v._arena_size);
		swap(u._arena_limit, v._arena_limit);
	}

	memory_arena()
	: _memory{nullptr}, _offset{0}, _arena_size{0}, _arena_limit{0} { };

	memory_arena(const memory_arena &) = delete;

	memory_arena(memory_arena &&other)
	: memory_arena{} {
		swap(*this, other);
	}

	~memory_arena() {
		_free();
	}

	memory_arena &operator= (memory_arena other) {
		swap(*this, other);
		return *this;
	}

	void alter(size_t new_limit) {
		assert(!_memory);
		_arena_limit = new_limit;
	}

	void *get(ptrdiff_t index = 0) {
		return reinterpret_cast<char *>(_memory) + index;
	}

	size_t space_limit() {
		return _arena_limit;
	}

	size_t reserved_space() {
		return _arena_size;
	}
	size_t used_space() {
		return _offset;
	}
	
	void reserve(size_t required_size, size_t desired_size) {
		assert(required_size <= desired_size);

		if(_offset + desired_size > _arena_size) {
			if(_arena_limit && _offset + required_size > _arena_limit)
				throw std::bad_alloc{};

			_grow(_offset + desired_size);
		}
	}

	ptrdiff_t allocate(size_t object_size, size_t alignment) {
		auto index = align(_offset, alignment);
		assert(index + object_size < _arena_size);
		_offset = index + object_size;
		return index;
	}

	ptrdiff_t reserve_and_allocate(size_t object_size, size_t alignment) {
		auto index = align(_offset, alignment);
		if(index + object_size > _arena_size) {
			if(_arena_limit && index + object_size > _arena_limit)
				throw std::bad_alloc{};

			_grow(2 * (index + object_size));
		}

		_offset = index + object_size;
		return index;
	}

private:
	void _grow(size_t requested_size) {
		assert(requested_size >= _offset);
		auto new_size = align(std::min(requested_size, _arena_limit),
				size_t(1) << align_shift);

		void *new_memory;
		if(!_memory) {
			new_memory = mmap(nullptr, new_size, PROT_READ | PROT_WRITE,
					MAP_PRIVATE | MAP_ANONYMOUS, -1, 0);
		}else{
			new_memory = mremap(_memory, _arena_size, new_size, MREMAP_MAYMOVE);
		}
		if(new_memory == reinterpret_cast<void *>(-1))
			throw std::bad_alloc{};

		_memory = new_memory;
		_arena_size = new_size;
	}

	void _free() {
		if(_memory)
			if(munmap(_memory, _arena_size)) {
				std::cerr << "Error in memory_arena: munmap() failed!" << std::endl;
				std::terminate();
			}
		_memory = nullptr;
		_offset = 0;
		_arena_size = 0;
	}

private:
	void *_memory;
	ptrdiff_t _offset;
	size_t _arena_size;
	size_t _arena_limit;
};

}}; /* namespace util::memory */

