
#include <mpicxx/fiber.hpp>
#include <satuzk/mpiutil.hpp>
#include <satuzk/distributed/suite.hpp>
#include <satuzk/distributed/worker.hpp>
#include <satuzk/distributed/balancer.hpp>

namespace satuzk {
namespace cdcl {

/*template<typename Defs>
class DistLitActivityLt {
public:
	DistLitActivityLt(Solver<Defs> &solver) : p_solver(solver) { }

	bool operator() (LiteralType<Defs> literal1,
			LiteralType<Defs> literal2) {
		auto var1 = literal1.variable();
		auto var2 = literal2.variable();
		if(p_solver.varGetActivity(var1) < p_solver.varGetActivity(var2))
			return true;
		return false;
	}

private:
	Solver<Defs> &p_solver;
};

template<typename Defs>
class DistClauseActivityLt {
public:
	DistClauseActivityLt(Solver<Defs> &solver) : p_solver(solver) { }
	
	bool operator() (ClauseType<Defs> clause1,
			ClauseType<Defs> clause2) {
		return p_solver.clause_get_activity(clause1)
				> p_solver.clause_get_activity(clause2);
	}

private:
	Solver<Defs> &p_solver;
};

template<typename Defs>
class DistClausesLt {
public:
	DistClausesLt(Solver<Defs> &solver) : p_solver(solver) { }

	float weight(ClauseType<Defs> clause) {
		float w = 0;
		for(auto i = p_solver.clauseBegin(clause); i != p_solver.clauseEnd(clause); ++i)
			w += p_solver.varGetActivity((*i).variable());
		w /= p_solver.clauseLength(clause);
		return w;
	}

	bool operator() (ClauseType<Defs> clause1,
			ClauseType<Defs> clause2) {
		return weight(clause1) > weight(clause2);
	}

private:
	Solver<Defs> &p_solver;
};*/

template<typename... PT>
struct Distillation {
	using LiteralIdType = LiteralId<PT...>;
	using LiteralRefType = LiteralRef<PT...>;
	using ClauseRefType = ClauseRef<PT...>;
	using AntecedentType = Antecedent<PT...>;
	using SolverType = Solver<PT...>;

	// Perform Asymmetric Tautology Elimination without introducing
	// learned clauses. This weakens UP strength.
	static constexpr bool aggressiveAte = false;

	enum Status {
		statusNull,
		statusTautology = 1,
		statusStrengthened = 2
	};

	struct Result {
		Result(ClauseRefType clause, unsigned int status, std::vector<LiteralIdType> resolvent)
		: clause{clause}, status{status}, resolvent{std::move(resolvent)} { }

		ClauseRefType clause;
		unsigned int status;
		std::vector<LiteralIdType> resolvent;
	};

	Distillation()
	: _currentStamp{1}, _nonEssentialArcs{false} { }

	Result distill(SolverType &solver, ClauseRefType clause, bool confluent) {
		assert(clause.isPresent());
		assert(clause.isEssential());

		assert(solver.trail.currentLevel() == 0);
		assert(!solver.trail.conflict());

		_stamps.resize(solver.varSpace.count());
		
		assert(_queue.empty());
		for(auto it = clause.beginLits(); it != clause.endLits(); ++it)
			_queue.push_back(*it);
//		DistLitActivityLt<Defs> order(solver);
//		std::sort(_queue.begin(), _queue.end(), order);
		std::shuffle(_queue.begin(), _queue.end(), _random);

		for(auto q_it = _queue.begin(); q_it != _queue.end(); ++q_it) {
			if(solver.assignment.isTrue(q_it->id())) {
				auto antecedent = solver.assignment.antecedent(q_it->variable().id());
				assert(!antecedent.isInitial());
				
				assert(_arcs.empty() && _initials.empty());
				_pushAntecedent(solver, antecedent);
				_traceLiterals(solver);

				// If the clause does not participate in the antecedent graph
				// we can just delete it from the formula because it is possible to
				// resolve another clause that subsumes this one.
				// If _initials.empty() this clause is satisfied by units alone.
				// Otherwise it might still make sense to add this
				// resolvent to the formula to improve unit propagation.
				// We do this until aggressiveAte is set.
//X				auto participates = _participates(clause);
//X				if(!confluent && (aggressiveAte || _initials.empty()) && !participates) {
//X					solver.trail.reset();
//X				
//X					clause.forceErase(true);
//X				
//X					solver.trail.start();	
//X					_clearGraph();
//X					_clearQueue();
//X					return Result(clause, kStatusRemoved, ClauseRefType());
//X				}

				assert(_resolvent.empty());
				_resolvent.insert(_resolvent.begin(), _initials.begin(), _initials.end());
				_resolvent.push_back(q_it->id());

				// This assumption is invalid if there are assumptions.
				assert(_resolvent.size() <= clause.length());

				bool subsumes = _resolventSubsumes(clause);
				if(subsumes && _resolvent.size() < clause.length()) {
//X					auto lbd = computeClauseLbd(solver, _resolvent.begin(), _resolvent.end());
					solver.trail.reset();

					// We generated a clause that is strictly smaller than the original one.
//X					ClauseRefType new_clause = solver.clauseSpace.allocate(solver.uniqueClauseName(),
//X							_resolvent.size(), _resolvent.begin(), _resolvent.end());
//X					new_clause.decreaseLbd(lbd);
//X					if(confluent || participates || _nonEssentialArcs) {
//X						new_clause.markAsEssential();
//X					}else{
//X						new_clause.markAsImportant();
//X					}
//X
//X					clause.forceErase(true);

					auto resolvent = _resolvent;
					solver.trail.start();
					_clearGraph();
					_clearQueue();
					return Result(clause, statusStrengthened, std::move(resolvent));
				}else if(!subsumes) {
					// TODO: It is not clear if/how this should be implemented at all.
					assert(!"Distillation with assumptions is untested");
				}

				_clearGraph();
			}else if(!solver.assignment.isFalse(q_it->id())) {
				// we could remove the literal from clause here.
				// but in this case we either assign all literals to false (and a conflict occurs)
				// or another literal in the clause must be true. these cases subsume this one
				// and allow us to infer potentially stronger information.

				// assign the it-th literal of the clause
				solver.trail.beginLevel();
				solver.trail.enqueue(q_it->inverse(), AntecedentType::makeInitial());
				solver.trail.propagate();

				if(solver.trail.conflict()) {
					for(auto c_it = solver.trail.conflict().begin(solver);
							c_it != solver.trail.conflict().end(solver); ++c_it)
						if(_stamps[c_it->variable().getIndex()] < _currentStamp)
							_pushLiteral(solver, LiteralRefType(solver.varSpace, *c_it));
					_traceLiterals(solver);

					assert(_resolvent.empty());
					_resolvent.insert(_resolvent.begin(), _initials.begin(), _initials.end());

					assert(_resolventSubsumes(clause));
//X					auto lbd = computeClauseLbd(solver, _resolvent.begin(), _resolvent.end());
					solver.trail.reset();

//X					ClauseRefType new_clause = solver.clauseSpace.allocate(solver.uniqueClauseName(),
//X							_resolvent.size(), _resolvent.begin(), _resolvent.end());
//X					new_clause.decreaseLbd(lbd);
//X					new_clause.markAsEssential();
//X
//X					clause.forceErase(true);

					auto resolvent = _resolvent;
					solver.trail.start();
					_clearGraph();
					_clearQueue();
					return Result(clause, statusStrengthened, std::move(resolvent));
				}
			}
		}
		
		solver.trail.backjump(0);
		_clearGraph();
		_clearQueue();
		return Result(clause, statusNull, {});
	}

private:
	void _pushLiteral(SolverType &solver, LiteralRefType literal) {
		assert(solver.assignment.isTrue(literal.id()));
		assert(_stamps[literal.variable().getIndex()] <= _currentStamp);
		if(_stamps[literal.variable().getIndex()] == _currentStamp)
			return;

		_stamps[literal.variable().getIndex()] = _currentStamp;
		_tracing.push_back(literal);
	}

	void _pushAntecedent(SolverType &solver, AntecedentType antecedent) {
		auto clause = ClauseRefType(solver.clauseSpace, antecedent.getClause());
		// TODO: Mark the arcs instead of walking the array.
		if(std::find(_arcs.begin(), _arcs.end(), clause) == _arcs.end())
			_arcs.push_back(clause);
		if(!clause.isEssential())
			_nonEssentialArcs = true;

		for(auto it = antecedent.begin(solver); it != antecedent.end(solver); ++it)
			_pushLiteral(solver, LiteralRefType(solver.varSpace, *it));
	}

	void _traceLiterals(SolverType &solver) {
		while(!_tracing.empty()) {
			auto current = _tracing.back();
			_tracing.pop_back();

			auto antecedent = solver.assignment.antecedent(current.variable().id());
			if(antecedent.isInitial()) {
				// TODO: Mark the initials instead of walking the array.
				if(std::find(_initials.begin(), _initials.end(), current.inverse().id()) == _initials.end())
					_initials.push_back(current.inverse().id());
			}else{
				_pushAntecedent(solver, antecedent);
			}
		}
	}

	bool _participates(ClauseRefType clause) {
		return std::find(_arcs.begin(), _arcs.end(), clause) != _arcs.end();
	}

	bool _resolventSubsumes(ClauseRefType clause) {
		for(auto it = _resolvent.begin(); it != _resolvent.end(); ++it) {
			auto p = [&] (LiteralRefType literal) {
				return literal.id() == *it;
			};
			if(std::find_if(clause.beginLits(), clause.endLits(), p) == clause.endLits())
				return false;
		}
		return true;
	}

	void _clearGraph() {
		if(_currentStamp < UINT8_MAX) {
			_currentStamp++;
		}else{
			std::fill(_stamps.begin(), _stamps.end(), 0);
			_currentStamp = 1;
		}
		_arcs.clear();
		_initials.clear();
		_resolvent.clear();
		_nonEssentialArcs = false;
	}

	void _clearQueue() {
		_queue.clear();
	}

private:
	std::mt19937 _random;
	std::vector<LiteralRefType> _queue;
	std::vector<uint8_t> _stamps;
	std::vector<LiteralRefType> _tracing;
	std::vector<ClauseRefType> _arcs;
	std::vector<LiteralIdType> _initials;
	std::vector<LiteralIdType> _resolvent;

	uint8_t _currentStamp;
	bool _nonEssentialArcs;
};

#define SATUZK_GOOD_ALLGATHER

template<typename... PT>
struct DistributedDistillation {
	using ClauseNameType = ClauseName<PT...>;
	using ClauseRefType = ClauseRef<PT...>;
	using LiteralIdType = LiteralId<PT...>;
	using LiteralRefType = LiteralRef<PT...>;
	using SolverType = Solver<PT...>;
	using DistillationType = Distillation<PT...>;

	template<typename T>
	static void allgather(const T *sendbuf, int sendcount, MPI_Datatype sendtype,
			T *recvbuf, int recvcount, MPI_Datatype recvtype, MPI_Comm comm,
			int self_index, int workers_per_node) {
		int num_nodes = mpiutil::Comm_size(comm);
		int self_rank = mpiutil::Comm_rank(comm);
		assert(sendcount == recvcount);
		assert(workers_per_node <= 16);

#ifdef SATUZK_GOOD_ALLGATHER
		// If we want to support a single worker we have to use something
		// like MPI_Sendrecv for the first odd/even cycle.
		assert(num_nodes || workers_per_node);
		int p_rank, p_index;
		int n_rank, n_index;
		if(self_index) {
			p_rank = self_rank;
			p_index = self_index - 1;
		}else if(self_rank) {
			p_rank = self_rank - 1;
			p_index = workers_per_node - 1;
		}else{
			p_rank = num_nodes - 1;
			p_index = workers_per_node - 1;
		}
		if(self_index < workers_per_node - 1) {
			n_rank = self_rank;
			n_index = self_index + 1;
		}else if(self_rank < num_nodes - 1) {
			n_rank = self_rank + 1;
			n_index = 0;
		}else{
			n_rank = 0;
			n_index = 0;
		}

		auto m = workers_per_node * num_nodes;
		auto s = self_rank * workers_per_node + self_index;
		auto even = !(s % 2);

		if(even) {
			MPI_Send(sendbuf, sendcount, sendtype, p_rank, p_index, comm);
			MPI_Recv(recvbuf + ((s + 1) % m) * recvcount, recvcount, recvtype,
					n_rank, self_index, comm, MPI_STATUS_IGNORE);
		}else{
			MPI_Recv(recvbuf + ((s + 1) % m) * recvcount, recvcount, recvtype,
					n_rank, self_index, comm, MPI_STATUS_IGNORE);
			MPI_Send(sendbuf, sendcount, sendtype, p_rank, p_index, comm);
		}
		s++;

		for(size_t i = 1; i < m; i++) {
			if(even) {
				MPI_Send(recvbuf + (s % m) * recvcount, recvcount, recvtype, p_rank, p_index, comm);
				MPI_Recv(recvbuf + ((s + 1) % m) * recvcount, recvcount, recvtype,
						n_rank, self_index, comm, MPI_STATUS_IGNORE);
			}else{
				MPI_Recv(recvbuf + ((s + 1) % m) * recvcount, recvcount, recvtype,
						n_rank, self_index, comm, MPI_STATUS_IGNORE);
				MPI_Send(recvbuf + (s % m) * recvcount, recvcount, recvtype, p_rank, p_index, comm);
			}
			s++;
		}
#else
		size_t disp = 0;
		for(int rank = 0; rank < num_nodes; rank++) {
			for(int index = 0; index < workers_per_node; index++) {
				if(rank == self_rank && index == self_index) {
					// It's our turn to send.
					for(int dest_rank = 0; dest_rank < num_nodes; dest_rank++) {
						for(int dest_index = 0; dest_index < workers_per_node; dest_index++) {
							if(dest_rank == self_rank && dest_index == self_index)
								continue;
							MPI_Send(sendbuf, sendcount, sendtype, dest_rank,
									(dest_index << 4) | self_index, comm);
						}
					}

					// We also need to copy to our own receive buffer.
					std::copy(sendbuf, sendbuf + sendcount, recvbuf + disp);
					disp += recvcount;
				}else{
					// In this iteration we receive only.
					MPI_Recv(recvbuf + disp, recvcount, recvtype, rank,
							(self_index << 4) | index, comm, MPI_STATUS_IGNORE);
					disp += recvcount;
				}
			}
		}
#endif
	}

	template<typename T>
	static void allgatherv(const T *sendbuf, int sendcount, MPI_Datatype sendtype,
			T *recvbuf, const int *recvcounts, const int *disps,
			MPI_Datatype recvtype, MPI_Comm comm,
			int self_index, int workers_per_node) {
		int num_nodes = mpiutil::Comm_size(comm);
		int self_rank = mpiutil::Comm_rank(comm);
		assert(sendcount == recvcounts[self_rank * workers_per_node + self_index]);
		assert(workers_per_node <= 16);

#ifdef SATUZK_GOOD_ALLGATHER
		// If we want to support a single worker we have to use something
		// like MPI_Sendrecv for the first odd/even cycle.
		assert(num_nodes || workers_per_node);
		int p_rank, p_index;
		int n_rank, n_index;
		if(self_index) {
			p_rank = self_rank;
			p_index = self_index - 1;
		}else if(self_rank) {
			p_rank = self_rank - 1;
			p_index = workers_per_node - 1;
		}else{
			p_rank = num_nodes - 1;
			p_index = workers_per_node - 1;
		}
		if(self_index < workers_per_node - 1) {
			n_rank = self_rank;
			n_index = self_index + 1;
		}else if(self_rank < num_nodes - 1) {
			n_rank = self_rank + 1;
			n_index = 0;
		}else{
			n_rank = 0;
			n_index = 0;
		}

		auto m = workers_per_node * num_nodes;
		auto s = self_rank * workers_per_node + self_index;
		auto even = !(s % 2);

		if(even) {
			MPI_Send(sendbuf, sendcount, sendtype, p_rank, p_index, comm);
			MPI_Recv(recvbuf + disps[(s + 1) % m], recvcounts[(s + 1) % m], recvtype,
					n_rank, self_index, comm, MPI_STATUS_IGNORE);
		}else{
			MPI_Recv(recvbuf + disps[(s + 1) % m], recvcounts[(s + 1) % m], recvtype,
					n_rank, self_index, comm, MPI_STATUS_IGNORE);
			MPI_Send(sendbuf, sendcount, sendtype, p_rank, p_index, comm);
		}
		s++;

		for(size_t i = 1; i < m; i++) {
			if(even) {
				MPI_Send(recvbuf + disps[s % m], recvcounts[s % m], recvtype, p_rank, p_index, comm);
				MPI_Recv(recvbuf + disps[(s + 1) % m], recvcounts[(s + 1) % m], recvtype,
						n_rank, self_index, comm, MPI_STATUS_IGNORE);
			}else{
				MPI_Recv(recvbuf + disps[(s + 1) % m], recvcounts[(s + 1) % m], recvtype,
						n_rank, self_index, comm, MPI_STATUS_IGNORE);
				MPI_Send(recvbuf + disps[s % m], recvcounts[s % m], recvtype, p_rank, p_index, comm);
			}
			s++;
		}
#else
		for(int rank = 0; rank < num_nodes; rank++) {
			for(int index = 0; index < workers_per_node; index++) {
				if(rank == self_rank && index == self_index) {
					// It's our turn to send.
					for(int dest_rank = 0; dest_rank < num_nodes; dest_rank++) {
						for(int dest_index = 0; dest_index < workers_per_node; dest_index++) {
							if(dest_rank == self_rank && dest_index == self_index)
								continue;
							MPI_Send(sendbuf, sendcount, sendtype, dest_rank,
									(dest_index << 4) | self_index, comm);
						}
					}

					// We also need to copy to our own receive buffer.
					std::copy(sendbuf, sendbuf + sendcount,
							recvbuf + disps[rank * workers_per_node + index]);
				}else{
					// In this iteration we receive only.
					MPI_Recv(recvbuf + disps[rank * workers_per_node + index],
							recvcounts[rank * workers_per_node + index],
							recvtype, rank,
							(self_index << 4) | index, comm, MPI_STATUS_IGNORE);
				}
			}
		}
#endif
	}

	template<typename Iterator>
	static void exchangeResults(SolverType &solver, Iterator begin, Iterator end,
			MPI_Comm communicator, int self_index, int workers_per_node) {
		const int num_nodes = mpiutil::Comm_size(communicator);

		// Components: (Number of clauses, Number of Literals).
		static constexpr int numCnts = 2;
		static constexpr int clauseCnt = 0;
		static constexpr int literalCnt = 1;

		// Prepare the local data.
		std::vector<uint32_t> local_data;

		int local_stats[numCnts] = {0, 0};
		for(auto rit = begin; rit != end; ++rit) {
			auto bits = rit->clause.name().bits();
			local_data.push_back(bits & 0xFFFFFFFF);
			local_data.push_back(bits >> 32);

			local_data.push_back(rit->status);
			for(auto it = rit->resolvent.begin(); it != rit->resolvent.end(); ++it) {
				local_data.push_back(it->getIndex() + 1);
				local_stats[literalCnt]++;
			}

			local_data.push_back(0);
			local_stats[clauseCnt]++;
		}

		// Gather the global clause/literal counts.
		std::vector<int> all_stats;
		all_stats.resize(numCnts * num_nodes * workers_per_node);
		allgather(local_stats, numCnts, mpiutil::Primitive<int>,
				all_stats.data(), numCnts, mpiutil::Primitive<int>, communicator,
				self_index, workers_per_node);
		
		std::vector<int> data_counts;
		std::vector<int> data_disps;

		int summary_stats[numCnts] = {0, 0};
		for(int i = 0; i < num_nodes * workers_per_node; i++) {
			data_counts.push_back(4 * all_stats[numCnts * i + clauseCnt] + all_stats[numCnts * i + literalCnt]);
			data_disps.push_back(4 * summary_stats[clauseCnt] + summary_stats[literalCnt]);

			summary_stats[clauseCnt] += all_stats[numCnts * i + clauseCnt];
			summary_stats[literalCnt] += all_stats[numCnts * i + literalCnt];
		}

		// Gather the elimination data.
		std::vector<uint32_t> all_data;
		all_data.resize(4 * summary_stats[clauseCnt] + summary_stats[literalCnt]);
		allgatherv(local_data.data(), 4 * local_stats[clauseCnt] + local_stats[literalCnt], mpiutil::Primitive<uint32_t>,
				all_data.data(), data_counts.data(), data_disps.data(),
				mpiutil::Primitive<uint32_t>, communicator, self_index, workers_per_node);

		// Process the elimination data.
		for(auto it = all_data.begin(); it != all_data.end(); /* no increment */) {
			uint64_t name_low = *it++;
			assert(it != all_data.end());
			uint64_t name_high = *it++;
			assert(it != all_data.end());

			auto status = *it++;
			assert(it != all_data.end());

			std::vector<LiteralIdType> lits;
			while(*it != 0) {
				lits.push_back(LiteralIdType::fromIndex(*it++ - 1));
				assert(it != all_data.end());
			}
			it++;

			auto name = ClauseNameType{(name_high << 32) | name_low};
			auto clause = solver.clauseSpace.findName(name);

			if(status & DistillationType::statusStrengthened) {
				auto new_clause = solver.clauseSpace.allocate(solver.uniqueClauseName(),
						lits.size(), lits.begin(), lits.end());
				new_clause.markAsEssential();

				clause.forceErase(true);
			}
		}
	}

	// TODO: Clone the communicator?
	DistributedDistillation(MPI_Comm base_communicator, SolverType &solver, mpicxx::dispatcher *dispatcher,
			int self_index, int workers_per_node)
	: _computeCommunicator(base_communicator), _solver(solver),
			_dispatcher(dispatcher), _context(_dispatcher, base_communicator),
			_numNodes(mpiutil::Comm_size(base_communicator)),
			_nodeRank(mpiutil::Comm_rank(base_communicator)),
			_selfIndex(self_index), _workersPerNode(workers_per_node) {
	}

	void perform() {
		std::vector<dist_balancer::Worker> workers;
		for(size_t i = 0; i < _numNodes; i++)
			for(size_t j = 0; j < _workersPerNode; j++)
				workers.push_back({i, j});

		// TODO: The clauses that solvers generate during preprocessing do not
		// have a consistent naming. We check for origin zero to work around this.
		std::vector<uint64_t> names;
		_solver.clauseSpace.forEach([&] (ClauseRefType clause) {
			if(clause.isPresent() && clause.name().origin() == 0)
				names.push_back(clause.name().bits());
		});

		// Sort the clauses to make sure all nodes agree on the clause numbering.
		std::sort(names.begin(), names.end());
		
		auto range = distributed::splitWork(names.begin(), names.end(),
				_numNodes * _workersPerNode, _nodeRank * _workersPerNode + _selfIndex);
	
		dist_balancer::Balancer<mpicxx::trivial_mapping<uint64_t>> balancer{{_nodeRank, _selfIndex}, &_context};
		balancer.initiate(workers, range.begin(), range.end());
		balancer.run();

		boost::fibers::fiber compute_fiber{[&] {
			_solver.trail.start();
	
			DistillationType distillation;
			std::vector<typename DistillationType::Result> results;

			while(true) {
//				std::cout << "Trying to steal()" << std::endl;
				auto stolen = balancer.steal();
				if(!stolen)
					break;
				auto clause = _solver.clauseSpace.findName(ClauseNameType{stolen.value()});
				boost::this_fiber::yield();
				
				assert(clause.length() > 0);
				auto result = distillation.distill(_solver, clause, true);
				if(result.status != DistillationType::statusNull)
					results.push_back(result);
			}

			// reset the trail so that we can apply the changes from other processors
			_solver.trail.reset();

//			std::cout << "Exchanging erased clauses" << std::endl;
			exchangeResults(_solver, results.begin(), results.end(),
					_computeCommunicator, _selfIndex, _workersPerNode);

			_solver.clauseSpace.compactClauses();
		}};
		compute_fiber.properties<mpicxx::props>().set_interaction(mpicxx::interaction::background);

		balancer.shutdown();
		compute_fiber.join();
	}

private:
	MPI_Comm _computeCommunicator;
	SolverType &_solver;
	mpicxx::dispatcher *_dispatcher;
	int _selfIndex;
	int _workersPerNode;

	dist_balancer::Context<mpicxx::trivial_mapping<uint64_t>> _context;

	int _numNodes;
	int _nodeRank;
};

} } // namespace satuzk::cdcl

