
$c_PROTO_DIR := $(TREE_PATH)/$c/proto
$c_GEN_DIR := $(TREE_PATH)/$c/gen
$c_GEN_INCLUDE_DIR := $(TREE_PATH)/$c/gen_include
$c_GEN_SRC_DIR := $(TREE_PATH)/$c/gen_src

.PHONY: all-$c gen-$c

$c_PROTO := trace.proto

$c_TARGETS := all-$c gen-$c

$($c_GEN_DIR) $($c_GEN_INCLUDE_DIR) $($c_GEN_SRC_DIR):
	mkdir -p $@

gen-$c: $(addprefix $($c_GEN_DIR)/,$($c_PROTO:%.proto=%.tag))

$($c_GEN_DIR)/%.tag: $($c_PROTO_DIR)/%.proto | $($c_GEN_DIR) $($c_GEN_INCLUDE_DIR) $($c_GEN_SRC_DIR)
	$(PROTOC) --cpp_out=$($d_GEN_DIR) --proto_path=$($d_PROTO_DIR) $<
	cp $($d_GEN_DIR)/$*.pb.h $($d_GEN_INCLUDE_DIR)/
	cp $($d_GEN_DIR)/$*.pb.cc $($d_GEN_SRC_DIR)/
	touch $@

