
#include <fstream>

#include <satuzk/All.hpp>

#include <boost/program_options.hpp>

namespace po = boost::program_options;

// --------------------------------------------------------
// Type declarations and Hooks implementation
// --------------------------------------------------------

class Hooks {
public:
//	void onLearnedClause(ClauseType<OurDefs> clause) { }

	void onCollectClauses();
};

typedef satuzk::cdcl::Solver<
	satuzk::cdcl::UseHooks<Hooks>
> Solver;

typedef satuzk::cdcl::CnfParser<
	satuzk::cdcl::UseHooks<Hooks>
> CnfParser;

typedef satuzk::cdcl::Subsumption<
	satuzk::cdcl::UseHooks<Hooks>
> Subsumption;

typedef satuzk::cdcl::Distillation<
	satuzk::cdcl::UseHooks<Hooks>
> Distillation;

typedef satuzk::cdcl::DistributedDistillation<
	satuzk::cdcl::UseHooks<Hooks>
> DistributedDistillation;

struct Guard {
	Guard() {
		MPI_Init(nullptr, nullptr);
	}

	~Guard() {
		MPI_Finalize();
	}
};

Guard mpiGuard;
Solver solver(Hooks(), satuzk::mpiutil::Comm_rank(MPI_COMM_WORLD) + 1);

void Hooks::onCollectClauses() { }

// --------------------------------------------------------
// Actual program logic
// --------------------------------------------------------

int main(int argc, char **argv) {
	solver.opts.general.verbose = 1;

	// parse the parameters given to the solver
	po::options_description options_desc("Options");
	options_desc.add_options()
		("help", "Print help message")
		("v", "Verbose output")
		("out", po::value<std::string>(), "Preprocessed output")
		("instance", po::value<std::string>(), "CNF problem instance");
	
	po::positional_options_description positional_desc;
	positional_desc.add("instance", 1);

	po::variables_map options;
	po::store(po::command_line_parser(argc, argv)
			.options(options_desc).positional(positional_desc).run(), options);
	po::notify(options);

	if(options.count("help") > 0) {
		std::cout << "Usage: satUZK-preproc [OPTIONS...] instance\n\n"
				<< options_desc << std::endl;
		return 0;
	}

	if(options.count("v") > 0)
		solver.opts.general.verbose = 3;
	
	assert(options.count("instance") > 0);
	auto instance_file = options["instance"].as<std::string>();
	int instance_fd = open(instance_file.c_str(), O_RDONLY);
	if(instance_fd == -1)
		throw std::runtime_error("Could not read input file");

	CnfParser parser(solver.varSpace, solver.clauseSpace, instance_fd);
	parser.parse();
	solver.inputFinish();
	
	if(close(instance_fd) != 0)
		throw std::runtime_error("Could not close instance file");

	std::cout << "c parse time: " << sysGetCpuTime() << " ms" << std::endl;
	std::cout << "c parse memory: " << sysPeakMemory() << " kb" << std::endl;
	
	if(!satuzk::mpiutil::Comm_rank(MPI_COMM_WORLD)) {
		std::cout << "c Before. numPresent: " << solver.clauseSpace.numPresent()
				<< ", presentLiterals: " << solver.clauseSpace.presentLiterals() << std::endl;
		std::cout << "c Before. unitClauses: " << solver.p_unitClauses.size() << std::endl;
	}

/*	Distillation distillation;

	solver.occlists.construct();
	for(int i = 0; i < 5; i++) {
		std::cout << "Round "  << i << std::endl;
		
		std::cout << "c Subsumption:" << std::endl;
		Subsumption::subsumeAll(solver);
		std::cout << "c numPresent: " << solver.clauseSpace.numPresent()
				<< ", presentLiterals: " << solver.clauseSpace.presentLiterals() << std::endl;
		
		solver.trail.start();

		std::cout << "c Distillation:" << std::endl;
		std::vector<Solver::ClauseRefType> clauses;
		for(auto it = solver.clauseSpace.beginRefs(); it != solver.clauseSpace.endRefs(); ++it) {
			if(!it->isPresent())
				continue;
			clauses.push_back(*it);
		}

		int next_percent = 0;
		for(auto it = clauses.begin(); it != clauses.end(); ++it) {
			assert(it->length() > 0);
			distillation.distill(solver, *it, *it->beginLits());

			if(it - clauses.begin() >= next_percent / 100.0f * clauses.size()) {
				std::cout << "c progress: " << next_percent << "%" << std::endl;
				next_percent += 20;
			}
		}
		std::cout << "c numPresent: " << solver.clauseSpace.numPresent()
				<< ", presentLiterals: " << solver.clauseSpace.presentLiterals() << std::endl;
		std::cout << "c unitClauses: " << solver.p_unitClauses.size() << std::endl;

		solver.trail.reset();
		solver.clauseSpace.compactClauses();
	}*/
	
	boost::fibers::use_scheduling_algorithm<mpicxx::scheduler>();

	mpicxx::dispatcher dispatcher;
	dispatcher.run();

	struct timespec start_wt, end_wt;
	if(clock_gettime(CLOCK_MONOTONIC, &start_wt))
		throw std::runtime_error("clock_gettime() failed");
	
	{
		DistributedDistillation distillation(MPI_COMM_WORLD, solver, &dispatcher, 0, 1);
		distillation.perform();
	}
	
	if(clock_gettime(CLOCK_MONOTONIC, &end_wt))
		throw std::runtime_error("clock_gettime() failed");
	time_t elapsed_secs = end_wt.tv_sec - start_wt.tv_sec;
	
	dispatcher.shutdown();
	
	if(!satuzk::mpiutil::Comm_rank(MPI_COMM_WORLD)) {
		std::cout << "c After. numPresent: " << solver.clauseSpace.numPresent()
				<< ", presentLiterals: " << solver.clauseSpace.presentLiterals() << std::endl;
		std::cout << "c After. unitClauses: " << solver.p_unitClauses.size() << std::endl;
		std::cout << "c walltime: " << elapsed_secs << " secs" << std::endl;
	}

	if(options.count("out") > 0
			&& !satuzk::mpiutil::Comm_rank(MPI_COMM_WORLD)) {
		typedef satuzk::satutils::Dump<
			satuzk::satutils::UseAtomSpace<Solver::VariableSpaceType>,
			satuzk::satutils::UseConstraintSpace<Solver::ClauseSpaceType>
		> Dump;

		std::ofstream out_stream(options["out"].as<std::string>());
		Dump::writeCnf(out_stream, solver.varSpace, solver.clauseSpace);
	}

	return 0;
}

