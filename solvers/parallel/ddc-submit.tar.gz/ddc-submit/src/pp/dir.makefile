
$c_SRCDIR := $(TREE_PATH)/$c/src
$c_BINDIR := $(BUILD_PATH)/$c/bin

.PHONY: all-$c debug-$c clean-$c

$c_TARGETS := all-$c debug-$c clean-$c $($c_BINDIR)/satUZK-pp $($c_BINDIR)

all-$c: $($c_BINDIR)/satUZK-pp

debug-$c: $($c_BINDIR)/satUZK-pp.debug

clean-$c:
	rm -f $($d_BINDIR)/satUZK-pp $($d_BINDIR)/satUZK-pp.d

$($c_BINDIR):
	mkdir -p $@

$c_INCLUDES := -I$(TREE_PATH)/lib/include -I$(TREE_PATH)/common/include

$c_CXXFLAGS := $(CXXFLAGS) $($c_INCLUDES)
$c_CXXFLAGS += -std=c++14 -pthread
$c_CXXFLAGS += -DCONFIG_HEADER=\"$(BUILD_PATH)/Config.hpp\"
$c_CXXFLAGS += -fwhole-program
$c_CXXFLAGS += -static-libgcc -static-libstdc++

$c_LIBS := -lrt -Wl,-Bstatic -lboost_program_options -Wl,-Bdynamic
$c_LIBS += -lmpi -lboost_fiber -lboost_context

$($c_BINDIR)/satUZK-pp: $($c_SRCDIR)/main.cpp | $($c_BINDIR)
	$(CXX) -o $@ -O3 $($d_CXXFLAGS) $< $($d_LIBS)
	$(CXX) $($d_CXXFLAGS) -MM -MP -MF $@.d -MT "$@" -MT "$@d" $<

$($c_BINDIR)/satUZK-pp.debug: $($c_SRCDIR)/main.cpp | $($c_BINDIR)
	$(CXX) -o $@ -g $($d_CXXFLAGS) $< $($d_LIBS)
	$(CXX) $($d_CXXFLAGS) -MM -MP -MF $@.d -MT "$@" -MT "$@d" $<

-include $($c_BINDIR)/satUZK-pp.d
-include $($c_BINDIR)/satUZK-pp.debug.d

