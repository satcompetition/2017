
#include <unistd.h>
#include <stddef.h>
#include <type_traits>
#include <algorithm>
#include <array>
#include <memory>
#include <vector>
#include <map>
#include <unordered_map>
#include <queue>
#include <string>
#include <iostream>
#include <fstream>
#include <sstream>
#include <iomanip>
#include <random>
#include <stdexcept>
#include <cstring>
#include <csignal>
#include <cassert>

#include <satuzk/All.hpp>

#include <boost/program_options.hpp>

#ifdef FEATURE_GOOGLE_PROFILE
#include <google/profiler.h>
#endif

namespace po = boost::program_options;

// --------------------------------------------------------
// Type declarations and Hooks implementation
// --------------------------------------------------------

class Hooks {
public:
//	void onLearnedClause(ClauseType<OurDefs> clause) { }

	void onCollectClauses();
};

typedef satuzk::cdcl::Solver<
	satuzk::cdcl::UseHooks<Hooks>
> Solver;

typedef satuzk::cdcl::LiteralRef<
	satuzk::cdcl::UseHooks<Hooks>
> LiteralRef;

typedef satuzk::cdcl::CnfParser<
	satuzk::cdcl::UseHooks<Hooks>
> CnfParser;

typedef satuzk::cdcl::Lookahead<
	satuzk::cdcl::UseHooks<Hooks>
> Lookahead;

Solver solver(Hooks(), 1);
//satuzk::SimplifyConfigStruct<OurDefs> simplifyConfig;

void Hooks::onCollectClauses() {
//FIXME	simplifyConfig.collectClauses(*the_config);
}

// --------------------------------------------------------
// Actual program logic
// --------------------------------------------------------

int main(int argc, char **argv) {
	solver.opts.general.verbose = 1;
	
	// parse the parameters given to the solver
	po::options_description options_desc("Options");
	options_desc.add_options()
		("help", "Print help message")
		("v", "Verbose output")
		("instance", po::value<std::string>(), "CNF problem instance");
	
	po::positional_options_description positional_desc;
	positional_desc.add("instance", 1);

	po::variables_map options;
	po::store(po::command_line_parser(argc, argv)
			.options(options_desc).positional(positional_desc).run(), options);
	po::notify(options);

	if(options.count("help") > 0) {
		std::cout << "Usage: satUZK-lookahead [OPTIONS...] instance\n\n"
				<< options_desc << std::endl;
		return 0;
	}

	if(options.count("v") > 0)
		solver.opts.general.verbose = 3;
	
	assert(options.count("instance") > 0);
	auto instance_file = options["instance"].as<std::string>();
	int instance_fd = open(instance_file.c_str(), O_RDONLY);
	if(instance_fd == -1)
		throw std::runtime_error("Could not read input file");

	CnfParser parser(solver.varSpace, solver.clauseSpace, instance_fd);
	parser.parse();
	solver.inputFinish();
	
	if(close(instance_fd) != 0)
		throw std::runtime_error("Could not close instance file");

	std::cout << "c parse time: " << sysGetCpuTime() << " ms" << std::endl;
	std::cout << "c parse memory: " << sysPeakMemory() << " kb" << std::endl;
	
	// perform a lookahead and display the result
	std::vector<std::pair<LiteralRef, satuzk::cdcl::LookaheadValue>> values;
	std::vector<LiteralRef> failed;

	solver.occlists.construct();
	solver.trail.start();
	auto preselected = Lookahead::preselect(solver.varSpace,
			solver.occlists, solver.assignment);
	Lookahead::lookaheadAll(preselected, solver,
			solver.occlists, solver.assignment, solver.trail, values, failed);

	for(size_t i = 0; i < 10 && i < values.size(); i++)
		std::cout << "c result " << values[i].first.toNumber()
				<< " " << values[i].second << std::endl;

	return 0;
}

