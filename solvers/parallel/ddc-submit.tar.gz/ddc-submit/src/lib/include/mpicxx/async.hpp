#ifndef SATUZK_MPI_ASYNC_HPP
#define SATUZK_MPI_ASYNC_HPP

#include <list>
#include <boost/fiber/algo/algorithm.hpp>
#include <boost/fiber/future.hpp>
#include "defs.hpp"
#include "fiber.hpp"

namespace mpicxx {

using future_type = boost::fibers::future<void>;
using promise_type = boost::fibers::promise<void>;

struct dispatcher {
	dispatcher()
	: _active{true}, _reqs_pending{0} { }

	dispatcher(const dispatcher &) = delete;

	dispatcher &operator= (const dispatcher &) = delete;

	void run() {
		_io_fiber = boost::fibers::fiber{[=] {
			while(_active.load(std::memory_order_relaxed)) {
				if(!_progress_reqs() && !_progress_probes())
//					boost::this_fiber::sleep_for(std::chrono::milliseconds{5});
					boost::this_fiber::yield();
			}
		}};
		_io_fiber.properties<mpicxx::props>().set_interaction(mpicxx::interaction::poll);
	}

	// The caller has to make sure that there is a barrier between
	// the last call to submit() by any thread and shutdown().
	void shutdown() {
		// Note that there might still be unfinished IO operations.

		// Because of said barrier it is fine use relaxed atomics here.
		_active.store(false, std::memory_order_relaxed);
		_io_fiber.join();
	}

	future_type submit(request req, status *stat) {
		std::lock_guard<std::mutex> lock{_mutex};

		assert(_active);
		_reqs_pending++;

		promise_type p;
		auto f = p.get_future();

		for(size_t i = 0; i < _req_handles.size(); i++) {
			if(_req_handles[i] != MPI_REQUEST_NULL)
				continue;

			_req_handles[i] = req;
			_req_promises[i] = std::move(p);
			_req_stats[i] = stat;
			return f;
		}

		_req_handles.push_back(req);
		_req_promises.push_back(std::move(p));
		_req_stats.push_back(stat);
		return f;
	}

private:
	struct probe {
		int source;
		int tag;
		MPI_Comm comm;
		MPI_Status *status;
		promise_type promise;
	};

	// For simplicity we use an atomic variable.
	// Only the "main" thread (i.e. the thread that calls run() and shutdown()) ever changes this.
	std::atomic<bool> _active;

	// This variable is not protected against concurrent access.
	boost::fibers::fiber _io_fiber;

	// Protects the following variables.
	// We never yield the fiber while holding this mutex so a standard std::mutex is sufficient here.
	std::mutex _mutex;

	// ------------------------------------------------------------------------
	// MPI_Request handling.
	// ------------------------------------------------------------------------

	bool _progress_reqs() {
		std::lock_guard<std::mutex> lock{_mutex};

		if(!_reqs_pending)
			return false;

		std::vector<int> indices;
		std::vector<status> st;
		st.resize(_req_handles.size());
		indices.resize(_req_handles.size());

		int count;
		MPI_Testsome(_req_handles.size(), &_req_handles[0], &count, &indices[0], &st[0]);
		if(!count || count == MPI_UNDEFINED)
			return false;

		for(size_t i = 0; i < count; i++) {
			auto k = indices[i];
			if(_req_stats[k] != MPI_STATUS_IGNORE)
				*_req_stats[k] = st[i];
			_req_promises[k].set_value();
		}

		assert(_reqs_pending >= count);
		_reqs_pending -= count;

		return true;
	}

	int _reqs_pending;

	std::vector<request> _req_handles;
	std::vector<promise_type> _req_promises;
	std::vector<status *> _req_stats;
	
	// ------------------------------------------------------------------------
	// MPI_Probe() handling.
	// ------------------------------------------------------------------------
public:
	future_type submit_probe(int source, int tag, MPI_Comm comm, MPI_Status *status) {
		std::lock_guard<std::mutex> lock{_mutex};

		promise_type p;
		auto f = p.get_future();

		_probes.push_back(probe{source, tag, comm, status, std::move(p)});
		return f;
	}

private:
	bool _progress_probes() {
		std::lock_guard<std::mutex> lock{_mutex};

		int num_success = 0;
		for(auto it = _probes.begin(); it != _probes.end(); /* no increment here */) {
			int flag;
			MPI_Iprobe(it->source, it->tag, it->comm, &flag, it->status);
			if(flag) {
				it->promise.set_value();

				it = _probes.erase(it);
				num_success++;
			}else{
				++it;
			}
		}
		return num_success;
	}

	std::list<probe> _probes;
};

} // namespace mpicxx

#endif // SATUZK_MPI_ASYNC_HPP
