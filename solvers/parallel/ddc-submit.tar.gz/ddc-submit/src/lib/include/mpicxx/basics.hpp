#ifndef SATUZK_MPICXX_BASICS_HPP
#define SATUZK_MPICXX_BASICS_HPP

namespace mpicxx {

struct Async { };

// TODO: This should be inline.
static constexpr Async async;

boost::fibers::future<void> fiber_probe(Async, dispatcher *d,
		int source, int tag, MPI_Comm comm, MPI_Status *status) {
	return d->submit_probe(source, tag, comm, status);
}

void fiber_probe(dispatcher *d, int source, int tag, MPI_Comm comm, MPI_Status *status) {
	auto f = d->submit_probe(source, tag, comm, status);
	f.get();
}

boost::fibers::future<void> fiber_send(Async, dispatcher *d,
		const void *buffer, int count, MPI_Datatype datatype,
		int dest, int tag, MPI_Comm comm) {
	MPI_Request req;
	MPI_Isend(const_cast<void *>(buffer), count, datatype, dest, tag, comm, &req);
	return d->submit(req, MPI_STATUS_IGNORE);
}

void fiber_send(dispatcher *d, const void *buffer, int count, MPI_Datatype datatype,
		int dest, int tag, MPI_Comm comm) {
	MPI_Request req;
	MPI_Isend(const_cast<void *>(buffer), count, datatype, dest, tag, comm, &req);
	auto f = d->submit(req, MPI_STATUS_IGNORE);
	f.get();
}

boost::fibers::future<void> async_recv(dispatcher *d, void *buffer, int count, MPI_Datatype datatype,
		int source, int tag, MPI_Comm comm, MPI_Status *status) {
	MPI_Request req;
	MPI_Irecv(buffer, count, datatype, source, tag, comm, &req);
	return d->submit(req, status);
}

void fiber_recv(dispatcher *d, void *buffer, int count, MPI_Datatype datatype,
		int source, int tag, MPI_Comm comm, MPI_Status *status) {
	MPI_Request req;
	MPI_Irecv(buffer, count, datatype, source, tag, comm, &req);
	auto f = d->submit(req, status);
	f.get();
}

boost::fibers::future<void> fiber_recv(Async, dispatcher *d,
		void *buffer, int count, MPI_Datatype datatype,
		int source, int tag, MPI_Comm comm, MPI_Status *status) {
	MPI_Request req;
	MPI_Irecv(buffer, count, datatype, source, tag, comm, &req);
	return d->submit(req, status);
}

} // namespace mpicxx

#endif // SATUZK_MPICXX_BASICS_HPP
