#ifndef SATUZK_MPI_FIBER_HPP
#define SATUZK_MPI_FIBER_HPP

#include <boost/fiber/algo/algorithm.hpp>
#include <boost/fiber/fiber.hpp>
#include <boost/fiber/properties.hpp>
#include <boost/fiber/scheduler.hpp>

namespace mpicxx {

enum class interaction {
	null,
	system,
	poll,
	batch,
	background
};

struct props : boost::fibers::fiber_properties {
	props(boost::fibers::context *context)
	: boost::fibers::fiber_properties{context}, _interaction{interaction::batch} {
		if(context->is_context(boost::fibers::type::dispatcher_context))
			set_interaction(interaction::system);
	}

	props(const props &) = delete;

	props &operator= (const props &) = delete;

	void set_interaction(interaction s) {
		_interaction = s;
		notify();
	}

	interaction get_interaction() {
		return _interaction;
	}

private:
	interaction _interaction;
};

struct scheduler : boost::fibers::algo::algorithm_with_properties<props> {
	scheduler()
	: _last_rotation{rotation::work} { }

	scheduler(const scheduler &) = delete;

	scheduler &operator= (const scheduler &) = delete;

	void awakened(boost::fibers::context *context, props &p) noexcept override {
		_enqueue(context, p);
/*		std::cout << "awakened(" << context << ")" << std::endl;
		if(context->is_context(boost::fibers::type::main_context))
			std::cout << "    Main context" << std::endl;
		if(context->is_context(boost::fibers::type::dispatcher_context))
			std::cout << "    Dispatcher context" << std::endl;
		if(context->is_context(boost::fibers::type::worker_context))
			std::cout << "    Worker context" << std::endl;*/
	}

	void property_change(boost::fibers::context *context, props &p) noexcept override {
		context->ready_unlink();
		_enqueue(context, p);
	}

	bool has_ready_fibers() const noexcept override {
		return !_system_q.empty() || !_poll_q.empty()
				|| !_batch_q.empty() || !_background_q.empty();
	}

	boost::fibers::context *pick_next() noexcept override {
		// Always process system fibers as soon as possible.
		// They might queue additional fibers that influence our scheduling decisions.
		if(!_system_q.empty()) {
			auto context = &_system_q.front();
			_system_q.pop_front();
			return context;
		}
		
		// Otherwise we always poll after doing real work.
		if(_last_rotation == rotation::work)
			if(!_poll_q.empty()) {
				auto context = &_poll_q.front();
				_poll_q.pop_front();
				_last_rotation = rotation::poll;
				return context;
			}

		// When scheduling real work we prefer batch fibers to background fibers.
		if(!_batch_q.empty()) {
			auto context = &_batch_q.front();
			_batch_q.pop_front();
			_last_rotation = rotation::work;
			return context;
		}else if(!_background_q.empty()) {
			auto context = &_background_q.front();
			_background_q.pop_front();
			_last_rotation = rotation::work;
			return context;
		}
		
		// Polling might be the only possible thing to do.
		if(!_poll_q.empty()) {
			auto context = &_poll_q.front();
			_poll_q.pop_front();
			_last_rotation = rotation::poll;
			return context;
		}
	
	/*		if(context->is_context(boost::fibers::type::main_context))
				std::cout << "    Main context" << std::endl;
			if(context->is_context(boost::fibers::type::dispatcher_context))
				std::cout << "    Dispatcher context" << std::endl;
			if(context->is_context(boost::fibers::type::worker_context))
				std::cout << "    Worker context" << std::endl;*/

		return nullptr;
	}

	void suspend_until(std::chrono::steady_clock::time_point const&) noexcept override {
		//std::cout << "TODO: Implement suspend_until()." << std::endl;
	}

	void notify() noexcept override {
	}

private:
	enum class rotation {
		work,
		poll
	};

	void _enqueue(boost::fibers::context *context, props &p) {
		assert(!context->ready_is_linked());
		if(p.get_interaction() == interaction::system) {
			_system_q.push_back(*context);
		}else if(p.get_interaction() == interaction::poll) {
			_poll_q.push_back(*context);
		}else if(p.get_interaction() == interaction::batch) {
			_batch_q.push_back(*context);
		}else{
			assert(p.get_interaction() == interaction::background);
			_background_q.push_back(*context);
		}
	}

	rotation _last_rotation;
	boost::fibers::scheduler::ready_queue_t _system_q;
	boost::fibers::scheduler::ready_queue_t _poll_q;
	boost::fibers::scheduler::ready_queue_t _batch_q;
	boost::fibers::scheduler::ready_queue_t _background_q;
};

} // namespace mpicxx

#endif // SATUZK_MPI_FIBER_HPP
