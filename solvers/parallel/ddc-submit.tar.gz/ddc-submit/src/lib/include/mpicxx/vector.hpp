#ifndef SATUZK_MPICXX_VECTOR_HPP
#define SATUZK_MPICXX_VECTOR_HPP

#include <vector>
#include <mpicxx/basics.hpp>

namespace mpicxx {

size_t size_probe(dispatcher *d, MPI_Datatype datatype,
		int source, int tag, MPI_Comm comm) {
	MPI_Status status;
	fiber_probe(d, source, tag, comm, &status);

	int count;
	MPI_Get_count(&status, datatype, &count);
	return count;
}

template<typename T>
void single_send(dispatcher *d, const T &v, MPI_Datatype datatype,
		int dest, int tag, MPI_Comm comm) {
	fiber_send(d, &v, 1, datatype, dest, tag, comm);
}

template<typename T>
void single_recv(dispatcher *d, T &v, MPI_Datatype datatype,
		int source, int tag, MPI_Comm comm, MPI_Status *status) {
	fiber_recv(d, &v, 1, datatype, source, tag, comm, status);
}

template<typename T>
void vector_send(dispatcher *d, const std::vector<T> &v, MPI_Datatype datatype,
		int dest, int tag, MPI_Comm comm) {
	fiber_send(d, &v[0], v.size(), datatype, dest, tag, comm);
}

template<typename T>
boost::fibers::future<void> vector_send(Async, dispatcher *d, const std::vector<T> &v, MPI_Datatype datatype,
		int dest, int tag, MPI_Comm comm) {
	return fiber_send(async, d, &v[0], v.size(), datatype, dest, tag, comm);
}

template<typename T>
void vector_recv(dispatcher *d, std::vector<T> &v, MPI_Datatype datatype,
		int source, int tag, MPI_Comm comm, MPI_Status *status) {
	fiber_recv(d, &v[0], v.size(), datatype, source, tag, comm, status);
}

template<typename T>
boost::fibers::future<void> vector_recv(Async, dispatcher *d, std::vector<T> &v, MPI_Datatype datatype,
		int source, int tag, MPI_Comm comm, MPI_Status *status) {
	return fiber_recv(async, d, &v[0], v.size(), datatype, source, tag, comm, status);
}

} // namespace mpicxx

#endif // SATUZK_MPICXX_VECTOR_HPP
