#ifndef SATUZK_MPI_TYPE_HPP
#define SATUZK_MPI_TYPE_HPP

#include <stddef.h>
#include <algorithm>
#include <type_traits>
#include <vector>
#include <mpi.h>

namespace mpicxx {

template<typename T>
struct trivial_mapping_base {
	using item = T;
	using representation = T;

	constexpr trivial_mapping_base(data_type type)
	: _type{type} { }

	data_type type() const {
		return _type;
	}

	T serialize(T item) const {
		return item;
	}

	T deserialize(T item) const {
		return item;
	}
	
private:
	data_type _type;
};

template<typename T>
struct trivial_mapping;

template<>
struct trivial_mapping<int> : trivial_mapping_base<int> {
	trivial_mapping()
	: trivial_mapping_base<int>{MPI_INT} { }
};

template<>
struct trivial_mapping<unsigned int> : trivial_mapping_base<unsigned int> {
	trivial_mapping()
	: trivial_mapping_base<unsigned int>{MPI_UNSIGNED} { }
};

template<>
struct trivial_mapping<unsigned long> : trivial_mapping_base<unsigned long> {
	trivial_mapping()
	: trivial_mapping_base<unsigned long>{MPI_UNSIGNED_LONG} { }
};

static const trivial_mapping<int> int_mapping;
static const trivial_mapping<int> bool_mapping;

template<typename T, typename Serializer>
struct complex_mapping {
private:
	struct resolve {
		auto operator() (Serializer &s, const T &x) {
			return s.serialize(x);
		}
	};

public:
	using item = T;
	using representation = std::result_of_t<resolve(Serializer &, const T &)>;

	representation serialize(const item &itm) const {
		return _serializer.serialize(itm);
	}

	item deserialize(const representation &rep) const {
		return _serializer.deserialize(rep);
	}

private:
	Serializer _serializer;
};

template<typename M>
struct send {
	using item_type = typename M::item;
	using rep_type = typename M::representation;

	explicit send(dispatcher *d, comm c, int peer, int tag, const item_type &item,
			const M &mapping) {
		_rep = mapping.serialize(item);

		request req;
		MPI_Isend(&_rep, 1, mapping.type(), peer, tag, c, &req);
		_f = d->submit(req, MPI_STATUS_IGNORE);
	}

	send(const send &) = delete;

	send &operator= (const send &) = delete;

	future_type future() {
		return std::move(_f);
	}

private:
	future_type _f;
	rep_type _rep;
};

template<typename M>
struct recv {
	using item_type = typename M::item;
	using rep_type = typename M::representation;

	explicit recv(dispatcher *d, comm c, int peer, int tag, const M &mapping)
	: _mapping{mapping} {
		request req;
		MPI_Irecv(&_rep, 1, mapping.type(), peer, tag, c, &req);
		_f = d->submit(req, MPI_STATUS_IGNORE);
	}

	recv(const recv &) = delete;

	recv &operator= (const recv &) = delete;

	future_type future() {
		return std::move(_f);
	}

	item_type value() {
		return _mapping.deserialize(_rep);
	}

private:
	M _mapping;
	future_type _f;
	rep_type _rep;
};

template<typename M>
struct send_n {
	using item_type = typename M::item;
	using rep_type = typename M::representation;

	explicit send_n(dispatcher *d, comm c, int peer, int tag, const std::vector<item_type> &items,
			const M &mapping) {
		std::transform(items.begin(), items.end(), std::back_inserter(_reps),
				[&] (const typename M::item &item) { return mapping.serialize(item); });

		request req;
		MPI_Isend(&_reps[0], _reps.size(), mapping.type(), peer, tag, c, &req);
		_f = d->submit(req, MPI_STATUS_IGNORE);
	}

	send_n(const send_n &) = delete;

	send_n &operator= (const send_n &) = delete;

	future_type future() {
		return std::move(_f);
	}

private:
	future_type _f;
	std::vector<rep_type> _reps;
};

template<typename M>
struct recv_n {
	using item_type = typename M::item;
	using rep_type = typename M::representation;

	explicit recv_n(dispatcher *d, comm c, int peer, int tag, size_t max_count, const M &mapping)
	: _mapping{mapping} {
		_reps.resize(max_count);

		request req;
		MPI_Irecv(&_reps[0], _reps.size(), mapping.type(), peer, tag, c, &req);
		_f = d->submit(req, &_status);
	}

	recv_n(const recv_n &) = delete;

	recv_n &operator= (const recv_n &) = delete;

	future_type future() {
		return std::move(_f);
	}

	std::vector<item_type> value() {
		int actual_count;
		MPI_Get_count(&_status, _mapping.type(), &actual_count);

		std::vector<typename M::representation> items;
		std::transform(_reps.begin(), _reps.begin() + actual_count, std::back_inserter(items),
				[&] (const rep_type &rep) { return _mapping.deserialize(rep); });
		return items;
	}

private:
	M _mapping;
	future_type _f;
	std::vector<rep_type> _reps;
	MPI_Status _status;
};

} // namespace mpicxx

#endif // SATUZK_MPI_TYPE_HPP
