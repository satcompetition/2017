#ifndef SATUZK_MPI_DEFS_HPP
#define SATUZK_MPI_DEFS_HPP

#include <mpi.h>

namespace mpicxx {

using comm = MPI_Comm;
using data_type = MPI_Datatype;
using status = MPI_Status;
using request = MPI_Request;

} // namespace mpicxx

#endif // SATUZK_MPI_DEFS_HPP
