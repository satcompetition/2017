
$c_SRCDIR := $(TREE_PATH)/$c/src
$c_BINDIR := $(BUILD_PATH)/$c/bin

.PHONY: all-$c clean-$c

$c_TARGETS := all-$c clean-$c $($c_BINDIR)/satUZK-par $($c_BINDIR)

all-$c: $($c_BINDIR)/satUZK-par

clean-$c:
	rm -f $($d_BINDIR)/satUZK-par $($d_BINDIR)/satUZK-par.d

$($c_BINDIR):
	mkdir -p $@

$c_INCLUDES := -I$(TREE_PATH)/common/include

$c_CXXFLAGS := $(CXXFLAGS) $($c_INCLUDES)
$c_CXXFLAGS += -std=c++11
$c_CXXFLAGS += -DCONFIG_HEADER=\"$(BUILD_PATH)/Config.hpp\"
$c_CXXFLAGS += -pthread
$c_CXXFLAGS += -fwhole-program

$($c_BINDIR)/satUZK-par: $($c_SRCDIR)/main.cpp | $($c_BINDIR)
	$(CXX) -o $@ $($d_CXXFLAGS) $<
	$(CXX) $($d_CXXFLAGS) -MM -MP -MF $@.d -MT "$@" -MT "$@d" $<

-include $($c_BINDIR)/satUZK-par.d

