
#include <unistd.h>
#include <stddef.h>
#include <type_traits>
#include <algorithm>
#include <array>
#include <chrono>
#include <memory>
#include <vector>
#include <map>
#include <unordered_map>
#include <queue>
#include <string>
#include <iostream>
#include <fstream>
#include <sstream>
#include <iomanip>
#include <random>
#include <stdexcept>
#include <cstring>
#include <csignal>
#include <cassert>

#include <satuzk/All.hpp>
#include CONFIG_HEADER

#include <boost/program_options.hpp>

#ifdef FEATURE_GOOGLE_PROFILE
#include <google/profiler.h>
#endif

namespace po = boost::program_options;

// --------------------------------------------------------
// Global configuration options.
// --------------------------------------------------------

enum class ModelStyle {
	null,
	standard
};

enum class ProofStyle {
	null,
	dratPlain,
	dratBinary
};

ModelStyle withModel = ModelStyle::null;
ProofStyle withProof = ProofStyle::null;

// File descriptors for the model/proof files.
FILE *modelFile = nullptr;
FILE *proofFile = nullptr;

bool enableSimplification = false;

// --------------------------------------------------------
// Type declarations and Hooks implementation.
// --------------------------------------------------------

struct Hooks {
private:
	static void _emitVariableInt(int n, FILE *stream) {
		if(!n) {
			fputc_unlocked(0, stream);
		}else{
			auto u = (n > 0) ? 2 * unsigned(n) : 2 * unsigned(-n) + 1;
			while(u) {
				auto x = u & 0x7F;
				u >>= 7;
				if(u) {
					fputc_unlocked(x | 0x80, stream);
				}else{
					fputc_unlocked(x, stream);
				}
			}
		}
	}

public:
	template<typename ClauseRef>
	void emitProof(ClauseRef clause) {
		if(withProof == ProofStyle::null)
			return;

		FILE *file = proofFile ? proofFile : stdout;
		if(withProof == ProofStyle::dratBinary) {
			fputc_unlocked('a', file);
			for(auto it = clause.beginLits(); it != clause.endLits(); ++it)
				_emitVariableInt(it->id().toNumber(), file);
			fputc_unlocked(0, file);
		}else{
			assert(withProof == ProofStyle::dratPlain);

			for(auto it = clause.beginLits(); it != clause.endLits(); ++it)
				fprintf(file, " %d", it->id().toNumber());
			fputs(" 0\n", file);
		}
	}
	
	template<typename ClauseRef>
	void reduceProof(ClauseRef clause) {
		if(withProof == ProofStyle::null)
			return;

		FILE *file = proofFile ? proofFile : stdout;
		if(withProof == ProofStyle::dratBinary) {
			fputc_unlocked('d', file);
			for(auto it = clause.beginLits(); it != clause.endLits(); ++it)
				_emitVariableInt(it->id().toNumber(), file);
			fputc_unlocked(0, file);
		}else{
			assert(withProof == ProofStyle::dratPlain);

			fputs("d", file);
			for(auto it = clause.beginLits(); it != clause.endLits(); ++it)
				fprintf(file, " %d", it->id().toNumber());
			fputs(" 0\n", file);
		}
	}

	template<typename ClauseRef>
	void onLearnClause(ClauseRef) { }

	template<typename C>
	void onClauseCompaction(C *);

	void onReductionIncrement();
};

typedef satuzk::cdcl::Solver<
	satuzk::cdcl::UseHooks<Hooks>
> Solver;

typedef satuzk::cdcl::SatisfiedReduction<
	satuzk::cdcl::UseHooks<Hooks>
> SatisfiedReduction;

typedef satuzk::cdcl::CnfParser<
	satuzk::cdcl::UseHooks<Hooks>
> CnfParser;

Solver solver(Hooks(), 4);
//satuzk::SimplifyConfigStruct<OurDefs> simplifyConfig;

template<typename C>
void Hooks::onClauseCompaction(C *) {
//FIXME	simplifyConfig.collectClauses(*the_config);
}

void Hooks::onReductionIncrement() {
	if(solver.emulation == satuzk::cdcl::Emulation::miniSat) {
		auto current = sys::hptCurrent();
		progressMessage(solver, current, "r");
	}
}

// --------------------------------------------------------
// Actual program logic
// --------------------------------------------------------

satuzk::SolveState solve() {
//	solver.opts.clauseRed.model = Solver::kClauseRedGeometric;
	SatisfiedReduction sr{&solver, &solver.clauseSpace, &solver.trail,
			&solver.assignment};

	if(solver.opts.general.verbose >= 1) {
		std::cout << "c Initial variables: " << solver.varSpace.presentCount()
			<< ", clauses: " << solver.clauseSpace.numPresent()
			<< ", literals: " << solver.clauseSpace.presentLiterals() << "." << std::endl;	
	}
	
	// Perform preprocessing.
	if(enableSimplification) {
		satuzk::cdcl::Preprocessor<
			satuzk::cdcl::UseHooks<Hooks>
		> preprocessor{&solver};
		preprocessor.verbose = true;
		
		// We need to build occlists before we can preprocess.
		{
			auto start = sys::ThreadClock::now();
			solver.occlists.construct();
			auto elapsed = sys::ThreadClock::now() - start;
			if(solver.opts.general.verbose >= 1)
				std::cout << "c Building occurrence lists took "
						<< std::chrono::duration_cast<std::chrono::milliseconds>(elapsed).count()
						<< " ms" << std::endl;
		}

		preprocessor.run();
		
		// Occlists are required for inprocessing but are expensive to maintain.
		solver.occlists.destruct();
		if(solver.opts.general.verbose >= 1) {
			std::cout << "c Preprocessing took "
					<< (solver.perf.preprocTime / (1000 * 1000)) << " ms, peak memory: "
					<< sysPeakMemory() << " kiB." << std::endl;
			std::cout << "c Remaining variables: " << solver.varSpace.presentCount()
				<< ", clauses: " << solver.clauseSpace.numPresent()
				<< ", literals: " << solver.clauseSpace.presentLiterals() << "." << std::endl;	
		}
	}

	auto last_message = sys::hptCurrent();
	if(solver.opts.general.verbose >= 1)
		progressHeader(solver);

	satuzk::cdcl::TotalSearchStats search_stats;
	satuzk::cdcl::SearchLimits search_limits;
	search_limits.propagations = 1000000;

	while(true) {
		if(solver.state.general.stopSolve)
			return satuzk::SolveState::kStateBreak;
		
		auto current = sys::hptCurrent();
		if(solver.opts.general.timeout != 0 && solver.opts.general.timeout
				< current - solver.state.general.startTime)
			return satuzk::SolveState::kStateBreak;
		if(current - last_message > 5LL * 1000 * 1000 * 1000) {
			if(solver.opts.general.verbose >= 1)
				progressMessage(solver, current);
			last_message = current;
		}

		satuzk::SolveState state = search(solver, search_limits, &search_stats);
		if(state == satuzk::SolveState::kStateSatisfied
				|| state == satuzk::SolveState::kStateUnsatisfiable
				|| state == satuzk::SolveState::kStateAssumptionFail) 
			return state;

		sr.simplify();		
//		simplifyConfig.simplifyPass(solver);
	}
}

void onInterrupt(int sig) {
	std::cout << "c signal: ";
	switch(sig) {
		case SIGINT: std::cout << "SIGINT"; break;
		case SIGXCPU: std::cout << "SIGXCPU"; break;
		default: std::cout << sig;
	}
	std::cout << std::endl;
	solver.state.general.stopSolve = true;
}

int main(int argc, char **argv) {
	std::cout << "c This is satUZK-seq, commit " << CONFIG_REVISION
	#ifdef CONFIG_DIRTY
		<< "*"
	#endif
		<< std::endl;
	
	std::cout << "c Args:";
	for(int i = 0; i < argc; i++)
		std::cout << ' ' << argv[i];
	std::cout << std::endl;

	if(satuzk::kDbgSlowAssertions)
		std::cout << "c " << "\e[31m" << "WARNING: Slow assertions are enabled!"
				<< "\e[39m" << std::endl;

	solver.opts.general.verbose = 1;

	if(signal(SIGINT, onInterrupt) == SIG_ERR
			|| signal(SIGXCPU, onInterrupt) == SIG_ERR)
		throw std::runtime_error("Could not install signal handler");
	
	// parse the parameters given to the solver
	po::options_description options_desc("Options");
	options_desc.add_options()
		("help", "Print help message")
		("v", "Verbose output")
		("seed", po::value<int>(), "Set random seed")
		("budget", po::value<int>(), "Set solve time buget (in seconds)")
		("timeout", po::value<int>(), "Set solver time out (in seconds)")
		("assume", po::value<std::vector<long>>(), "Set up assumption literals")
		("emulate", po::value<std::string>(), "Emulate another SAT solver")
		("simplify", "Enable CNF simplification")
		("with-model", "Display model on SAT answer")
		("with-proof", po::value<std::string>()->implicit_value("drat-plain"), "Emit UNSAT proof in DRAT format")
		("model-file", po::value<std::string>(), "Redirect --with-model output")
		("proof-file", po::value<std::string>(), "Redirect --with-proof output")
		("instance", po::value<std::string>(), "CNF problem instance");
	
	po::positional_options_description positional_desc;
	positional_desc.add("instance", 1);

	po::variables_map options;
	po::store(po::command_line_parser(argc, argv)
			.options(options_desc).positional(positional_desc).run(), options);
	po::notify(options);

	if(options.count("help") > 0) {
		std::cout << "Usage: satUZK-preproc [OPTIONS...] instance\n\n"
				<< options_desc << std::endl;
		return 0;
	}

	if(options.count("v") > 0)
		solver.opts.general.verbose = 3;

	if(options.count("seed") > 0)
		solver.seedRandomEngine(options["seed"].as<int>());

	if(options.count("budget") > 0)
		solver.opts.general.budget = options["budget"].as<int>() * 1000000000LL;
	if(options.count("timeout") > 0) {
		solver.opts.general.budget = options["timeout"].as<int>() * 1000000000LL;
		solver.opts.general.timeout = options["timeout"].as<int>() * 1000000000LL;
	}

	if(options.count("emulate") > 0) {
		if(options["emulate"].as<std::string>() == "MiniSat") {
			solver.emulation = satuzk::cdcl::Emulation::miniSat;
		}else if(options["emulate"].as<std::string>() == "Glucose") {
			solver.emulation = satuzk::cdcl::Emulation::glucose;
		}else{
			throw std::runtime_error("Illegal parameter for --emulate");
		}
	}

	if(options.count("simplify") > 0)
		enableSimplification = true;

	if(options.count("with-model") > 0)
		withModel = ModelStyle::standard;

	if(options.count("with-proof"))
		if(options["with-proof"].as<std::string>() == "drat-plain") {
			withProof = ProofStyle::dratPlain;
		}else if(options["with-proof"].as<std::string>() == "drat-binary") {
			withProof = ProofStyle::dratBinary;
		}else{
			throw std::runtime_error("Illegal parameter for --with-proof");
		}

	if(options.count("model-file") > 0) {
		modelFile = fopen(options["model-file"].as<std::string>().c_str(), "w");
		if(!modelFile)
			throw std::runtime_error("Could not open model file");
	}
	if(options.count("proof-file") > 0) {
		proofFile = fopen(options["proof-file"].as<std::string>().c_str(), "w");
		if(!proofFile)
			throw std::runtime_error("Could not open proof file");
	}

#ifdef FEATURE_GOOGLE_PROFILE
	char profile[256];
	sprintf(profile, "%d.profile", getpid());
	printf("Writing profile %s\n", profile);
	ProfilerStart(profile);
#endif

	satuzk::SolveState result = satuzk::kStateBreak;
	try {
		assert(options.count("instance") > 0);
		auto instance_file = options["instance"].as<std::string>();
		int instance_fd = open(instance_file.c_str(), O_RDONLY);
		if(instance_fd == -1)
			throw std::runtime_error("Could not read input file");

		solver.resetBaseHeuristics();

		CnfParser parser(solver.varSpace, solver.clauseSpace, instance_fd);
		parser.parse();

		solver.resetInputHeuristics();
		
		if(close(instance_fd) != 0)
			throw std::runtime_error("Could not close instance file");

		std::cout << "c Parse time: " << sysGetCpuTime() << " ms, peak memory: "
				<< sysPeakMemory() << " kiB." << std::endl;
		
		if(options.count("assume") > 0) {
			auto &assumptions = options["assume"].as<std::vector<long>>();
			for(auto it = assumptions.begin(); it != assumptions.end(); ++it) {
				Solver::LiteralIdType literal = Solver::LiteralIdType::fromNumber(*it);
				solver.lockVariable(literal.variable());
				solver.assumptionEnable(literal);
			}
		}

		result = solve();
	} catch(std::bad_alloc &) {
		std::cout << "c Out-of-memory exception." << std::endl;
	}

	if(options.count("save-model") > 0) {
		std::fstream model_stream(options["save-model"].as<std::string>().c_str(),
				std::fstream::out | std::fstream::trunc);
		if(result == satuzk::kStateSatisfied) {
			model_stream << "SAT\n";
			
			std::unordered_map<int, Bool3> model;
//FIXME			solver.extModelConfig.buildModel(solver, model);
			
			//FIXME
/*			for(long i = 1; i <= read_hooks.numVariables(); ++i) {
				if(i != 1)
					model_stream << " ";
				// TODO: don't include non-assigned variables?
				if(model[i].isTrue()) {
					model_stream << i;
				}else model_stream << -i;
			}
			model_stream << " 0\n";*/
		}else if(result == satuzk::kStateUnsatisfiable) {
			model_stream << "UNSAT\n";
		}else model_stream << "INDET\n";
		model_stream.close();
	}

	if(result == satuzk::kStateSatisfied) {
		// TODO: add some debug flag to validate this
		// satuzk::cdcl::checkSolution(solver);

		std::cout << "s SATISFIABLE" << std::endl;

		if(withModel == ModelStyle::standard) {
			if(modelFile)
				fputs("s SATISFIABLE\n", modelFile);

			using LiteralIdType = Solver::LiteralIdType;
			std::vector<LiteralIdType> premodel;
			for(auto var : solver.varSpace) {
				if(solver.assignment.isTrue(var.positive()))
					premodel.push_back(var.positive().id());
				if(solver.assignment.isTrue(var.negative()))
					premodel.push_back(var.negative().id());
			}

			Solver::EliminationStackType::ModelExtender me{&solver.eliminationStack};
			auto model = me.extend(premodel);

			FILE *file = modelFile ? modelFile : stdout;
			for(auto it = model.begin(); it != model.end(); /* no increment */) {
				fputc('v', file);
				for(int i = 0; i < 10 && it != model.end(); ++i, ++it)
					fprintf(file, " %d", it->toNumber());
				if(it == model.end()) {
					fputs(" 0\n", file);
				}else{
					fputc('\n', file);
				}
			}
		}
	}else if(result == satuzk::kStateUnsatisfiable) {
		std::cout << "s UNSATISFIABLE" << std::endl;

		if(withModel == ModelStyle::standard) {
			if(modelFile)
				fputs("s UNSATISFIABLE\n", modelFile);
		}
	}else if(result == satuzk::kStateAssumptionFail) {
		std::cout << "s ASSUMPTIONFAIL" << std::endl;
		
//FIXME			std::vector<Solver::Literal> failed = findFailedAssumptions(solver);
//			for(auto it = failed.begin(); it != failed.end(); ++it)
//				std::cout << "c assumption " << it->toNumber() << " failed" << std::endl;

	}else{
		assert(result == satuzk::kStateBreak);
		std::cout << "s UNKNOWN" << std::endl;
	}

#ifdef FEATURE_GOOGLE_PROFILE
	ProfilerStop();	
#endif

	auto secs = sysGetCpuTime() / 1000.0;

	std::cout << std::setprecision(2);
	std::cout << "c ------ statistics: general ------" << std::endl;
	std::cout << "c cpu time: " << (int)secs << " secs" << std::endl;
	std::cout << "c peak memory: " << sysPeakMemory() << " kb" << std::endl;
	std::cout << "c    [      ] clause collections: " << solver.stat.general.clauseCollects << std::endl;

	std::cout << "c ------ search ------" << std::endl;
	std::cout << "c    conflicts: " << solver.trail.conflictCounter;
	if(secs > 0)
		std::cout << ", conflicts/sec: " << (int64_t)(solver.trail.conflictCounter / secs);
	std::cout << std::endl;
	std::cout << "c    propagations: " << solver.trail.propagationCounter;
	if(secs > 0)
		std::cout << ", propagations/sec: " << (int64_t)(solver.trail.propagationCounter / secs);
	std::cout << std::endl;
	std::cout << "c    deleted clauses: " << solver.stat.general.deletedClauses << std::endl;
	std::cout << "c    restarts: " << solver.stat.search.restarts << std::endl;
	std::cout << "c    learned units: " << solver.stat.search.learnedUnits << ", binary: " << solver.stat.search.learnedBinary << std::endl;
	std::cout << "c    minimized literals: " << solver.stat.search.minimizedLits
			<< " of " << solver.stat.search.learnedLits << ", " << (100.0f - solver.stat.search.minimizedLits * 100.0f
			/ solver.stat.search.learnedLits) << "% redundant" << std::endl;
	std::cout << "c    clause reductions: " << solver.stat.clauseRed.reductionRuns
		<< ", active: " << (100.0f * solver.stat.clauseRed.clausesActive
			/ (solver.stat.clauseRed.clausesActive + solver.stat.clauseRed.clausesNotActive)) << "%"
		<< ", deletions: " << (100.0f * solver.stat.clauseRed.clauseDeletions
			/ solver.stat.clauseRed.clausesConsidered) << "%"
		<< ", freezes: " << (100.0f * solver.stat.clauseRed.clauseFreezes
			/ solver.stat.clauseRed.clausesConsidered) << "%"
		<< ", unfreezes: " << (100.0f * solver.stat.clauseRed.clauseUnfreezes
			/ solver.stat.clauseRed.clausesConsidered) << "%"
		<< std::endl;
	
	std::cout << "c ------ simplification ------" << std::endl;
/*	std::cout << "c    [VECD  ]  vars eliminated: " << solver.stat.simp.bve.elimVars
			<< ", facts discovered: " << solver.stat.simp.bve.numFacts << std::endl;
	std::cout << "c    [BVA   ]  new vars: " << solver.stat.simp.bvaNewVars
			<< ", removed clauses: " << solver.stat.simp.bvaRemovedClauses << std::endl;
	std::cout << "c    [SCC   ]  vars eliminated: " << solver.stat.simp.sccVariables << std::endl;
	std::cout << "c    [SUB   ]  shortcut checks: " << solver.stat.simp.subsume.resShortcuts
		<< ", subsumption checks: " << solver.stat.simp.subsume.resChecks
		<< ", resolution checks: " << solver.stat.simp.subsume.resExpensiveChecks << std::endl;
	std::cout << "c    [SUB   ]  clauses removed: " << solver.stat.simp.subsume.subClauses
		<< ", clauses shortened: " << solver.stat.simp.subsume.resClauses
		<< ", facts discovered: " << solver.stat.simp.subsume.resFacts << std::endl;
	std::cout << "c    [BCE   ]  blocked clauses: " << solver.stat.simp.bce.elimClauses << std::endl;
	std::cout << "c    [DIST  ]  checks: " << solver.stat.simp.distChecks
		<< ", conflicts: " << solver.stat.simp.distConflicts
		<< " (removed " << solver.stat.simp.distConflictsRemoved << " lits)"
		<< ", asserts: " << solver.stat.simp.distAsserts
		<< " (removed " << solver.stat.simp.distAssertsRemoved << " lits)"
		<< ", ssubs: " << solver.stat.simp.distSelfSubs
		<< " (removed " << solver.stat.simp.distSelfSubsRemoved << " lits)" << std::endl;
	std::cout << "c    [HB    ]  new clauses: " << solver.stat.simp.hbNewClauses << std::endl;
	std::cout << "c    [UNHIDE]  transitive edges: " << solver.stat.simp.unhide.transitiveEdges
		<< ", failed literals: " << solver.stat.simp.unhide.failedLiterals
		<< ", equivalent literals: " << solver.stat.simp.unhide.equivalentLiterals
		<< ", hidden literals: " << solver.stat.simp.unhide.hleLiterals
		<< ", hidden tautologies: " << solver.stat.simp.unhide.hteClauses << std::endl;*/
	
	std::cout << "c    [      ]  Elimination stack consumes "
			<< (solver.eliminationStack.getUsedSpace() / 1024) << " kiB." << std::endl;

	std::cout << "c ------ time ------" << std::endl;
//	std::cout << "c    [      ]  inprocessing: "
//			<< (solver.perf.inprocTime / (1000 * 1000)) << " ms" << std::endl;
	
	constexpr int64_t k1Million = 1000000LL;

	std::cout << std::fixed;
	std::cout << "c [search] time: " << (solver.perf.searchTime / k1Million) << " ms"
			", perf: " << ((float)solver.perf.searchWatchVisitOps
				/ (float)(solver.perf.searchTime / 10e6f)) << " ops/ms" << std::endl;
/*	std::cout << "c [vecd] time: " << (solver.stat.simp.bve.time / k1Million) << " ms"
			", perf: " << ((float)solver.stat.simp.bve.ops
				/ (float)(solver.stat.simp.bve.time / 10e6f)) << " ops/ms" << std::endl;
	std::cout << "c [bva] time: " << (solver.perf.bvaTime / k1Million) << " ms"
			", perf: " << ((float)solver.perf.bvaOps
				/ (float)(solver.perf.bvaTime / 10e6f)) << " ops/ms" << std::endl;
	std::cout << "c [bce] time: " << (solver.stat.simp.bce.time / k1Million) << " ms"
			<< ", pref: " << ((float)solver.stat.simp.bce.ops
				/ (float)(solver.stat.simp.bce.time / 10e6f)) << " ops/ms" << std::endl;
	std::cout << "c [subsume] " << (solver.stat.simp.subsume.time / k1Million) << " ms"
			<< ", perf: " << ((float)solver.stat.simp.subsume.ops
				/ (float)(solver.stat.simp.subsume.time / 10e6f)) << " ops/ms" << std::endl;
	std::cout << "c [unhide] " << (solver.stat.simp.unhide.time / k1Million) << " ms"
			<< ", perf: " << ((float)solver.stat.simp.bce.ops
				/ (float)(solver.stat.simp.bce.time / 10e6f)) << " ops/ms" << std::endl;*/
	
//	std::cout << "c === inprocessing ===" << std::endl;
//	std::cout << "c [subsume] " << (solver.stat.simp.inprocSubsume.time / k1Million) << " ms" << std::endl;

	if(result == satuzk::kStateSatisfied) {
		return 10;
	}else if(result == satuzk::kStateUnsatisfiable) {
		return 20;
	}
	return 0;
}

