
$c_SRCDIR := $(TREE_PATH)/$c/src
$c_BINDIR := $(BUILD_PATH)/$c/bin

.PHONY: all-$c debug-$c clean-$c

$c_TARGETS := clean-$c $($c_BINDIR)/satUZK-seq $($c_BINDIR)/satUZK-seq.ndebug \
		$($c_BINDIR)/satUZK-seq.profile $($c_BINDIR)/satUZK-seq.asan $($c_BINDIR)

all-$c: $($c_BINDIR)/satUZK-seq
all-$c.ndebug: $($c_BINDIR)/satUZK-seq.ndebug
all-$c.debug: $($c_BINDIR)/satUZK-seq.debug
all-$c.profile: $($c_BINDIR)/satUZK-seq.profile
all-$c.asan: $($c_BINDIR)/satUZK-seq.asan

clean-$c:
	rm -f $($d_BINDIR)/satUZK-seq $($d_BINDIR)/satUZK-seq.d

$($c_BINDIR):
	mkdir -p $@

$c_INCLUDES := -I$(TREE_PATH)/lib/include -I$(TREE_PATH)/common/include

$c_CXXFLAGS := $(CXXFLAGS) $($c_INCLUDES)
$c_CXXFLAGS += -std=c++1y
$c_CXXFLAGS += -DCONFIG_HEADER=\"$(BUILD_PATH)/Config.hpp\"
$c_CXXFLAGS += -fwhole-program
$c_CXXFLAGS += -static-libgcc -static-libstdc++

$c_LIBS := -lrt -Wl,-Bstatic -lboost_program_options -Wl,-Bdynamic

$($c_BINDIR)/satUZK-seq: $($c_SRCDIR)/main.cpp | $($c_BINDIR)
	$(TREE_PATH)/mkconfig.sh $(TREE_PATH) release
	$(CXX) -o $@ -O3 $($d_CXXFLAGS) $< $($d_LIBS)
	$(CXX) $($d_CXXFLAGS) -MM -MP -MF $@.d -MT "$@" -MT "$@d" $<

$($c_BINDIR)/satUZK-seq.ndebug: $($c_SRCDIR)/main.cpp | $($c_BINDIR)
	$(TREE_PATH)/mkconfig.sh $(TREE_PATH) release
	$(CXX) -o $@ -O3 -DNDEBUG $($d_CXXFLAGS) $< $($d_LIBS)
	$(CXX) $($d_CXXFLAGS) -MM -MP -MF $@.d -MT "$@" -MT "$@d" $<

$($c_BINDIR)/satUZK-seq.debug: $($c_SRCDIR)/main.cpp | $($c_BINDIR)
	$(TREE_PATH)/mkconfig.sh $(TREE_PATH) release
	$(CXX) -o $@ -g $($d_CXXFLAGS) $< $($d_LIBS)
	$(CXX) $($d_CXXFLAGS) -MM -MP -MF $@.d -MT "$@" -MT "$@d" $<

$($c_BINDIR)/satUZK-seq.profile: $($c_SRCDIR)/main.cpp | $($c_BINDIR)
	$(TREE_PATH)/mkconfig.sh $(TREE_PATH) release
	$(CXX) -o $@ -O3 -g -DNDEBUG $($d_CXXFLAGS) $< $($d_LIBS)
	$(CXX) $($d_CXXFLAGS) -MM -MP -MF $@.d -MT "$@" -MT "$@d" $<

$($c_BINDIR)/satUZK-seq.asan: $($c_SRCDIR)/main.cpp | $($c_BINDIR)
	$(TREE_PATH)/mkconfig.sh $(TREE_PATH) release
	$(CXX) -o $@ -O3 -g -fsanitize=address,undefined $($d_CXXFLAGS) $< $($d_LIBS)
	$(CXX) $($d_CXXFLAGS) -MM -MP -MF $@.d -MT "$@" -MT "$@d" $<

-include $($c_BINDIR)/satUZK-seq.d
-include $($c_BINDIR)/satUZK-seq.ndebug.d
-include $($c_BINDIR)/satUZK-seq.debug.d
-include $($c_BINDIR)/satUZK-seq.profile.d
-include $($c_BINDIR)/satUZK-seq.asan.d

