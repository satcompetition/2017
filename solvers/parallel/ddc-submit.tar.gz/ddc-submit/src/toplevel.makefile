
.DEFAULT_GOAL := all

PROTOC = protoc
CXXFLAGS +=

include $(TREE_PATH)/rules.makefile
$(call include_dir,common)
$(call include_dir,seq)
$(call include_dir,par)
$(call include_dir,ipasir)
$(call include_dir,ddc)
$(call include_dir,lookahead)
$(call include_dir,pp)

.PHONY: all clean

all: $(addprefix all-,$(DIRECTORIES))

clean: $(addprefix clean-,$(DIRECTORIES))

