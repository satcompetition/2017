ScaLoPe
========
Collaboration model was changed

authors: Konan Tchinda Rodrigue and Tayou Djamegni Clémentin

PeneLoPe
========

For more information about this SAT solver, you may consult the following paper:
Gilles Audemard, Benoît Hoessen, Said Jabbour, Jean-Marie Lagniez, Cédric Piette, « Revisiting Clause Exchange in Parallel SAT Solving », in Fifteenth International Conference on Theory and Applications of Satisfiability Testing (SAT'12), june 2012.

update: a new restart strategy has been added to the solver. 

Content
-------
clean.sh             script to clean everything that was compiled
build.sh             script to compile the solver and SatELite
code/
 - solver.sh         script to use PeneLoPe after SatELite
 - build.sh          script to compile SatELite
 - clean.sh          script to clean SatELite
 - configuration.ini the file containing the different parameters for PeneLoPe
 - Doxyfile          file used to generate the documentation of PeneLoPe
 - Makefile          makefile used to build PeneLoPe (make all to see more information about it)
 - src/              the sources of PeneLoPe
 - include/          the public headers of PeneLoPe if you plan to use PeneLoPe as a library
 - SatELite/         the sources of SatELite

History
-------
PeneLoPe (Gilles Audemard, Benoît Hoessen, Said Jabbour, Jean-Marie Lagniez, Cédric Piette)

    ^
    |

ManySat2.0 (Youssef Hamadi, Said Jabbour, Lakhdar Sais)

    ^
    |

Minisat2 (Niklas Eén, Niklas Sörensson)


Build
-----

To build the solver, you may use the 'build.sh' script located in the same directory as this readme. It will create a 'solver' directory containing everything needed to run the solver.
Requirements:
 - g++
 - make
 - libstdc++-static 32 bits (for SatELite)
 - libstdc++-static, pthread-static and libgomp-static (for Penelope)

Usage
-----

You can either use penelope directly using the binary, (for more information: use the --help option) or use it through the provided script that will first run SatELite, and run penelope on the 'satelised' version of the instance. The script will also limit the time to 5000sec.

usage of the script:
sh solver.sh <instance.cnf>

Funny note
----------
Did you see the evolution of the #authors for the different solvers? Fib(3), Fib(4), Fib(5)

