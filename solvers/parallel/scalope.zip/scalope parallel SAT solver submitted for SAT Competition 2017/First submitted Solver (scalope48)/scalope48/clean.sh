make -C code cleaner
rm -f binary/scalope binary/SatELite_release binary/configuration.ini binary/solver.sh 
#rmdir binary
rm -rf binary
