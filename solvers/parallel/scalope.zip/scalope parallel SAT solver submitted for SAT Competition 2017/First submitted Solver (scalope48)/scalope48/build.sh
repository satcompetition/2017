make -C code CONF=Release SHARED="-fopenmp -static" scalope SatELite
mkdir binary
cp code/scalope code/SatELite_release code/configuration.ini code/solver.sh ./binary/
