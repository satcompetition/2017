The parallel solver: abcdsat_p
Authors : Jingchao Chen

abcdsat_p can be built with g++ command:
./build.sh

For running
cd bin 
./abcdsat_p FORMULA

