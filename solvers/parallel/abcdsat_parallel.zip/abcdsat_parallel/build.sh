#!/bin/bash

cd abcdsat_p/parallel
make r 2>&1
cp abcdSAT_p_release ../../bin/abcdsat_p

