/export/starexec/sandbox2/solver/glulu/simp/SimpSolver.o /export/starexec/sandbox2/solver/glulu/simp/SimpSolver.or /export/starexec/sandbox2/solver/glulu/simp/SimpSolver.od /export/starexec/sandbox2/solver/glulu/simp/SimpSolver.op: /export/starexec/sandbox2/solver/glulu/simp/SimpSolver.cc \
 /export/starexec/sandbox2/solver/glulu/simp/../mtl/Sort.h \
 /export/starexec/sandbox2/solver/glulu/simp/../mtl/Vec.h \
 /export/starexec/sandbox2/solver/glulu/simp/../mtl/IntTypes.h \
 /export/starexec/sandbox2/solver/glulu/simp/../mtl/XAlloc.h \
 /export/starexec/sandbox2/solver/glulu/simp/../simp/SimpSolver.h \
 /export/starexec/sandbox2/solver/glulu/simp/../mtl/Queue.h \
 /export/starexec/sandbox2/solver/glulu/simp/../core/Solver.h \
 /export/starexec/sandbox2/solver/glulu/simp/../mtl/Heap.h \
 /export/starexec/sandbox2/solver/glulu/simp/../mtl/Alg.h \
 /export/starexec/sandbox2/solver/glulu/simp/../utils/Options.h \
 /export/starexec/sandbox2/solver/glulu/simp/../utils/ParseUtils.h \
 /export/starexec/sandbox2/solver/glulu/simp/../core/SolverTypes.h \
 /export/starexec/sandbox2/solver/glulu/simp/../mtl/Map.h \
 /export/starexec/sandbox2/solver/glulu/simp/../mtl/Alloc.h \
 /export/starexec/sandbox2/solver/glulu/simp/../core/BoundedQueue.h \
 /export/starexec/sandbox2/solver/glulu/simp/../core/Constants.h \
 /export/starexec/sandbox2/solver/glulu/simp/../mtl/Clone.h \
 /export/starexec/sandbox2/solver/glulu/simp/../core/SolverStats.h \
 /export/starexec/sandbox2/solver/glulu/simp/../utils/System.h
/export/starexec/sandbox2/solver/glulu/simp/Main.o /export/starexec/sandbox2/solver/glulu/simp/Main.or /export/starexec/sandbox2/solver/glulu/simp/Main.od /export/starexec/sandbox2/solver/glulu/simp/Main.op: /export/starexec/sandbox2/solver/glulu/simp/Main.cc \
 /export/starexec/sandbox2/solver/glulu/simp/../utils/System.h \
 /export/starexec/sandbox2/solver/glulu/simp/../mtl/IntTypes.h \
 /export/starexec/sandbox2/solver/glulu/simp/../utils/ParseUtils.h \
 /export/starexec/sandbox2/solver/glulu/simp/../utils/Options.h \
 /export/starexec/sandbox2/solver/glulu/simp/../mtl/Vec.h \
 /export/starexec/sandbox2/solver/glulu/simp/../mtl/XAlloc.h \
 /export/starexec/sandbox2/solver/glulu/simp/../core/Dimacs.h \
 /export/starexec/sandbox2/solver/glulu/simp/../core/SolverTypes.h \
 /export/starexec/sandbox2/solver/glulu/simp/../mtl/Alg.h \
 /export/starexec/sandbox2/solver/glulu/simp/../mtl/Map.h \
 /export/starexec/sandbox2/solver/glulu/simp/../mtl/Alloc.h \
 /export/starexec/sandbox2/solver/glulu/simp/../simp/SimpSolver.h \
 /export/starexec/sandbox2/solver/glulu/simp/../mtl/Queue.h \
 /export/starexec/sandbox2/solver/glulu/simp/../core/Solver.h \
 /export/starexec/sandbox2/solver/glulu/simp/../mtl/Heap.h \
 /export/starexec/sandbox2/solver/glulu/simp/../core/BoundedQueue.h \
 /export/starexec/sandbox2/solver/glulu/simp/../core/Constants.h \
 /export/starexec/sandbox2/solver/glulu/simp/../mtl/Clone.h \
 /export/starexec/sandbox2/solver/glulu/simp/../core/SolverStats.h
