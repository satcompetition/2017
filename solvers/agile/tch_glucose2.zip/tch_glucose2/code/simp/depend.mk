/home/moon/tex/2017SAT_COMP/tch_glucose2/code/simp/SimpSolver.o /home/moon/tex/2017SAT_COMP/tch_glucose2/code/simp/SimpSolver.or /home/moon/tex/2017SAT_COMP/tch_glucose2/code/simp/SimpSolver.od /home/moon/tex/2017SAT_COMP/tch_glucose2/code/simp/SimpSolver.op: \
 /home/moon/tex/2017SAT_COMP/tch_glucose2/code/simp/SimpSolver.cc \
 /home/moon/tex/2017SAT_COMP/tch_glucose2/code/simp/../mtl/Sort.h \
 /home/moon/tex/2017SAT_COMP/tch_glucose2/code/simp/../mtl/Vec.h \
 /home/moon/tex/2017SAT_COMP/tch_glucose2/code/simp/../mtl/IntTypes.h \
 /home/moon/tex/2017SAT_COMP/tch_glucose2/code/simp/../mtl/XAlloc.h \
 /home/moon/tex/2017SAT_COMP/tch_glucose2/code/simp/../simp/SimpSolver.h \
 /home/moon/tex/2017SAT_COMP/tch_glucose2/code/simp/../mtl/Queue.h \
 /home/moon/tex/2017SAT_COMP/tch_glucose2/code/simp/../core/Solver.h \
 /home/moon/tex/2017SAT_COMP/tch_glucose2/code/simp/../mtl/Heap.h \
 /home/moon/tex/2017SAT_COMP/tch_glucose2/code/simp/../mtl/Alg.h \
 /home/moon/tex/2017SAT_COMP/tch_glucose2/code/simp/../utils/Options.h \
 /home/moon/tex/2017SAT_COMP/tch_glucose2/code/simp/../utils/ParseUtils.h \
 /home/moon/tex/2017SAT_COMP/tch_glucose2/code/simp/../core/SolverTypes.h \
 /home/moon/tex/2017SAT_COMP/tch_glucose2/code/simp/../mtl/Map.h \
 /home/moon/tex/2017SAT_COMP/tch_glucose2/code/simp/../mtl/Alloc.h \
 /home/moon/tex/2017SAT_COMP/tch_glucose2/code/simp/../core/BoundedQueue.h \
 /home/moon/tex/2017SAT_COMP/tch_glucose2/code/simp/../core/Constants.h \
 /home/moon/tex/2017SAT_COMP/tch_glucose2/code/simp/../utils/System.h
/home/moon/tex/2017SAT_COMP/tch_glucose2/code/simp/Main.o /home/moon/tex/2017SAT_COMP/tch_glucose2/code/simp/Main.or /home/moon/tex/2017SAT_COMP/tch_glucose2/code/simp/Main.od /home/moon/tex/2017SAT_COMP/tch_glucose2/code/simp/Main.op: /home/moon/tex/2017SAT_COMP/tch_glucose2/code/simp/Main.cc \
 /home/moon/tex/2017SAT_COMP/tch_glucose2/code/simp/../utils/System.h \
 /home/moon/tex/2017SAT_COMP/tch_glucose2/code/simp/../mtl/IntTypes.h \
 /home/moon/tex/2017SAT_COMP/tch_glucose2/code/simp/../utils/ParseUtils.h \
 /home/moon/tex/2017SAT_COMP/tch_glucose2/code/simp/../utils/Options.h \
 /home/moon/tex/2017SAT_COMP/tch_glucose2/code/simp/../mtl/Vec.h \
 /home/moon/tex/2017SAT_COMP/tch_glucose2/code/simp/../mtl/XAlloc.h \
 /home/moon/tex/2017SAT_COMP/tch_glucose2/code/simp/../core/Dimacs.h \
 /home/moon/tex/2017SAT_COMP/tch_glucose2/code/simp/../core/SolverTypes.h \
 /home/moon/tex/2017SAT_COMP/tch_glucose2/code/simp/../mtl/Alg.h \
 /home/moon/tex/2017SAT_COMP/tch_glucose2/code/simp/../mtl/Map.h \
 /home/moon/tex/2017SAT_COMP/tch_glucose2/code/simp/../mtl/Alloc.h \
 /home/moon/tex/2017SAT_COMP/tch_glucose2/code/simp/../simp/SimpSolver.h \
 /home/moon/tex/2017SAT_COMP/tch_glucose2/code/simp/../mtl/Queue.h \
 /home/moon/tex/2017SAT_COMP/tch_glucose2/code/simp/../core/Solver.h \
 /home/moon/tex/2017SAT_COMP/tch_glucose2/code/simp/../mtl/Heap.h \
 /home/moon/tex/2017SAT_COMP/tch_glucose2/code/simp/../core/BoundedQueue.h \
 /home/moon/tex/2017SAT_COMP/tch_glucose2/code/simp/../core/Constants.h
