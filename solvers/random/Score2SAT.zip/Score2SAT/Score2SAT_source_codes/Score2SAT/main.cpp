#include <iostream>
#include <fstream>
#include <string>
#include <sstream>
#include <stdio.h>
#include <stdlib.h>

using namespace std;

enum type{SAT3, SAT4, SAT5, SAT6, SAT7, strSAT} probtype;

#define pop(stack) stack[--stack ## _fill_pointer]
#define push(item, stack) stack[stack ## _fill_pointer++] = item

/* limits on the size of the problem. */
#define MAX_VARS    5000050
#define MAX_CLAUSES 21500215

// Define a data structure for a literal in the SAT problem.
struct lit {
    int clause_num;		//clause num, begin with 0
    int var_num;		//variable num, begin with 1
    int sense;			//is 1 for true literals, 0 for false literals.
};

/*parameters of the instance*/
int     num_vars;		//var index from 1 to num_vars
int     num_clauses;	//clause index from 0 to num_clauses-1
int		max_clause_len;
int		min_clause_len;

/* literal arrays */				
lit*	var_lit[MAX_VARS];				//var_lit[i][j] means the j'th literal of var i.
int		var_lit_count[MAX_VARS];        //amount of literals of each var
lit*	clause_lit[MAX_CLAUSES];		//clause_lit[i][j] means the j'th literal of clause i.
int		clause_lit_count[MAX_CLAUSES]; 	// amount of literals in each clause	

/* Information about the variables. */
int     score[MAX_VARS];				
long long		time_stamp[MAX_VARS];
long long		conf_change[MAX_VARS];
int*	var_neighbor[MAX_VARS];
int		var_neighbor_count[MAX_VARS];
int		pscore[MAX_VARS];
long long		cscc[MAX_VARS];
int		bscore[MAX_VARS];
int		mscore[MAX_VARS];
int		mscore_2[MAX_VARS];

/* Information about the clauses */			
int     clause_weight[MAX_CLAUSES];		
int     sat_count[MAX_CLAUSES];			
int		sat_var[MAX_CLAUSES];
int		sat_var2[MAX_CLAUSES];

//unsat clauses stack
int		unsat_stack[MAX_CLAUSES];		//store the unsat clause number
int		unsat_stack_fill_pointer;
int		index_in_unsat_stack[MAX_CLAUSES];//which position is a clause in the unsat_stack

//variables in unsat clauses
int		unsatvar_stack[MAX_VARS];		
int		unsatvar_stack_fill_pointer;
int		index_in_unsatvar_stack[MAX_VARS];
int		unsat_app_count[MAX_VARS];		//a varible appears in how many unsat clauses

//configuration changed decreasing variables (score>0 and confchange=1)
int		goodvar_stack[MAX_VARS];		
int		goodvar_stack_fill_pointer;
int		already_in_goodvar_stack[MAX_VARS];

/* Information about solution */
int     cur_soln[MAX_VARS];	//the current solution, with 1's for True variables, and 0's for False variables


void free_memory()
{
	int i;
	for (i = 0; i < num_clauses; i++) 
	{
		delete[] clause_lit[i];
	}
	
	for(i=1; i<=num_vars; ++i)
	{
		delete[] var_lit[i];
		delete[] var_neighbor[i];
	}
}

/*
 * Read in the problem.
 */
int temp_lit[MAX_VARS]; //the max length of a clause can be MAX_VARS
int build_instance(char *filename)
{
	char    line[1024];
	char    tempstr1[10];
	char    tempstr2[10];
	int     cur_lit;
	int     i,j;
	int		v,c;//var, clause
	
	ifstream infile(filename);
	if(infile==NULL)
		return 0;

	/*** build problem data structures of the instance ***/
	infile.getline(line,1024);
	while (line[0] != 'p')
		infile.getline(line,1024);

	sscanf(line, "%s %s %d %d", tempstr1, tempstr2, &num_vars, &num_clauses);
	
	if(num_vars>=MAX_VARS || num_clauses>=MAX_CLAUSES)
	{
		cout<<"the size of instance exceeds out limitation, please enlarge MAX_VARS and (or) MAX_CLAUSES."<<endl;
		exit(-1);
	}
	
	for (c = 0; c < num_clauses; c++) 
		clause_lit_count[c] = 0;
	for (v=1; v<=num_vars; ++v)
		var_lit_count[v] = 0;
		
	max_clause_len = 0;
	min_clause_len = num_vars;
		
	//Now, read the clauses, one at a time.
	for (c = 0; c < num_clauses; c++) 
	{
		infile>>cur_lit;

		while (cur_lit != 0) { 
			temp_lit[clause_lit_count[c]] = cur_lit;
			clause_lit_count[c]++;
		
			infile>>cur_lit;
		}
		
		clause_lit[c] = new lit[clause_lit_count[c]+1];
		
		for(i=0; i<clause_lit_count[c]; ++i)
		{
			clause_lit[c][i].clause_num = c;
			clause_lit[c][i].var_num = abs(temp_lit[i]);
			if (temp_lit[i] > 0) clause_lit[c][i].sense = 1;
				else clause_lit[c][i].sense = 0;
			
			var_lit_count[clause_lit[c][i].var_num]++;
		}
		clause_lit[c][i].var_num=0; 
		clause_lit[c][i].clause_num = -1;
		
		if(clause_lit_count[c] > max_clause_len)
			max_clause_len = clause_lit_count[c];
		else if(clause_lit_count[c] < min_clause_len)
			min_clause_len = clause_lit_count[c];
	}
	infile.close();
	
	//creat var literal arrays
	for (v=1; v<=num_vars; ++v)
	{
		var_lit[v] = new lit[var_lit_count[v]+1];
		var_lit_count[v] = 0;	//reset to 0, for build up the array
	}
	//scan all clauses to build up var literal arrays
	for (c = 0; c < num_clauses; ++c) 
	{
		for(i=0; i<clause_lit_count[c]; ++i)
		{
			v = clause_lit[c][i].var_num;
			var_lit[v][var_lit_count[v]] = clause_lit[c][i];
			++var_lit_count[v];
		}
	}
	for (v=1; v<=num_vars; ++v) //set boundary
		var_lit[v][var_lit_count[v]].clause_num=-1;
	
	//problem type
	if(max_clause_len == min_clause_len)
	{
		if(max_clause_len<=3) probtype=SAT3;
		else if(max_clause_len<=4) probtype=SAT4;
		else if(max_clause_len<=5) probtype=SAT5;
		else if(max_clause_len<=6) probtype=SAT6;
		else probtype=SAT7;
	}
	else {
		probtype=strSAT;
	}
	
	return 1;
}

string generate_command_line(string instance, string seed)
{
	double r;
	r = (double)num_clauses/num_vars;
	
	string walksatlm = "WalkSATlm2013";
	string dccasat = "DCCASat";
	
	string solver = "";
	
	if(probtype==SAT3)
	{
		if(r<=4.24)
		{
			//employ WalkSATlm2013
			solver = walksatlm;
		}
		else
		{
			//employ DCCASat
			solver = dccasat;
		}
	}
	else if(probtype==SAT4)
	{
		if(r<=9.35)
		{
			//employ WalkSATlm2013
			solver = walksatlm;
		}
		else
		{
			//employ DCCASat
			solver = dccasat;
		}
	}
	else if(probtype==SAT5)
	{
		if(r<=20.1)
		{
			//employ WalkSATlm2013
			solver = walksatlm;
		}
		else
		{
			//employ DCCASat
			solver = dccasat;
		}
	}
	else if(probtype==SAT6)
	{
		if(r<=41.2)
		{
			//employ WalkSATlm2013
			solver = walksatlm;
		}
		else
		{
			//employ DCCASat
			solver = dccasat;
		}
	}
	else if(probtype==SAT7)
	{
		if(r<=80)
		{
			//employ WalkSATlm2013
			solver = walksatlm;
		}
		else
		{
			//employ DCCASat
			solver = dccasat;
		}
	}
	else
	{
		//employ DCCASat
		solver = dccasat;
	}
	
	string command_line = "./"+solver+" \""+instance+"\" "+seed;
	return command_line;
}

int main(int argc, char* argv[])
{
	string instance, seed;
	long long i;
	    
    if(argc!=3)
    {
    	cout<<"c Usage: "<<argv[0] << " <instance> <seed>" <<endl;
    	return -1;
    }

	if (build_instance(argv[1])==0)
	{
		cout<<"c Invalid filename: "<< argv[1]<<endl;
		return -1;
	}
    
    instance = argv[1];
    seed = argv[2];
    
    string command_line = generate_command_line(instance, seed);
    cout<<"c "<<command_line<<endl;
    
    int ret = system(command_line.c_str());
    
    	 
    free_memory();

    return 0;
}



