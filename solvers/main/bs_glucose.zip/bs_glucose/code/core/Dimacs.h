/****************************************************************************************[Dimacs.h]
Copyright (c) 2003-2006, Niklas Een, Niklas Sorensson
Copyright (c) 2007-2010, Niklas Sorensson

Permission is hereby granted, free of charge, to any person obtaining a copy of this software and
associated documentation files (the "Software"), to deal in the Software without restriction,
including without limitation the rights to use, copy, modify, merge, publish, distribute,
sublicense, and/or sell copies of the Software, and to permit persons to whom the Software is
furnished to do so, subject to the following conditions:

The above copyright notice and this permission notice shall be included in all copies or
substantial portions of the Software.

THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR IMPLIED, INCLUDING BUT
NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY, FITNESS FOR A PARTICULAR PURPOSE AND
NONINFRINGEMENT. IN NO EVENT SHALL THE AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM,
DAMAGES OR OTHER LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM, OUT
OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE SOFTWARE.
**************************************************************************************************/

#ifndef Glucose_Dimacs_h
#define Glucose_Dimacs_h

#include <stdio.h>
#include <vector>
#include <algorithm>
#include <math.h>
#include <functional>

#include "utils/ParseUtils.h"
#include "core/SolverTypes.h"

#define INF 987654321

namespace Glucose {

	std::vector< std::vector<int> > clauses;
	std::vector<int> vars;
	int clPos;	


//=================================================================================================
// DIMACS Parser:

template<class B, class Solver>
static void readClause(B& in, Solver& S, vec<Lit>& lits) {
    int     parsed_lit, var;
    lits.clear();
	std::vector<int> vars;
    for (;;){
        parsed_lit = parseInt(in);
        if (parsed_lit == 0) break;
        var = abs(parsed_lit)-1;
		vars.push_back(var);
        while (var >= S.nVars()) S.newVar();
        lits.push( (parsed_lit > 0) ? mkLit(var) : ~mkLit(var) );
    }
	clauses[clPos++] = vars;
}


void setVarClauseGraphFeatures(Features& d) {
		d.cvMean = 0, d.cvCovar = 0, d.cvMin = INF, d.cvMax = 0, d.cvEnt = 0;
		d.vcMean = 0, d.vcCovar = 0, d.vcMin = INF, d.vcMax = 0, d.vcEnt = 0;
		for(int i = 0; i < clauses.size(); i++) {
			for(int j = 0; j < clauses[i].size(); j++) {
				vars[clauses[i][j]]++;
			}
			d.cvMean += clauses[i].size();
		}
		double lenCl = double(clauses.size());
		for(int i = 0; i < lenCl; i++) {
			double sz = clauses[i].size();
			if(sz == 0) { 
				printf("Empty clause detected!\n"); exit(3);
			}
			double p = sz / d.cvMean;
			d.cvEnt -= p * log2(p);
			d.cvMax = std::max(d.cvMax, sz);
			d.cvMin = std::min(d.cvMin, sz);
			d.cvCovar += sz * sz;
		}
		d.cvMean /= lenCl;
		d.cvCovar /= (lenCl * d.cvMean * d.cvMean);
		d.cvCovar -= 1;
		d.cvCovar = sqrt(d.cvCovar);

//		printf("cv: %lf %lf %lf %lf %lf\n", d.cvMean, d.cvCovar, d.cvMin, d.cvMax, d.cvEnt);

		double nVar = vars.size();
		for(int i = 0; i < vars.size(); i++) {
			double sz = vars[i];
			if(sz == 0) {
				nVar--;
				continue;
			}

			d.vcMean += sz;
			d.vcCovar += sz * sz;
			d.vcMin = std::min(d.vcMin, sz);
			d.vcMax = std::max(d.vcMax, sz);
		}

		for(int i = 0; i < vars.size(); i++) {
			int sz = vars[i];			
			if(sz == 0) continue;
			double p = sz / d.vcMean;
			d.vcEnt -= p * log2(p);
		}

		d.vcMean /= nVar;
		d.vcCovar /= (nVar * d.vcMean * d.vcMean);
		d.vcCovar -= 1;
		d.vcCovar = sqrt(d.vcCovar);

//		printf("vc: %lf %lf %lf %lf %lf\n", vcMean, vcCovar, vcMin, vcMax, vcEnt);
	}



template<class B, class Solver>
static void parse_DIMACS_main(B& in, Solver& S) {
    vec<Lit> lits;
    int v = 0;
    int c = 0;
    int cnt = 0;
	clPos = 0;
    for (;;){
        skipWhitespace(in);
        if (*in == EOF) break;
        else if (*in == 'p'){
            if (eagerMatch(in, "p cnf")){
                v = parseInt(in);
                c = parseInt(in);

				S.features.vars = v;
				S.features.clauses = c;
				S.features.v_c = v / double(c);
				vars.resize(v);
				clauses.resize(c);

                // SATRACE'06 hack
                // if (clauses > 4000000)
                //     S.eliminate(true);
            }else{
                printf("PARSE ERROR! Unexpected char: %c\n", *in), exit(3);
            }
        } else if (*in == 'c' || *in == 'p')
            skipLine(in);
        else{
            cnt++;
            readClause(in, S, lits);
            S.addClause_(lits); }
    }
    if (v != S.nVars())
        fprintf(stderr, "WARNING! DIMACS header mismatch: wrong number of variables.\n");
    if (cnt  != c)
        fprintf(stderr, "WARNING! DIMACS header mismatch: wrong number of clauses.\n");

	setVarClauseGraphFeatures(S.features);
}

// Inserts problem into solver.
//
template<class Solver>
static void parse_DIMACS(gzFile input_stream, Solver& S) {
    StreamBuffer in(input_stream);
    parse_DIMACS_main(in, S); }

//=================================================================================================
}

#endif
