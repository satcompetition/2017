#include <iostream>
#include <stdio.h>
#include <vector>
#include <math.h>
#include <string.h>
#include <fstream>
#include <sstream>
#include <stdlib.h>
#include <cstdlib>
#include <ctime>

#define ENTROPY 0
#define GINI 1
#define MISCLASS 2
#define SAMPLE_RATE 0.6

using namespace std;

namespace Glucose {

class Node {
public:
	bool leaf; // Whether leaf of not
	int	fNum; // feature number used for branching
	double fVal; // threshold for selected feature
	bool bc1, bc2; // child exist?
	Node** child;
	int pos;
	int claNum, featDim;
	int minSampleNum, maxDepth; //stop criteria
	double entropy; //stop criteria
	int impurity;
	int nF, nK; //numbers for random feature selection 
	vector<double> prob; // Ratio for each class

	Node (int classNum, int fNum, int minSNum, int mDep, double ent, int imp) {
		claNum = classNum;
		featDim = fNum;
		minSampleNum = minSNum;
		maxDepth = mDep;
		entropy = ent;
		impurity = imp;
		pos = -1;
		leaf = 0;
		fNum = -1;
		fVal = -1;
		bc1 = bc2 = 0;
		child = new Node* [2];
		child[0] = NULL;
		child[1] = NULL;
		prob.resize(classNum, 0.);
	}

	void read(ifstream& f) {
		f >> leaf >> fNum >> fVal >> bc1 >> bc2;
		f >> pos >> claNum >> featDim >> minSampleNum >> maxDepth;
		f >> entropy >> impurity >> nF >> nK;
		for(int i = 0; i < claNum; i++) f >> prob[i];

		if(bc1) {
			child[0] = new Node(claNum, featDim, minSampleNum, maxDepth, entropy, impurity);
			child[0]->read(f);
		}
		if(bc2) {
			child[1] = new Node(claNum, featDim, minSampleNum, maxDepth, entropy, impurity);
			child[1]->read(f);
		}
	}

	vector<double> getProb(vector<double>& dat) {
		if(leaf) return prob;
		else {
			if(dat[fNum] < fVal) return child[0]->getProb(dat);
			else return child[1]->getProb(dat);
		}
	}
};


class RandomForest {
public:
	int T; //tree number
	int alpha, beta; // OOB, sampling
	vector<Node> dTrees; 
	int vm; // voting mote: 0 - avg prob, 1 - max cnt	
	vector<double> maxDat;
	int claNum, featDim, useF;
	int minSampleNum, maxDepth; //stop criteria
	double entropy; //stop criteria
	int impurity = MISCLASS;


	RandomForest() {
		T = 30;
		vm = 1;
	}

	void read(ifstream& f) {
		int tmp;
		f.precision(30);
		f >> T >> alpha >> beta >> vm >> useF >> claNum >> featDim >> maxDepth >> tmp;
		maxDat.resize(tmp);

//		std::cout << " " << T << " " << alpha << " " << beta << " " << vm << " " << useF << " " << claNum << " " << featDim << " " << maxDepth << " " <<  tmp << std::endl;


		for(int i = 0; i < tmp; i++) f >> maxDat[i];

		for(int i = 0; i < T; i++) {
			Node dTree(claNum, featDim, minSampleNum, maxDepth, entropy, impurity);
			dTree.read(f);

			dTrees.push_back(dTree);
		}
	}

	vector<double> getProb(vector<double>& dat) {
		vector<double> ret(claNum, 0.);

		if(vm == 0) {
			for(int i = 0; i < T; i++) {
				vector<double> ret1 = dTrees[i].getProb(dat); 
				for(int j = 0; j < ret1.size(); j++) {
//					if(idx == 0) cout << ret1[j] << " ";
					ret[j] += ret1[j];
				}
//				if(idx == 0) cout << endl;
			}
		
			for(int i = 0; i < ret.size(); i++) ret[i] /= double(T);
		}
		else if(vm == 1) {
			double maxV;
			int maxIdx;
			for(int i = 0; i < T; i++) {
				maxV = 0; maxIdx = 0;
				vector<double> ret1 = dTrees[i].getProb(dat); 
				for(int j = 0; j < ret1.size(); j++) {
//					if(idx == 0) cout << ret1[j] << " ";
					if(ret1[j] > maxV) {
						maxV = ret1[j]; maxIdx = j;
					}
				}
				ret[maxIdx] += 1.;  
//				if(idx == 0) cout << maxIdx << endl;
			}
		
			for(int i = 0; i < ret.size(); i++) ret[i] /= double(T);
		}

		return ret;
	}
};

}

/*
	RandomForest rf;
		ifstream iF;
		iF.open(argv[8], ios::in);
		rf.read(iF);
		iF.close();


		vector<double> probs = rf.getProb(i, dat1);
*/
